/*
 * Copyright (c) 2019 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.predix.edgemanager.qe.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author 212587995
 */
@SuppressWarnings({"javadoc", "nls"
}) @Target(ElementType.METHOD) @Retention(RetentionPolicy.RUNTIME)

public @interface JiraTestCaseInfo
{

    String testCaseName() default "";

    String description() default "";

    String moduleName() default "";

    String preCondition() default "";

    String requirementID() default "";

    String testType() default "";

    String epicName() default "";

}
