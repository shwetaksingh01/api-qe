/*
 * Copyright (c) 2012 - 2017 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.tools.testng;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

import org.testng.IAnnotationTransformer;
import org.testng.annotations.ITestAnnotation;

/**
 * 
 * @author 212547153
 */
@SuppressWarnings(
        {
            "nls", "rawtypes"
        })
public class AnnotationTransformer
implements IAnnotationTransformer
{

    /*
     * (non-Javadoc)
     * @see org.testng.IAnnotationTransformer#transform(org.testng.annotations.ITestAnnotation, java.lang.Class, java.lang.reflect.Constructor,
     * java.lang.reflect.Method)
     */
    @Override
    public void transform(ITestAnnotation annotation, Class testClass, Constructor testConstructor, Method testMethod)
    {
        // Configuration configuration = Configuration.getConfig();
        // if ( configuration.getEnvProp().equals("sysint") )
        // {
        // annotation.setEnabled(true);
        // }
        annotation.setRetryAnalyzer(Retry.class);

    }

}
