/*
 * Copyright (c) 2018 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */
package com.ge.dspmicro.qe.tools.utils;

import java.time.Instant;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@SuppressWarnings("javadoc")
public class Token
{
    private static final Logger _logger = LoggerFactory.getLogger(Token.class);
    public static final String ACCESS_TOKEN  = "access_token";
    public static final String TOKEN_TYPE    = "token_type";
    public static final String REFRESH_TOKEN = "refresh_token";
    public static final String EXPIRES_IN    = "expires_in";
    public static final String SCOPE         = "scope";
    public static final String JTI           = "jti";
    private             String accessToken;
    private             String tokenType;
    private             String refreshToken;
    private             long   expiresIn;
    private             String scope;
    private             String jti;

    /**
     *
     * @param epochTimestampBeforeUAARequestSent - the EPOCH in milliseconds representing when the request was sent out
     * @return boolean indicating whether or not the token has expired
     */
    public boolean hasTokenExpired(long epochTimestampBeforeUAARequestSent) {
        return Instant.now().toEpochMilli() > epochTimestampBeforeUAARequestSent + this.expiresIn * 1000;
    }

    /**
     * @return the accessToken
     */
    public String getAccessToken()
    {
        return this.accessToken;
    }

    /**
     * @param accessToken to be set
     */
    public void setAccessToken(String accessToken)
    {
        this.accessToken = accessToken;
    }

    /**
     * @return the tokenType
     */
    public String getTokenType()
    {
        return this.tokenType;
    }

    /**
     * @param tokenType to be set
     */
    public void setTokenType(String tokenType)
    {
        this.tokenType = tokenType;
    }

    /**
     * @return the refreshToken
     */
    public String getRefreshToken()
    {
        return this.refreshToken;
    }

    /**
     * @param refreshToken to use
     */
    public void setRefreshToken(String refreshToken)
    {
        this.refreshToken = refreshToken;
    }

    /**
     * @return expiredIn: number of seconds that the UAA token will be considered valid for (i.e. from the EPOCH moment
     * the original request was issued until that EPOCH moment + expiredIn seconds)
     */
    public long getExpiresIn()
    {
        return this.expiresIn;
    }

    /**
     * @param expiresIn to use - the # seconds from "now" until which the token will be considered valid
     */
    public void setExpiresIn(long expiresIn)
    {
        this.expiresIn = expiresIn;
    }

    /**
     * @return scope of the UAA Token
     */
    public String getScope()
    {
        return this.scope;
    }

    /**
     * @param scope to use
     */
    public void setScope(String scope)
    {
        this.scope = scope;
    }

    /**
     * @return jti - the JWT ID claim that provides a unique ID for the JSON Web Token - makes sure token cannot be replayed
     */
    public String getJti()
    {
        return this.jti;
    }

    /**
     * @param jti to use
     */
    public void setJti(String jti)
    {
        this.jti = jti;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString()
    {
        JSONObject jsonResponse = new JSONObject();
        jsonResponse.put(Token.ACCESS_TOKEN, StringUtils.repeat('*', this.accessToken.length()));
        jsonResponse.put(Token.TOKEN_TYPE, this.tokenType);
        if ( this.refreshToken != null )
        {
            jsonResponse.put(Token.REFRESH_TOKEN, StringUtils.repeat('*', this.refreshToken.length()));
        }
        jsonResponse.put(Token.EXPIRES_IN, String.valueOf(this.expiresIn));
        jsonResponse.put(Token.SCOPE, this.scope);
        jsonResponse.put(Token.JTI, this.jti);
        return jsonResponse.toJSONString();
    }

}
