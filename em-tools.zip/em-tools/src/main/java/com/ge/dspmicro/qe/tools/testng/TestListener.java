/*
 * Copyright (c) 2019 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.tools.testng;

import static com.ge.dspmicro.qe.tools.testng.QTestAPI.findOrCreateTestCase;
import static com.ge.dspmicro.qe.tools.testng.QTestAPI.findOrCreateTestRunAndUpdateStatus;
import static com.ge.dspmicro.qe.tools.testng.QTestAPI.findOrCreateTestSuite;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.ge.predix.edgemanager.qe.annotations.JiraTestCaseInfo;

/**
 * @author 212547153
 */

@SuppressWarnings("nls") public class TestListener
        implements ITestListener
{
    private static       Logger logger             = LoggerFactory.getLogger(TestListener.class);
    private static       String qTestIntegration   = System.getProperty("qTestIntegration");
    private static final String FAILED_INTEGRATION = "Failed to Integrate with QTest";

    /*
     * (non-Javadoc)
     * @see org.testng.ITestListener#onTestStart(org.testng.ITestResult)
     */
    @Override public void onTestStart(ITestResult result)
    {
        try
        {
            if ( qTestIntegration.equalsIgnoreCase("true") )
            {
                JiraTestCaseInfo testAnnotation = result.getMethod().getConstructorOrMethod().getMethod()
                        .getAnnotation(JiraTestCaseInfo.class);

                String testCaseName = testAnnotation.testCaseName();
                String description = testAnnotation.description();
                String moduleName = testAnnotation.moduleName();
                String preCondition = testAnnotation.preCondition();
                String requirementID = testAnnotation.requirementID();
                String epicName = testAnnotation.epicName();
                String testType = testAnnotation.testType();

                findOrCreateTestCase(requirementID, epicName, testType, moduleName, testCaseName, description,
                        preCondition);
            }
        }
        catch (Exception e)
        {
            logger.info(String.format(FAILED_INTEGRATION));
        }
    }

    /*
     * (non-Javadoc)
     * @see org.testng.ITestListener#onTestSuccess(org.testng.ITestResult)
     */
    @Override public void onTestSuccess(ITestResult result)
    {
        try
        {
            if ( qTestIntegration.equalsIgnoreCase("true") )
            {
                JiraTestCaseInfo testAnnotation = result.getMethod().getConstructorOrMethod().getMethod()
                        .getAnnotation(JiraTestCaseInfo.class);

                String testCaseName = testAnnotation.testCaseName();

                findOrCreateTestRunAndUpdateStatus(testCaseName, "PASS", "Success");
            }
        }
        catch (Exception e)
        {
            logger.info(String.format(FAILED_INTEGRATION));
        }
    }

    /*
     * (non-Javadoc)
     * @see org.testng.ITestListener#onTestFailure(org.testng.ITestResult)
     */
    @Override public void onTestFailure(ITestResult result)
    {
        logger.error("TEST FAILED: " + result.getThrowable().getMessage());

        try
        {
            if ( qTestIntegration.equalsIgnoreCase("true") )
            {
                JiraTestCaseInfo testAnnotation = result.getMethod().getConstructorOrMethod().getMethod()
                        .getAnnotation(JiraTestCaseInfo.class);

                String testCaseName = testAnnotation.testCaseName();

                String failureMsg = null;
                if ( null != result.getThrowable() )
                {
                    failureMsg = result.getThrowable().getMessage().replaceAll("[\\n\\t\\r]","");
                }
                findOrCreateTestRunAndUpdateStatus(testCaseName, "FAIL", failureMsg);
            }
        }
        catch (Exception e)
        {
            logger.info(String.format(FAILED_INTEGRATION));
        }
    }

    /*
     * (non-Javadoc)
     * @see org.testng.ITestListener#onTestSkipped(org.testng.ITestResult)
     */
    @Override public void onTestSkipped(ITestResult result)
    {
        logger.info("TEST SKIPPED");

        try
        {
            if ( qTestIntegration.equalsIgnoreCase("true") )
            {
                JiraTestCaseInfo testAnnotation = result.getMethod().getConstructorOrMethod().getMethod()
                        .getAnnotation(JiraTestCaseInfo.class);

                String testCaseName = testAnnotation.testCaseName();

                findOrCreateTestRunAndUpdateStatus(testCaseName, "SKIP", "Skipped");
            }
        }
        catch (Exception e)
        {
            logger.info(String.format(FAILED_INTEGRATION));
        }
    }

    /*
     * (non-Javadoc)
     * @see org.testng.ITestListener#onTestFailedButWithinSuccessPercentage(org.testng.ITestResult)
     */
    @Override public void onTestFailedButWithinSuccessPercentage(ITestResult result)
    {
        //Auto-generated method stub

    }

    /*
     * (non-Javadoc)
     * @see org.testng.ITestListener#onStart(org.testng.ITestContext)
     */
    @Override public void onStart(ITestContext context)
    {
        try
        {
            if ( qTestIntegration.equalsIgnoreCase("true") )
                findOrCreateTestSuite();
        }
        catch (Exception e)
        {
            logger.info(String.format(FAILED_INTEGRATION));
        }

    }

    /*
     * (non-Javadoc)
     * @see org.testng.ITestListener#onFinish(org.testng.ITestContext)
     */
    @Override public void onFinish(ITestContext context)
    {
        //Auto-generated method stub

    }

}
