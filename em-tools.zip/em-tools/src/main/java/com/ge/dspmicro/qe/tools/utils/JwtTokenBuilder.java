package com.ge.dspmicro.qe.tools.utils;

/*
 * Copyright (c) 2016 General Electric Company. All rights reserved.
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

import org.apache.commons.codec.binary.Base64;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author 212069155
 */
public class JwtTokenBuilder
{
    private static Logger         _logger          = LoggerFactory.getLogger(JwtTokenBuilder.class);

    // Header keys
    /**
     * key that defines the signature algorithm used on this token
     */
    public static final String    ALG_KEY          = "alg";                                         //$NON-NLS-1$

    /**
     * RSA with SHA256 signature
     */
    public static final String    RS256_VAL        = "RS256";                                       //$NON-NLS-1$

    // Claim keys
    /**
     * issuer key
     */
    public static final String    ISS_KEY          = "iss";                                         //$NON-NLS-1$
    /**
     * subject key (clientID)
     */
    public static final String    SUB_KEY          = "sub";                                         //$NON-NLS-1$
    /**
     * audience key (UAA url)
     */
    public static final String    AUD_KEY          = "aud";                                         //$NON-NLS-1$
    /**
     * issued at key
     */
    public static final String    IAT_KEY          = "iat";                                         //$NON-NLS-1$
    /**
     * expiration key
     */
    public static final String    EXP_KEY          = "exp";                                         //$NON-NLS-1$

    private static final String   SIGNATURE_ALG    = "SHA256withRSA";                               //$NON-NLS-1$

    private static final byte[]   PERIOD           = ".".getBytes(StandardCharsets.UTF_8);          //$NON-NLS-1$

    private Map<String, String>   headers          = new HashMap<>();
    private Map<String, Object>   claims           = new HashMap<>();

    private ObjectMapper          mapper           = new ObjectMapper();

    private Signature             signature;

    private static final String[] REQUIRED_CLAIMS  =
            {
                    ISS_KEY, SUB_KEY, AUD_KEY, EXP_KEY
            };

    private static final String[] REQUIRED_HEADERS =
            {
                    ALG_KEY
            };

    @SuppressWarnings("javadoc")
    public JwtTokenBuilder(PrivateKey key)
    {
        try
        {
            this.signature = Signature.getInstance(SIGNATURE_ALG);
        }
        catch (NoSuchAlgorithmException e)
        {
            e.printStackTrace();
        }
        try
        {
            this.signature.initSign(key);
        }
        catch (InvalidKeyException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * @param value Token signature algorithm value
     * @return this
     */
    public JwtTokenBuilder setAlg(String value)
    {
        this.headers.put(ALG_KEY, value);
        return this;
    }

    /**
     * @param issuer token issuer
     * @return this
     */
    public JwtTokenBuilder setIssuer(String issuer)
    {
        this.claims.put(ISS_KEY, issuer);
        return this;
    }

    /**
     * @param subject token subject (client_id)
     * @return this
     */
    public JwtTokenBuilder setSubject(String subject)
    {
        this.claims.put(SUB_KEY, subject);
        return this;
    }

    /**
     * @param expiration expiration time
     * @return this
     */
    public JwtTokenBuilder setExpiration(long expiration)
    {
        this.claims.put(EXP_KEY, expiration);
        return this;
    }

    /**
     * @param audience UAA instance
     * @return this
     */
    public JwtTokenBuilder setAudience(String audience)
    {
        this.claims.put(AUD_KEY, audience);
        return this;
    }

    /**
     * Add an additional header entry
     *
     * @param key entry key
     * @param value entry value
     * @return this
     */
    public JwtTokenBuilder addHeader(String key, String value)
    {
        this.headers.put(key, value);
        return this;
    }

    /**
     * Add an additional claim entry
     *
     * @param key entry key
     * @param value entry value
     * @return this
     */
    public JwtTokenBuilder addClaim(String key, String value)
    {
        this.claims.put(key, value);
        return this;
    }

    /**
     * Clears all set parameters
     */
    public void reset()
    {
        this.claims.clear();
        this.headers.clear();
    }

    /**
     * @return returns the signed bearer token signed by the method. This method calls {@link #reset()} so that the builder is in a clean state
     * @throws SignatureException If the signing process fails
     * @exception IllegalStateException if any of the required claims or headers have not been set
     */
    public String buildToken()
            throws SignatureException
    {
        // important note: All of the values are explicitly listed as UTF-8 to maintain compatability between platforms
        checkState();

        try (ByteArrayOutputStream tokenBos = new ByteArrayOutputStream())
        {
            String headerStr = this.mapper.writeValueAsString(this.headers);
            tokenBos.write(Base64.encodeBase64URLSafe(headerStr.getBytes(StandardCharsets.UTF_8)));
            tokenBos.write(PERIOD);
            this.claims.put(IAT_KEY, System.currentTimeMillis() / 1000L);
            String claimStr = this.mapper.writeValueAsString(this.claims);
            tokenBos.write(Base64.encodeBase64URLSafe(claimStr.getBytes(StandardCharsets.UTF_8)));
            this.signature.update(tokenBos.toByteArray());
            byte[] tokenSig = Base64.encodeBase64URLSafe(this.signature.sign());
            tokenBos.write(PERIOD);
            tokenBos.write(tokenSig);
            reset();
            return StandardCharsets.UTF_8.newDecoder().decode(ByteBuffer.wrap(tokenBos.toByteArray())).toString();
        }
        catch (IOException e)
        {
            _logger.error("Error serializing fields to JSON", e); //$NON-NLS-1$
        }

        return null;
    }

    // throws illegal argument exception if not all required parameters are set
    private void checkState()
    {
        List<String> missingKeys = new ArrayList<>(REQUIRED_CLAIMS.length + REQUIRED_HEADERS.length + 1);
        for (String header : REQUIRED_HEADERS)
        {
            if ( !this.headers.containsKey(header) )
            {
                missingKeys.add(header);
            }
        }
        for (String claim : REQUIRED_CLAIMS)
        {
            if ( !this.claims.containsKey(claim) )
            {
                missingKeys.add(claim);
            }
        }
        if ( missingKeys.size() > 0 )
        {
            StringBuilder missing = new StringBuilder();
            missing.append(missingKeys.get(0));
            for (int i = 1; i < missingKeys.size(); i++)
            {
                missing.append(',');
                missing.append(' ');
                missing.append(missingKeys.get(i));
            }
            throw new IllegalStateException("Missing claims in JWT token builder"); //$NON-NLS-1$
        }
    }

}
