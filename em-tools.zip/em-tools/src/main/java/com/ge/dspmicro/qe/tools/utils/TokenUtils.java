/*
 * Copyright (c) 2012 - 2018 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.tools.utils;

import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Header;
import com.jayway.restassured.response.Response;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import java.nio.charset.StandardCharsets;
import java.util.Map;

import static com.jayway.restassured.RestAssured.given;

/**
 * 
 * @author 212547153
 */

@SuppressWarnings(
        {
            "javadoc", "nls"
        })
public class TokenUtils
{

    private static final Logger _logger = LoggerFactory.getLogger(TokenUtils.class);

    public static Token getUAAToken(String uaaUrl, String clientId, String clientSecret,
            Map<String, String> queryParams)
    {
        String base64Secret = "";
        base64Secret = Base64.encodeBase64String((clientId + ':' + clientSecret).getBytes(StandardCharsets.UTF_8));
//        Base64.encodeBase64String((clientId+":"+clientSecret).getBytes(StandardCharsets.UTF_8));
        Header header1 = new Header("Content-Type", "application/x-www-form-urlencoded");
        Header header2 = new Header("Authorization", "Basic " + base64Secret);
        Response response = given().header(header1).header(header2).relaxedHTTPSValidation().queryParams(queryParams)
                .post(uaaUrl + "/oauth/token");

        JsonPath jsonPath = response.jsonPath();
        Token token = new Token();
        token.setAccessToken(jsonPath.getString(Token.ACCESS_TOKEN));
        token.setTokenType(jsonPath.getString(Token.TOKEN_TYPE));
        token.setExpiresIn(jsonPath.getLong(Token.EXPIRES_IN));
        token.setScope(jsonPath.getString(Token.SCOPE));
        token.setJti(jsonPath.getString(Token.JTI));
        String refreshToken = jsonPath.getString(Token.REFRESH_TOKEN);
        if (refreshToken != null && !refreshToken.isEmpty()) {
            token.setRefreshToken(refreshToken);
        }

        if (token == null || StringUtils.isEmpty(token.getAccessToken()))
        {
            _logger.warn("Failed to get UAA token for {}. Response: {}", header2, response.getStatusLine());
            response.getBody().print();
        }

        return token;
    }

    /**
     * get token for EdgeManager user (technician, operator, admin etc.)
     * 
     * @param uaaUrl
     * @param clientId EdgeManager clientId
     * @param clientSecret EdgeManager clientSecret
     * @param queryParams grant_type=password&username=ROAR5&password=change22me
     * @return
     */
    public static Token getUserUAAToken(String uaaUrl, String clientId, String clientSecret, Map<String, Object> queryParams)
    {
        String base64Secret = "";
        base64Secret = Base64.encodeBase64String((clientId + ':' + clientSecret).getBytes(StandardCharsets.UTF_8));
        Header header1 = new Header("Content-Type", "application/x-www-form-urlencoded");
        Header header2 = new Header("Authorization", "Basic " + base64Secret);
        Response response = given().header(header1).header(header2).relaxedHTTPSValidation().queryParams(queryParams)
                .post(uaaUrl + "/oauth/token");

        JsonPath jsonPath = response.jsonPath();
        Token token = new Token();
        token.setAccessToken(jsonPath.getString(Token.ACCESS_TOKEN));
        token.setTokenType(jsonPath.getString(Token.TOKEN_TYPE));
        token.setExpiresIn(jsonPath.getLong(Token.EXPIRES_IN));
        token.setScope(jsonPath.getString(Token.SCOPE));
        token.setJti(jsonPath.getString(Token.JTI));
        String refreshToken = jsonPath.getString(Token.REFRESH_TOKEN);
        if (refreshToken != null && !refreshToken.isEmpty()) {
            token.setRefreshToken(refreshToken);
        }

        return token;
    }
}
