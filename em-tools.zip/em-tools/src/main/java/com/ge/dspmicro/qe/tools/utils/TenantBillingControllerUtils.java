/*
 * Copyright (c) 2012 - 2017 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.tools.utils;

import com.ge.dspmicro.qe.tools.environment.Configuration;
import com.jayway.restassured.response.Response;

/**
 * 
 * @author 212547153
 */

@SuppressWarnings(
{
        "javadoc", "nls"
})

public class TenantBillingControllerUtils
{

    private static Configuration cfg = Configuration.getConfig();

    // POST /svc/tenant/v1/usage Report usage for specified tenant List
    public static Response reportUsage(String tenantList) // TODO remove this API from cloud-qe as it has been deprecated from edge manager.
    {
        return RestClient.postWithToken(cfg.getEdgeManagerUrl().replaceAll(cfg.getTenantId() + ".", ""),
                "/svc/tenant/v1/usage", tenantList, cfg.getTenantMgrToken());
    }

    // POST /svc/tenant/v1/usage/all Retrieve usage for specified tenant.Returns a map of tenantId and usage. Negative usage means error getting usage data.
    // GET /svc/tenant/v1/usage/{tenantId} Retrieve usage for specified tenant
    public static Response getUsageForTenant()
    {
        return RestClient.getWithToken(cfg.getEdgeManagerUrl().replaceAll(cfg.getTenantId() + ".", ""),
                "/svc/tenant/v1/usage/" + cfg.getTenantId(), null, cfg.getTenantMgrToken());
    }

    // GET /svc/tenant/v1/billing/devices Retrieve Billing data for specified tenant
    public static Response getBillingStats()
    {
        return RestClient.getWithToken(cfg.getEdgeManagerUrl().replaceAll(cfg.getTenantId() + ".", ""),
                "/svc/tenant/v1/billing/devices/", null, cfg.getTenantMgrToken());
    }
}
