/*
 * Copyright (c) 2017 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.tools.utils;

import com.ge.dspmicro.qe.tools.environment.Configuration;
import com.jayway.restassured.response.Response;
import org.apache.commons.io.IOUtils;
import org.bouncycastle.openssl.jcajce.JcaPEMWriter;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.OperatorCreationException;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import org.bouncycastle.pkcs.PKCS10CertificationRequest;
import org.bouncycastle.pkcs.PKCS10CertificationRequestBuilder;
import org.bouncycastle.pkcs.jcajce.JcaPKCS10CertificationRequestBuilder;
import org.bouncycastle.util.io.pem.PemObject;

import javax.security.auth.x500.X500Principal;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.apache.commons.codec.binary.Base64.encodeBase64;

/**
 * 
 * @author 212547153
 */

@SuppressWarnings(
        {
            "javadoc", "nls"
        })
public class CommonUtils
{
    private static final String CSR_ALG               = "SHA256withRSA";
    private static final String X500_PRINCIPAL_PREFIX = "OU=digital, O=GE, L=San Ramon, ST=CA, C=US, CN=";

    public static String getTimeStamp_yyyy_MM_dd_HH_mm_ss()
    {
        return new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss").format(new Date());

    }

    public static String getTimeStamp_yyyy_MM_dd_HH_mm_ss_SSS()
    {
        return new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss_SSS").format(new Date());

    }

    public static String getTimeStamp_HH_mm_ss_yyyy_MM_dd()
    {
        return new SimpleDateFormat("HH-mm-ss-yyyy-MM-dd").format(new Date());

    }

    public static String getTimeStamp_HH_mm_ss_SSS_yyyy_MM_dd()
    {
        return new SimpleDateFormat("HH-mm-ss-SSS-yyyy-MM-dd").format(new Date());

    }

    @SuppressWarnings("unchecked")
    public static List<Map<String, String>> readCSVtoMap(String csvFileName)
            throws IOException
    {
        List<Map<String, String>> testData = new ArrayList<>();

        // read file line by line

        List<String> csvLines = IOUtils.readLines(CommonUtils.getResourceAsInputStream(csvFileName));
        String[] keys = null;
        if ( !csvLines.isEmpty() && csvLines.size() >= 2 )
        {
            keys = csvLines.get(0).split(",");
        }
        if ( keys != null )
        {
            for (int i = 1; i < csvLines.size(); i++)
            {
                String[] values = csvLines.get(i).split(",");
                Map<String, String> dataSet = new HashMap<>();
                // add key and values to map
                for (int j = 0; j < values.length; j++)
                {
                    dataSet.put(keys[j], values[j].trim());
                }

                if ( dataSet.get("isEnabled").toLowerCase().equals("true") )
                {
                    testData.add(dataSet);
                }
            }
        }
        return testData;
    }

    public static InputStream getResourceAsInputStream(String fileName)
    {
        InputStream inputStream = CommonUtils.class.getResourceAsStream(fileName);
        return inputStream;
    }

    public static String getResourceAsString(String fileName)
    {
        try
        {
            return IOUtils.toString(CommonUtils.class.getResourceAsStream(fileName));
        }
        catch (IOException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }

    public static String getEncodedCSR(KeyPair kp, String deviceId)
            throws IOException, OperatorCreationException
    {
        return Base64.getEncoder().encodeToString(generateCSR(kp, deviceId).getBytes());
    }

    public static boolean isFeatureEnabled(String featureName)
    {
        return Configuration.getConfig().getAvailableFeatures().contains(featureName);

    }

    /**
     * Returns decoded JWT Token string
     * 
     * @param jwtToken token
     * @return
     */
    public static String getDecodedJwt(String jwtToken)
    {
        String decodedToken = "";

        String encodedToken = jwtToken.split("[.]")[1]; // get second index.
        try
        {

            byte[] partAsBytes = encodedToken.getBytes(StandardCharsets.UTF_8);
            decodedToken = new String(java.util.Base64.getUrlDecoder().decode(partAsBytes), StandardCharsets.UTF_8);
        }
        catch (Exception e)
        {
            throw new RuntimeException("Couldnt decode jwt", e);
        }

        return decodedToken;
    }

    public static boolean isUuidValid(String uuid)
    {
        return uuid.matches("^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$");
    }
    /**
     * Validates if the location header has valid uuid
     * 
     * @param uri
     * @param locationHeader
     * @return boolean
     */
    public static boolean isLocationHeaderValid(String uri, String locationHeader)
    {
        return locationHeader
                .matches("^" + uri + "[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$");
    }

    private static String generateCSR(KeyPair kp, String deviceId)
            throws OperatorCreationException, IOException
    {

        ContentSigner signGen = new JcaContentSignerBuilder(CSR_ALG).build(kp.getPrivate());

        // 3. Create CSR
        PKCS10CertificationRequestBuilder builder = new JcaPKCS10CertificationRequestBuilder(getX500Principal(deviceId),
                kp.getPublic());
        PKCS10CertificationRequest pkcs10Request = builder.build(signGen);

        PemObject pemObject = new PemObject("CERTIFICATE REQUEST", pkcs10Request.getEncoded());
        try (StringWriter strWriter = new StringWriter(); JcaPEMWriter pemWriter = new JcaPEMWriter(strWriter))
        {
            pemWriter.writeObject(pemObject);
            pemWriter.flush();
            return strWriter.toString();
        }
    }

    /**
     * Validates if string is lower case
     * 
     * @param string to be tested
     * @return
     */
    public static boolean isLowerCase(String str)
    {
        String regex = "[a-z\\-]+";

        Pattern pattern = Pattern.compile(regex);

        Matcher matcher = pattern.matcher(str);
        return matcher.matches();
    }

    /**
     * Save response to a file
     * 
     * @param Response
     * @param fileName
     * @return
     * @throws IOException
     */
    public static void writeResponseToFile(Response response, String fileName)
            throws IOException
    {
        // save config to file
        InputStream initialStream = response.asInputStream();
        File targetFile = new File(fileName);
        OutputStream outStream = new FileOutputStream(targetFile);

        byte[] buffer = new byte[8 * 1024];
        int bytesRead;
        while ((bytesRead = initialStream.read(buffer)) != -1)
        {
            outStream.write(buffer, 0, bytesRead);
        }
        IOUtils.closeQuietly(initialStream);
        IOUtils.closeQuietly(outStream);
    }

    private static X500Principal getX500Principal(String deviceId)
    {
        return new X500Principal(X500_PRINCIPAL_PREFIX + deviceId);
    }

    // helper method to read image file as base64 encoded string
    public static String encodeFileToBase64Binary(InputStream inputStream)
    {
        String encodedfile = null;
        try
        {
            byte[] bytes = IOUtils.toByteArray(inputStream);
            encodedfile = new String(encodeBase64(bytes), StandardCharsets.UTF_8);
        }
        catch (FileNotFoundException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        catch (IOException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return encodedfile;
    }
}
