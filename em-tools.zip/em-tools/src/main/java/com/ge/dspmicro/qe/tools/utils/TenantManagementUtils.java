/*
 * Copyright (c) 2012 - 2018 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.tools.utils;

import com.ge.dspmicro.qe.tools.environment.Configuration;
import com.jayway.restassured.response.Response;

/**
 * 
 * @author 212547153
 */
@SuppressWarnings(
        {
            "javadoc", "nls"
        })

public class TenantManagementUtils
{
    private static Configuration cfg     = Configuration.getConfig();
    private static Token        token   = cfg.getAdminUAAToken();

    // GET /svc/tenant/v1/features Returns a list of features for a tenant.
    public static Response getFeatureListForTenant()
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), "/svc/tenant/v1/features", null, token);
    }

    // HEAD /svc/tenant/v1/features Retrieve HEAD information for feature toggles
    public static Response getHeadInfoForFeatureToggle()
    {
        return RestClient.head(cfg.getEdgeManagerUrl(), "/svc/tenant/v1/features", null, token);
    }

    // GET /svc/tenant/v1/features/{key} Returns the value of a feature for a tenant.
    public static Response getFeatureKey(String key)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), "/svc/tenant/v1/features/" + key, null, token);
    }

    // GET /svc/tenant/v1/service-instances Returns list of the services for a tenant.
    public static Response getServices()
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), "/svc/tenant/v1/service-instances", null, token);
    }

    // PUT /svc/tenant/v1/featuretoggles/{tenantId}/{key} Sets the value of a feature toggle for a tenant.
    public static Response setFeatureToggleValueForTenant(String tenantId, String key, String payload)
    {
        // endpoint is for super admins...
        return RestClient.put(cfg.getEdgeManagerUrl().replace(tenantId + ".", ""),
                "/svc/tenant/v1/featuretoggles/" + tenantId + "/" + key,
                payload, token);
    }

    public void setToken(Token token) {
        TenantManagementUtils.token = token;
    }

    public Token getToken() {
        return TenantManagementUtils.token;
    }
}
