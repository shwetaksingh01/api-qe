/*
 * Copyright (c) 2019 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.tools.utils;

import static com.jayway.restassured.RestAssured.given;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Header;
import com.jayway.restassured.response.Response;

/**
 * @author 212775111
 * The class file handles the get and post request of QTest APIs
 */

@SuppressWarnings({"javadoc", "nls"
}) public class QTestRestClient
{
    private static final Logger _logger = LoggerFactory.getLogger(QTestRestClient.class);

    private static void logRequestURL(String url, String path)
    {

        StackTraceElement[] stacktrace = Thread.currentThread().getStackTrace();
        StackTraceElement e = stacktrace[3];// maybe this number needs to be corrected
        String methodName = e.getMethodName();
        _logger.info(String.format("\t%s : %s%s", methodName, url, path));
    }

    private static void logResponseBodyAndStatusCode(Response response)
    {
        String callingMethodName = Thread.currentThread().getStackTrace()[3].getMethodName();
        _logger.info(String.format("\t%s response code: %d", callingMethodName, response.statusCode()));
        if ( callingMethodResponseBodyShouldBeHidden(callingMethodName) )
        {
            _logger.info(
                    String.format("\t%s response body: [Not intended to be printed as string]", callingMethodName));
        }
        else
        {
            _logger.info(String.format("\t%s response body: %s", callingMethodName, sanitizeResponse(response)));
        }
    }

    private static boolean callingMethodResponseBodyShouldBeHidden(String methodName)
    {
        // response body of these methods result in corrupted text and should not be displayed as string.
        List skipMethodNameList = Arrays
                .asList("downloadAppPackage", "getAllBaselineConfigPackages", "getAvailableAppPackages",
                        "exportDevicesToCsv", "exportDevicesToCsvV1", "getBaselinePkg", "getBaselinePkgV2",
                        "getBaselinePkgV1", "downloadPackage", "downloadPackageV1", "downloadDeploymentTaskOutput",
                        "downloadDeploymentTaskOutputV1", "getDeviceModelImage", "getDeviceModelImageV1");

        return skipMethodNameList.contains(methodName);
    }

    private static String sanitizeResponse(Response response)
    {
        return response.asString()
                .replaceAll("\"access_token\":\".*\",\"token_type\"", "\"access_token\":\"******\",\"token_type\"");
    }

    public static Response qtestPost(String hostUrl, String uri, String payload, String token)
    {
        Header authHeader = new Header("Authorization", "Bearer " + token);
        logRequestURL(hostUrl, uri);
        Response response = given().header(authHeader).contentType(ContentType.JSON).relaxedHTTPSValidation()
                .body(payload).when().post(hostUrl + uri).then().extract().response();
        logResponseBodyAndStatusCode(response);
        return response;
    }

    public static Response qtestGet(String hostUrl, String uri, String token)
    {
        Header authHeader = new Header("Authorization", "Bearer " + token);
        Response response = given().header(authHeader).contentType(ContentType.JSON).relaxedHTTPSValidation()
                .queryParameters(new HashMap<>()).when().get(hostUrl + uri).then().extract().response();
        logResponseBodyAndStatusCode(response);
        return response;
    }
}
