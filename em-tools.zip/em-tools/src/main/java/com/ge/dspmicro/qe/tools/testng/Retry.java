/*
 * Copyright (c) 2012 - 2017 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.tools.testng;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;


/**
 * 
 * @author 212547153
 */
@SuppressWarnings("nls")
public class Retry
implements IRetryAnalyzer
{
    private static final Logger _logger = LoggerFactory.getLogger(IRetryAnalyzer.class);
    private int                 retryCount    = 0;
    private static int          maxRetryCount = 2;

    @SuppressWarnings("javadoc")
    public boolean isRetryAvailable()
    {
        return this.retryCount < maxRetryCount;
    }

    @Override
    public boolean retry(ITestResult result)
    {
        // if ( this.retryCount < maxRetryCount && !result.isSuccess() )
        // {
        // result.setStatus(ITestResult.SUCCESS);
        // _logger.info("\tRETRYING............");
        // _logger.info("\tError in "
        // + result.getName() + " Retrying "
        // + (maxRetryCount + 1 - this.retryCount) + " more times");
        // this.retryCount++;
        // return true;
        // }
        // result.setStatus(ITestResult.FAILURE);
        return false;
    }

}