/*
 * Copyright (c) 2012 - 2018 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.tools.utils;

import static com.jayway.restassured.RestAssured.given;

import java.io.IOException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.ws.rs.core.MultivaluedHashMap;

import org.bouncycastle.operator.OperatorCreationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import com.ge.dspmicro.qe.tools.environment.Configuration;
import com.jayway.restassured.response.Header;
import com.jayway.restassured.response.Response;

/**
 * 
 * @author 212547153
 */
@SuppressWarnings(
{
        "javadoc", "nls"
})
public class DeviceManagementUtils
{
    private static final Logger _logger       = LoggerFactory.getLogger(DeviceManagementUtils.class);
    private static final String KEY_ALG       = "RSA";
    private static final String SHARED_SECRET = "sharedsecret";
    private static final String DEVICE_URI_V2 = "/svc/device/v2/device-mgmt/devices";

    // "OAuth enrollment is no longer supported; use v2 cert enrollment instead."
    @Deprecated
    public static HashMap<String, String> enrollDeviceV1(String deviceId, String activationCode, String techId,
            String techPassword)
    {
        Configuration cfg = Configuration.getConfig();
        Token token = cfg.getAdminUAAToken();
        // send token request
        String clientId = "PM_CLIENT-" + deviceId + "-ENROLL";
        String clientSecret = activationCode;
        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("username", techId);
        queryParams.put("password", techPassword);
        queryParams.put("grant_type", "password");
        if ( token == null )
        {
            token = TokenUtils.getUAAToken(cfg.getUaaUrl(), clientId, clientSecret, queryParams);
        }

        // Send enrollment request
        Header authHeader = new Header("Authorization", token.getTokenType() + " " + token.getAccessToken());
        Header contentType = new Header("Content-Type", "application/x-www-form-urlencoded");
        Header noCache = new Header("Cache-Control", "no-cache");
        Response response = given().header(authHeader).header(contentType).header(noCache)
                .queryParam("deviceId", deviceId).relaxedHTTPSValidation()
                .post(cfg.getEdgeManagerUrl() + "/svc/device/v1/enroll");

        // put device credentials in a map and return
        HashMap<String, String> deviceCredentials = new HashMap<>();
        deviceCredentials.put("clientIdUaa", response.jsonPath().getString("clientId"));
        deviceCredentials.put("clientSecretUaa", response.jsonPath().getString("clientSecret"));

        return deviceCredentials;

    }

    public static CertEnrolledDeviceInfo enrollDeviceUsingCertificate(String deviceId, String sharedSecret)
    {

        return enrollPredixMachineDevice(deviceId, sharedSecret, false);
    }

    public static CertEnrolledDeviceInfo enrollDockerEnabledDeviceUsingCertificate(String deviceId, String sharedSecret)
    {
        return enrollPredixMachineDevice(deviceId, sharedSecret, true);
    }

    public static CertEnrolledDeviceInfo enrollPredixMachineDevice(String deviceId, String sharedSecret,
            Boolean isDockerEnabled)
    {
        KeyPair keypair = null;
        String csr;
        KeyPairGenerator keyGen = null;
        try
        {
            keyGen = KeyPairGenerator.getInstance(KEY_ALG);
            keyGen.initialize(2048);
            keypair = keyGen.generateKeyPair();
        }
        catch (NoSuchAlgorithmException e)
        {
            _logger.error(e.getMessage(), e);
        }

        String enrollmentPayload = "{\"deviceId\":\"$did\",\"macAddr\":\"unknown\",\"tenantId\":\"$tenantId\",\"sharedSecret\":\"$sharedSecret\",\"csr\":\"$csr\",\"serialNo\":\"test-serialno\",\"dockerEnabled\":$isDockerEnabled}";
        enrollmentPayload = enrollmentPayload.replaceAll("\\$did", deviceId);
        enrollmentPayload = enrollmentPayload.replaceAll("\\$sharedSecret", sharedSecret);
        enrollmentPayload = enrollmentPayload.replaceAll("\\$tenantId", Configuration.getConfig().getTenantId());
        enrollmentPayload = enrollmentPayload.replaceAll("\\$isDockerEnabled", Boolean.toString(isDockerEnabled));
        try
        {
            csr = CommonUtils.getEncodedCSR(keypair, deviceId);
            enrollmentPayload = enrollmentPayload.replaceAll("\\$csr", csr);
        }
        catch (OperatorCreationException | IOException e)
        {
            _logger.error("\tFailed to generate csr", e);
        }

        _logger.info("\tEnrolling device: " + deviceId);

        Response response = RestClient.post(Configuration.getConfig().getEdgeManagerUrl(), "/svc/device/v2/enroll",
                enrollmentPayload, Configuration.getConfig().getAdminUAAToken());
        response.then().assertThat().statusCode(200);

        String clientID = response.jsonPath().getString("clientId");
        String deviceUUID = RestClient
                .get(Configuration.getConfig().getEdgeManagerUrl(), "/svc/device/v1/device-mgmt/devices/" + deviceId,
                        new MultivaluedHashMap<String, String>(), Configuration.getConfig().getAdminUAAToken())
                .jsonPath().getString("deviceUUID");
        CertEnrolledDeviceInfo certEnrolledDeviceInfo = new CertEnrolledDeviceInfo();

        certEnrolledDeviceInfo.setDeviceId(deviceId);
        certEnrolledDeviceInfo.setKeyPair(keypair);
        certEnrolledDeviceInfo.setClientID(clientID);
        certEnrolledDeviceInfo.setDeviceUUID(deviceUUID);
        return certEnrolledDeviceInfo;
    }

    /**
     * enroll an edge agent device with the given deviceId and sharedSecret
     *
     * @param deviceId deviceId
     * @param sharedSecret sharedSecret
     * @return CertEnrolledDeviceInfo
     */

    public static CertEnrolledDeviceInfo enrollEdgeAgentDevice(String deviceId, String sharedSecret)
    {
        KeyPair keypair = null;
        String csr;
        KeyPairGenerator keyGen = null;
        try
        {
            keyGen = KeyPairGenerator.getInstance(KEY_ALG);
            keyGen.initialize(2048);
            keypair = keyGen.generateKeyPair();
        }
        catch (NoSuchAlgorithmException e)
        {
            _logger.error(e.getMessage(), e);
        }

        Map<String, String> edge_enroll_headers = new HashMap<>();
        _logger.info("ENROLLING EDGE AGENT DEVICE " + deviceId + " " + sharedSecret);
        edge_enroll_headers.put("Authorization",
                "Bearer " + Configuration.getConfig().getAdminUAAToken().getAccessToken());
        edge_enroll_headers.put("User-Agent", "EdgeAgent/1.0");

        String enrollmentPayload = "{\"deviceId\":\"$did\",\"macAddr\":\"unknown\",\"tenantId\":\"$tenantId\",\"sharedSecret\":\"$sharedSecret\",\"csr\":\"$csr\",\"serialNo\":\"test-serialno\",\"dockerEnabled\":false}";
        enrollmentPayload = enrollmentPayload.replaceAll("\\$did", deviceId);
        enrollmentPayload = enrollmentPayload.replaceAll("\\$sharedSecret", sharedSecret);
        enrollmentPayload = enrollmentPayload.replaceAll("\\$tenantId", Configuration.getConfig().getTenantId());

        try
        {
            csr = CommonUtils.getEncodedCSR(keypair, deviceId);
            enrollmentPayload = enrollmentPayload.replaceAll("\\$csr", csr);
        }
        catch (OperatorCreationException | IOException e)
        {
            _logger.error("\tFailed to generate csr", e);
        }

        _logger.info("\tEnrolling device: " + deviceId);

        Response response = RestClient.postJsonWithCustomHeaders(Configuration.getConfig().getEdgeManagerUrl(),
                "/svc/device/v2/enroll", enrollmentPayload, edge_enroll_headers);
        response.then().assertThat().statusCode(200);

        String clientID = response.jsonPath().getString("clientId");
        String deviceUUID = RestClient
                .get(Configuration.getConfig().getEdgeManagerUrl(), "/svc/device/v1/device-mgmt/devices/" + deviceId,
                        new MultivaluedHashMap<String, String>(), Configuration.getConfig().getAdminUAAToken())
                .jsonPath().getString("deviceUUID");
        CertEnrolledDeviceInfo certEnrolledDeviceInfo = new CertEnrolledDeviceInfo();

        certEnrolledDeviceInfo.setDeviceId(deviceId);
        certEnrolledDeviceInfo.setKeyPair(keypair);
        certEnrolledDeviceInfo.setClientID(clientID);
        certEnrolledDeviceInfo.setDeviceUUID(deviceUUID);
        return certEnrolledDeviceInfo;
    }

    /**
     * @param payload payload
     * @return Response
     */
    public static Response addDeviceV2UsingDeviceId(String deviceId)
    {
        String payload = "{\"modelID\":\"FieldAgent\",\"groupId\":\"0\",\"name\":\"$did\",\"did\":\"$did\",\"sharedSecret\":\"$sharedSecret\"}";
        payload = payload.replaceAll("\\$did", deviceId);
        payload = payload.replaceAll("\\$sharedSecret", SHARED_SECRET);
        _logger.info("\tAddDevicePayLoad: " + payload);
        Response response = addDeviceV2(payload);
        return response;
    }

    public static Response addDeviceV2(String payload)
    {
        _logger.info("\tAddDeviceV2 payload: " + payload);
        return RestClient.post(Configuration.getConfig().getEdgeManagerUrl(), DEVICE_URI_V2, payload,
                Configuration.getConfig().getAdminUAAToken());
    }

    /**
     * @param deviceId device ID
     * @return CertEnrolledDeviceInfo CertEnrolledDeviceInfo
     */
    public static CertEnrolledDeviceInfo addAndEnrollPredixMachineDevice(String deviceId)
            throws InterruptedException
    {
        Response response = addDeviceV2UsingDeviceId(deviceId);
        Assert.assertEquals(response.statusCode(), 201, "Create device expected response code does not match.");
        TimeUnit.SECONDS.sleep(2);
        CertEnrolledDeviceInfo certEnrolledDeviceInfo = DeviceManagementUtils.enrollDeviceUsingCertificate(deviceId,
                SHARED_SECRET);
        Assert.assertEquals(certEnrolledDeviceInfo.getDeviceId(), deviceId);

        return certEnrolledDeviceInfo;
    }

}
