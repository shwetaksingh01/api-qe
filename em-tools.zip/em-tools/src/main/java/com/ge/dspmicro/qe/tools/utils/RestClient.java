/*
 * Copyright (c) 2018 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.tools.utils;

import static com.jayway.restassured.RestAssured.given;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.MediaType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.dspmicro.qe.tools.environment.Configuration;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Header;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;

/**
 * @author 212547153
 */

@SuppressWarnings({"javadoc", "nls"
}) public class RestClient
{
    private static final Logger _logger = LoggerFactory.getLogger(RestClient.class);

    private static Header gzipEncodingHeader = new Header("Accept-Encoding", "gzip");

    public static Response get(String hostUrl, String uri, Map<String, ?> queryParams, Token token)
    {
        logRequestURL(hostUrl, uri);
        Header authHeader = new Header("Authorization", "Bearer " + token.getAccessToken());
        Response response;
        if ( queryParams == null )
        {

            response = given().header(authHeader).contentType(ContentType.JSON).relaxedHTTPSValidation()
                    .queryParameters(new HashMap<>()).when().get(hostUrl + uri).then().extract().response();
        }
        else
        {
            response = given().header(authHeader).contentType(ContentType.JSON).relaxedHTTPSValidation()
                    .queryParams(queryParams).when().get(hostUrl + uri).then().extract().response();
        }
        logResponseBodyAndStatusCode(response);
        return response;
    }

    public static Response getTextPlain(String hostUrl, String uri, Map<String, ?> queryParams, Token token)
    {
        logRequestURL(hostUrl, uri);
        Header authHeader = new Header("Authorization", "Bearer " + token.getAccessToken());
        Response response;
        if ( queryParams == null )
        {

            response = given().header(authHeader).contentType(ContentType.TEXT).relaxedHTTPSValidation()
                    .queryParameters(new HashMap<>()).when().get(hostUrl + uri).then().extract().response();
        }
        else
        {
            response = given().header(authHeader).contentType(ContentType.TEXT).relaxedHTTPSValidation()
                    .queryParams(queryParams).when().get(hostUrl + uri).then().extract().response();
        }
        logResponseBodyAndStatusCode(response);
        return response;
    }

    public static Response post(String hostUrl, String uri, String payload, Token token)
    {
        Header authHeader = new Header("Authorization", "Bearer " + token.getAccessToken());
        logRequestURL(hostUrl, uri);
        Response response = given().header(authHeader).contentType(ContentType.JSON).relaxedHTTPSValidation()
                .body(payload).when().post(hostUrl + uri).then().extract().response();
        logResponseBodyAndStatusCode(response);
        return response;
    }

    public static Response postOctetWithToken(String url, byte[] body, String token)
    {
        Header authHeader = new Header("Authorization", "Bearer " + token);
        Response response = given().header(authHeader).content(MediaType.APPLICATION_OCTET_STREAM_TYPE)
                .relaxedHTTPSValidation().body(body).when().post(url).then().extract().response();
        logResponseBodyAndStatusCode(response);
        return response;
    }

    /**
     * the post method that takes in a JSON body plus a list of supplied headers
     *
     * @param hostUrl hostUrl
     * @param uri     uri
     * @param payload payload
     * @param headers headers
     * @return Response
     */
    public static Response postJsonWithCustomHeaders(String hostUrl, String uri, String payload,
            Map<String, String> headers)
    {
        RequestSpecification spec = given();
        for (Map.Entry<String, String> header : headers.entrySet())
        {
            spec.header(new Header(header.getKey(), header.getValue()));
        }
        logRequestURL(hostUrl, uri);
        Response response = spec.contentType(ContentType.JSON).relaxedHTTPSValidation().body(payload).when()
                .post(hostUrl + uri).then().extract().response();
        logResponseBodyAndStatusCode(response);
        return response;
    }

    public static Response postWithMultiPart(String hostUrl, String uri, String fileName, Token token)
    {
        Header authHeader = new Header("Authorization", "Bearer " + token.getAccessToken());
        logRequestURL(hostUrl, uri);
        Response response = given().header(authHeader).contentType(ContentType.JSON).header(gzipEncodingHeader)
                .relaxedHTTPSValidation().multiPart("file", new File(fileName)).contentType("multipart/form-data")
                .when().post(hostUrl + uri).then().extract().response();
        logResponseBodyAndStatusCode(response);
        return response;
    }

    public static Response putWithMultiPart(String hostUrl, String uri, String fileName, Token token)
    {
        Header authHeader = new Header("Authorization", "Bearer " + token.getAccessToken());
        logRequestURL(hostUrl, uri);
        Response response = given().header(authHeader).contentType(ContentType.JSON).header(gzipEncodingHeader)
                .relaxedHTTPSValidation().multiPart("file", new File(fileName)).contentType("multipart/form-data")
                .when().put(hostUrl + uri).then().extract().response();
        logResponseBodyAndStatusCode(response);
        return response;
    }

    public static Response postWithMultiPart(String hostUrl, String uri, Map<String, ?> queryParams,
            Map<String, ?> formParams, String fileName, Token token)
    {
        Header authHeader = new Header("Authorization", "Bearer " + token.getAccessToken());
        logRequestURL(hostUrl, uri);
        Response response = given().header(authHeader).contentType(ContentType.JSON).header(gzipEncodingHeader)
                .relaxedHTTPSValidation().queryParams(queryParams).formParameters(formParams)
                .multiPart("file", new File(fileName)).contentType("multipart/form-data").when().post(hostUrl + uri)
                .then().extract().response();
        logResponseBodyAndStatusCode(response);
        return response;
    }

    public static Response postWithParams(String hostUrl, String uri, Map<String, ?> queryParams, Token token)
    {
        Header authHeader = new Header("Authorization", "Bearer " + token.getAccessToken());
        logRequestURL(hostUrl, uri);
        Response response = given().header(authHeader).contentType(ContentType.JSON).relaxedHTTPSValidation()
                .queryParameters(queryParams).when().post(hostUrl + uri).then().extract().response();
        logResponseBodyAndStatusCode(response);
        return response;
    }

    public static Response postWithParams(String hostUrl, String uri, Map<String, ?> queryParams, String payload,
            Token token)
    {
        Header authHeader = new Header("Authorization", "Bearer " + token.getAccessToken());
        logRequestURL(hostUrl, uri);
        Response response = given().header(authHeader).contentType(ContentType.JSON).relaxedHTTPSValidation()
                .body(payload).queryParameters(queryParams).when().post(hostUrl + uri).then().extract().response();
        logResponseBodyAndStatusCode(response);
        return response;
    }

    public static Response postWithParamsTextContent(String hostUrl, String uri, Map<String, ?> queryParams,
            Token token)
    {
        Header authHeader = new Header("Authorization", "Bearer " + token.getAccessToken());
        logRequestURL(hostUrl, uri);
        Response response = given().header(authHeader).contentType(ContentType.TEXT).relaxedHTTPSValidation()
                .queryParameters(queryParams).when().post(hostUrl + uri).then().extract().response();
        logResponseBodyAndStatusCode(response);
        return response;
    }

    public static Response postUrlEncodedFormWithoutAuthHeader(String hostUrl, String uri, Map<String, ?> formParams)
    {
        logRequestURL(hostUrl, uri);
        Response response = given().contentType(ContentType.URLENC).header(gzipEncodingHeader).relaxedHTTPSValidation()
                .formParams(formParams).when().post(hostUrl + uri).then().extract().response();
        logResponseBodyAndStatusCode(response);
        return response;
    }

    public static Response postBinaryWithCustomHeaders(String hostUrl, String uri, Map<String, String> headers,
            byte[] body)
    {
        logRequestURL(hostUrl, uri);
        RequestSpecification spec = given();
        for (Map.Entry<String, String> header : headers.entrySet())
        {
            spec.header(new Header(header.getKey(), header.getValue()));
        }
        Response response = spec.contentType(ContentType.BINARY).relaxedHTTPSValidation().body(body).when()
                .post(hostUrl + uri).then().extract().response();
        logResponseBodyAndStatusCode(response);
        return response;
    }

    public static Response put(String hostUrl, String uri, String payload, Token token)
    {
        logRequestURL(hostUrl, uri);
        Header authHeader = new Header("Authorization", "Bearer " + token.getAccessToken());
        Response response = given().header(authHeader).contentType(ContentType.JSON).relaxedHTTPSValidation()
                .body(payload).when().put(hostUrl + uri).then().extract().response();
        logResponseBodyAndStatusCode(response);
        return response;
    }

    public static Response postWithMultipart(String hostUrl, String uri, Map<String, Object> formParams,
            String fileName, Token token)
    {
        Header authHeader = new Header("Authorization", "Bearer " + token.getAccessToken());
        Response response = given().header(authHeader).contentType(ContentType.JSON).header(gzipEncodingHeader)
                .relaxedHTTPSValidation().formParameters(formParams).multiPart("file", new File(fileName))
                .contentType("multipart/form-data").when().post(hostUrl + uri).then().extract().response();
        logResponseBodyAndStatusCode(response);
        return response;
    }

    public static Response putWithMultipartChunked(String hostUrl, String uri, String fileName, Token token)
    {
        Header authHeader = new Header("Authorization", "Bearer " + token.getAccessToken());
        Header chunkNumber = new Header("Chunk-Number", "1");
        Response response = given().header(authHeader).contentType(ContentType.BINARY).relaxedHTTPSValidation()
                .header(chunkNumber).body(new File(fileName)).when().put(hostUrl + uri).then().extract().response();
        logResponseBodyAndStatusCode(response);
        return response;
    }

    /**
     * Uploads the fileName to the host using the chunkNumber provided.
     * <p>
     * Usage: To simulate the upload of a large file, call this method repeatedly with
     * the same host and fileName, incrementing the chunkNumber every time.
     *
     * @param host        - target
     * @param fileName    - the chunk being uploaded
     * @param chunkNumber - the current chunk number being uploaded
     * @param token
     * @return the response for the rest call
     */
    public static Response putFileAsChunk(String host, String fileName, int chunkNumber, Token token)
    {
        Header authHeader = new Header("Authorization", "Bearer " + token.getAccessToken());
        Header chunkNumberHeader = new Header("Chunk-Number", "" + chunkNumber);
        Response response = given().header(authHeader).contentType(ContentType.BINARY).relaxedHTTPSValidation()
                .header(chunkNumberHeader).body(new File(fileName)).when().put(host).then().extract().response();
        logResponseBodyAndStatusCode(response);
        return response;
    }

    public static Response patch(String hostUrl, String uri, String payload, Token token)
    {
        Header authHeader = new Header("Authorization", "Bearer " + token.getAccessToken());
        logRequestURL(hostUrl, uri);
        Response response = given().header(authHeader).contentType(ContentType.JSON).relaxedHTTPSValidation()
                .body(payload).when().patch(hostUrl + uri).then().extract().response();
        logResponseBodyAndStatusCode(response);
        return response;
    }

    public static Response delete(String hostUrl, String uri, Token token)
    {
        Configuration cfg = Configuration.getConfig();
        logRequestURL(hostUrl, uri);
        Header authHeader = new Header("Authorization", "Bearer " + token.getAccessToken());
        Response response = given().header(authHeader).contentType(ContentType.JSON).relaxedHTTPSValidation().when()
                .delete(hostUrl + uri).then().extract().response();
        logResponseBodyAndStatusCode(response);
        return response;
    }

    public static Response head(String hostUrl, String uri, Map<String, ?> queryParams, Token token)
    {
        Header authHeader = new Header("Authorization", "Bearer " + token.getAccessToken());
        logRequestURL(hostUrl, uri);
        Response response;
        if ( queryParams == null )
        {
            response = given().header(authHeader).contentType(ContentType.JSON).relaxedHTTPSValidation().when()
                    .head(hostUrl + uri).then().extract().response();
        }
        else
        {
            response = given().header(authHeader).contentType(ContentType.JSON).relaxedHTTPSValidation()
                    .queryParams(queryParams).when().head(hostUrl + uri).then().extract().response();
        }
        logResponseBodyAndStatusCode(response);
        return response;
    }

    public static Response getWithToken(String hostUrl, String uri, Map<String, ?> queryParams, String token)
    {

        Header authorizationHeader = new Header("Authorization", "Bearer " + token);
        logRequestURL(hostUrl, uri);
        Response response;
        if ( queryParams == null )
        {

            response = given().header(authorizationHeader).contentType(ContentType.JSON).relaxedHTTPSValidation()
                    .queryParameters(new HashMap<>()).when().get(hostUrl + uri).then().extract().response();
        }
        else
        {
            response = given().header(authorizationHeader).contentType(ContentType.JSON).relaxedHTTPSValidation()
                    .queryParams(queryParams).when().get(hostUrl + uri).then().extract().response();
        }
        logResponseBodyAndStatusCode(response);
        return response;
    }

    public static Response postWithToken(String hostUrl, String uri, String payload, String token)
    {
        Header authorizationHeader = new Header("Authorization", "Bearer " + token);
        logRequestURL(hostUrl, uri);
        Response response = given().header(authorizationHeader).contentType(ContentType.JSON).relaxedHTTPSValidation()
                .body(payload).when().post(hostUrl + uri).then().extract().response();
        logResponseBodyAndStatusCode(response);
        return response;
    }

    public static Response postWithTokenAndParams(String hostUrl, String uri, Map<String, ?> queryParams, String token)
    {
        Header authHeader = new Header("Authorization", "Bearer " + token);
        logRequestURL(hostUrl, uri);
        Response response = given().header(authHeader).contentType(ContentType.JSON).accept(ContentType.JSON)
                .relaxedHTTPSValidation().queryParameters(queryParams).when().post(hostUrl + uri).then().extract()
                .response();
        logResponseBodyAndStatusCode(response);
        return response;
    }

    // plainTextPostWithToken
    public static Response plainTextPostWithToken(String hostUrl, String uri, String payload, String token)
    {
        Header authorizationHeader = new Header("Authorization", "Bearer " + token);
        logRequestURL(hostUrl, uri);
        Response response = given().header(authorizationHeader).contentType(ContentType.TEXT).relaxedHTTPSValidation()
                .body(payload).when().post(hostUrl + uri).then().extract().response();
        logResponseBodyAndStatusCode(response);
        return response;
    }

    public static Response multiPartPostWithToken(String hostUrl, String uri, String token)
    {
        Header authorizationHeader = new Header("Authorization", "Bearer " + token);
        logRequestURL(hostUrl, uri);

        Response response = given().header(authorizationHeader).contentType(ContentType.JSON).header(gzipEncodingHeader)
                .relaxedHTTPSValidation().multiPart("file", new File("configuration.zip"))
                .contentType("multipart/form-data").when().post(hostUrl + uri).then().extract().response();
        logResponseBodyAndStatusCode(response);
        return response;
    }

    public static Response patchWithToken(String hostUrl, String uri, String payload, String token)
    {
        logRequestURL(hostUrl, uri);

        Header authHeader = new Header("Authorization", "Bearer " + token);
        Response response = given().header(authHeader).contentType(ContentType.JSON).relaxedHTTPSValidation()
                .body(payload).when().patch(hostUrl + uri).then().extract().response();
        logResponseBodyAndStatusCode(response);
        return response;
    }

    public static Response putWithToken(String hostUrl, String uri, String payload, String token)
    {
        Header authorizationHeader = new Header("Authorization", "Bearer " + token);
        logRequestURL(hostUrl, uri);
        Response response = given().header(authorizationHeader).contentType(ContentType.JSON).relaxedHTTPSValidation()
                .body(payload).when().put(hostUrl + uri).then().extract().response();
        logResponseBodyAndStatusCode(response);
        return response;
    }

    public static Response multiPartPutWithToken(String hostUrl, String uri, String token)
    {
        Header authorizationHeader = new Header("Authorization", "Bearer " + token);
        logRequestURL(hostUrl, uri);

        Response response = given().header(authorizationHeader).contentType(ContentType.JSON).header(gzipEncodingHeader)
                .relaxedHTTPSValidation().multiPart("file", new File("configuration.zip"))
                .contentType("multipart/form-data").when().put(hostUrl + uri).then().extract().response();
        logResponseBodyAndStatusCode(response);
        return response;
    }

    /*
     * For an existing OS, try to deploy it to a device
     */
    public static Response deployHostOsWithToken(String hostUrl, String uri, String token)
    {
        Header authorizationHeader = new Header("Authorization", "Bearer " + token);

        logRequestURL(hostUrl, uri);

        // deploy OS to device
        String payload = CommonUtils.getResourceAsString("/package/deployOperatingSystem.json");

        Response response = given().header(authorizationHeader).contentType(ContentType.JSON).relaxedHTTPSValidation()
                .body(payload).contentType(ContentType.JSON).when().put(hostUrl + uri).then().extract().response();

        return response;
    }

    public static Response deleteWithToken(String hostUrl, String uri, String token)
    {
        Header authorizationHeader = new Header("Authorization", "Bearer " + token);
        logRequestURL(hostUrl, uri);
        Response response = given().header(authorizationHeader).contentType(ContentType.JSON).relaxedHTTPSValidation()
                .when().delete(hostUrl + uri).then().extract().response();
        logResponseBodyAndStatusCode(response);
        return response;
    }

    public static Response headWithToken(String hostUrl, String uri, String token, Map<String, ?> queryParams)
    {
        Header authHeader = new Header("Authorization", "Bearer " + token);
        logRequestURL(hostUrl, uri);
        Response response;
        if ( queryParams == null )
        {
            response = given().header(authHeader).contentType(ContentType.JSON).relaxedHTTPSValidation().when()
                    .head(hostUrl + uri).then().extract().response();
        }
        else
        {
            response = given().header(authHeader).contentType(ContentType.JSON).relaxedHTTPSValidation()
                    .queryParams(queryParams).when().head(hostUrl + uri).then().extract().response();
        }
        logResponseBodyAndStatusCode(response);
        return response;
    }

    private static void logRequestURL(String url, String path)
    {

        StackTraceElement[] stacktrace = Thread.currentThread().getStackTrace();
        StackTraceElement e = stacktrace[3];// maybe this number needs to be corrected
        String methodName = e.getMethodName();
        _logger.info(String.format("\t%s : %s%s", methodName, url, path));
    }

    private static void logResponseBodyAndStatusCode(Response response)
    {
        String callingMethodName = Thread.currentThread().getStackTrace()[3].getMethodName();
        _logger.info(String.format("\t%s response code: %d", callingMethodName, response.statusCode()));
        if ( callingMethodResponseBodyShouldBeHidden(callingMethodName) )
        {
            _logger.info(
                    String.format("\t%s response body: [Not intended to be printed as string]", callingMethodName));
        }
        else
        {
            _logger.info(String.format("\t%s response body: %s", callingMethodName, sanitizeResponse(response)));
        }
    }

    private static boolean callingMethodResponseBodyShouldBeHidden(String methodName)
    {
        // response body of these methods result in corrupted text and should not be displayed as string.
        List skipMethodNameList = Arrays
                .asList("downloadAppPackage", "getAllBaselineConfigPackages", "getAvailableAppPackages",
                        "exportDevicesToCsv", "exportDevicesToCsvV1", "getBaselinePkg", "getBaselinePkgV2",
                        "getBaselinePkgV1", "downloadPackage", "downloadPackageV1", "downloadDeploymentTaskOutput",
                        "downloadDeploymentTaskOutputV1", "getDeviceModelImage", "getDeviceModelImageV1");

        return skipMethodNameList.contains(methodName);
    }

    private static String sanitizeResponse(Response response)
    {
        return response.asString()
                .replaceAll("\"access_token\":\".*\",\"token_type\"", "\"access_token\":\"******\",\"token_type\"");
    }

}
