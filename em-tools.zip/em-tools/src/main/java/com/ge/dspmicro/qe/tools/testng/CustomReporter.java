/*
 * Copyright (c) 2012 - 2018 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.tools.testng;

/**
 * 
 * @author 212547153
 */
import java.util.List;
import java.util.Map;

import org.testng.IReporter;
import org.testng.ISuite;
import org.testng.ISuiteResult;
import org.testng.ITestContext;
import org.testng.xml.XmlSuite;

@SuppressWarnings(
{
        "nls", "javadoc"
})
public class CustomReporter
implements IReporter
{
    @Override
    public void generateReport(List<XmlSuite> xmlSuites, List<ISuite> suites, String outputDirectory)
    {

        // Iterating over each suite included in the test
        for (ISuite suite : suites)
        {

            // Following code gets the suite name
            String suiteName = suite.getName();

            // Getting the results for the said suite
            Map<String, ISuiteResult> suiteResults = suite.getResults();
            for (ISuiteResult sr : suiteResults.values())
            {
                ITestContext tc = sr.getTestContext();
                System.out.println(
                        "Passed tests for suite '" + suiteName + "' is:" + tc.getPassedTests().getAllResults().size());
                System.out.println(
                        "Failed tests for suite '" + suiteName + "' is:" + tc.getFailedTests().getAllResults().size());
                System.out.println("Skipped tests for suite '" + suiteName + "' is:"
                        + tc.getSkippedTests().getAllResults().size());
            }
        }
    }
}