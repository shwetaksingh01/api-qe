/*
 * Copyright (c) 2019 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.tools.utils;

import static org.testng.Assert.assertEquals;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import com.ge.dspmicro.qe.tools.environment.Configuration;
import com.jayway.restassured.response.Response;

/**
 * 
 * @author 212547153
 */
@SuppressWarnings(
{
        "nls", "javadoc"
})
public class TestUtils
{
    private static Logger _logger = LoggerFactory.getLogger(TestUtils.class);



    public static boolean envSupportCheck(Configuration cfg)
    {
        boolean isSupported = true;
        List<String> supportedEnv = Arrays.asList("int", "sysint", "stage");
        if ( !supportedEnv.contains(cfg.getEnvProp()) )
        {
            isSupported = false;
        }
        return isSupported;
    }
}
