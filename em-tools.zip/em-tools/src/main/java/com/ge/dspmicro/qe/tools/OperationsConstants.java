package com.ge.dspmicro.qe.tools;

@SuppressWarnings("javadoc")
public class OperationsConstants
{
    public final static String PENDING                   = "PENDING";
    public final static String CANCELLED                 = "CANCELLED";
    public final static String SUCCESS                   = "SUCCESS";
    public final static String FAILURE                   = "FAILURE";
    public final static String IN_PROGRESS               = "IN_PROGRESS";
    public final static String OPERATION_ID              = "operationId";
    public final static String STATUS                    = "status";
    public final static String CONFIGURATION             = "configuration";
    public final static String APPLICATION               = "application";
    public final static String MULTI_CONTAINER_APP       = "multi_container_app";
    public final static String EMAPI_MULTI_CONTAINER_APP = "multi-container-app";
    public final static String ANALYTICS_DATA_MAP        = "analytics_data_map";
    public final static String ANALYTICS_TEMPLATE        = "analytics_template";
    public final static String CONTAINER                 = "container";
}
