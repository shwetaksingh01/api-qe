/*
 * Copyright (c) 2018 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.tools.environment;

import com.ge.dspmicro.qe.tools.utils.CommonUtils;
import com.ge.dspmicro.qe.tools.utils.RestClient;
import com.ge.dspmicro.qe.tools.utils.Token;
import com.ge.dspmicro.qe.tools.utils.TokenUtils;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.jayway.restassured.response.Response;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.lang.reflect.Type;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Environment configuration needed to connect to a specific cloud environment.
 *
 * @author 212547153
 */
@SuppressWarnings("nls")
public class Configuration
{
    private static final Logger  _logger                  = LoggerFactory.getLogger(Configuration.class);
    private static final String  EDGEMANAGER_URL_KEY      = "edgemanagerUrl";
    private static final String  UAA_URL_KEY              = "uaaUrl";
    private static final String  EM_UAA_URL_KEY           = "emUaaUrl";
    private static final String  CLIENT_ID_KEY            = "apiClientId";
    private static final String  TENANT_MGR_CLIENT_ID_KEY = "tenantMgrClientId";
    private static final String  TIMESERIES_INSTANCE_KEY  = "timeseriesInstance";
    private static final String  TIMESERIES_URL_KEY       = "timeseriesUrl";
    private static final String  EVENTHUB_INSTANCE_KEY    = "eventhubInstance";
    private static final String  QE_EA_DEVICE_NAME_KEY    = "qeEdgeAgentDeviceName";
    private static final String  QE_HTC_DEVICE            = "htcQeDeviceDoNotDelete";
    private static final String  QE_PM_DEVICE_NAME_KEY    = "qePredixMachineDeviceName";
    private static final String  QE_DEVICE_NAME_WITH_SIM  = "qeDeviceNameWithSim";
    private static final String  DATAMAP_PARENT_ID        = "dataMapParentId";
    private static final String  QTEST_URL                = "qTestURL";
    private static final String  QTEST_BEARER_TOKEN       = "qTestBearerToken";
    private static final String  QTEST_PROJECT_ID         = "qTestProjectId";
    private static final String  QTEST_EM_MODULE_ID       = "qTestEmModuleId";
    private static final String  QTEST_RELEASE_ID         = "qTestReleaseId";
    private static final String  QTEST_RELEASE_NAME       = "qTestReleaseName";
    private static Configuration cfg                      = null;
    private String               uaaUrl                   = null;
    private String               emUaaUrl                 = null;
    private String               apiClientId              = null;
    private String               apiClientSecret          = null;
    private String               tenantMgrClientId        = null;
    private String               tenantMgrClientSecret    = null;
    private String               edgemanagerUrl           = null;
    private String               qeEADeviceName           = null;
    private String               qeHTCDeviceName          = null;
    private String               qePMDeviceName           = null;
    private String               qeDeviceNameWithSim      = null;
    private String               timeseriesInstance       = null;
    private String               timeseriesUrl            = null;
    private String               eventhubInstance         = null;
    private Token                adminUAAToken            = null;
    private String               tenantMgrToken           = null;
    private String               envProp                  = null;
    private String               tenantId;
    private List<String>         availableFeatures        = new ArrayList<>();
    private String               dataMapParentId          = null;
    private String               qTestURL                 = null;
    private String               qTestBearerToken         = null;
    private String               qTestProjectId           = null;
    private String               qTestEmModuleId          = null;
    private String               qTestReleaseId           = null;
    private String               qTestReleaseName         = null;

    /**
     * Loads configuration based on env.json
     *
     * @return Configuration needed to run cloud-qe tests
     */
    public static synchronized Configuration getConfig()
    {
        if ( cfg == null )
        {
            String testEnvironment = System.getProperty("test.env");
            _logger.info("LOADING CONFIG FOR TENANT: " + testEnvironment);
            cfg = loadConfig(testEnvironment);
            loadFeatureToggles();
        }

        return cfg;
    }

    /**
     * @param env : environment
     * @return configuration for the qe-utils
     * @throws JsonSyntaxException : throws JsonSyntaxException
     */
    private static Configuration loadConfig(String env)
    {
        try
        {
            // set proxy
            // System.setProperty("http.proxyHost", "proxy-src.research.ge.com");
            // System.setProperty("http.proxyPort", "8080");
            // System.setProperty("https.proxyHost", "proxy-src.research.ge.com");
            // System.setProperty("https.proxyPort", "8080");

            Configuration newConfig = new Configuration();
            Gson gson = new Gson();
            Type type = new TypeToken<ArrayList<HashMap<String, String>>>()
            {
                // empty block
            }.getType();
            List<HashMap<String, String>> list;

            list = gson.fromJson(IOUtils.toString(CommonUtils.getResourceAsInputStream("/env.json")), type);
            newConfig.setEnvProp(env);
            for (HashMap<String, String> map : list)
            {
                if ( newConfig.envProp == null || newConfig.envProp.equals("") )
                {
                    _logger.error("env property not found.");
                    System.exit(1);
                }

                if ( map.get("env").equalsIgnoreCase(newConfig.envProp) )
                {
                    _logger.info("Getting properties for : " + newConfig.envProp);

                    newConfig.uaaUrl = map.get(UAA_URL_KEY);
                    newConfig.emUaaUrl = map.get(EM_UAA_URL_KEY);
                    newConfig.apiClientId = map.get(CLIENT_ID_KEY);
                    newConfig.timeseriesInstance = map.get(TIMESERIES_INSTANCE_KEY);
                    newConfig.timeseriesUrl = map.get(TIMESERIES_URL_KEY);
                    newConfig.eventhubInstance = map.get(EVENTHUB_INSTANCE_KEY);
                    newConfig.qeEADeviceName = map.get(QE_EA_DEVICE_NAME_KEY);
                    newConfig.qeHTCDeviceName = map.get(QE_HTC_DEVICE);
                    newConfig.qePMDeviceName = map.get(QE_PM_DEVICE_NAME_KEY);
                    newConfig.qeDeviceNameWithSim = map.get(QE_DEVICE_NAME_WITH_SIM);
                    newConfig.dataMapParentId = map.get(DATAMAP_PARENT_ID);
                    newConfig.qTestURL = map.get(QTEST_URL);
                    newConfig.qTestBearerToken = map.get(QTEST_BEARER_TOKEN);
                    newConfig.qTestProjectId = map.get(QTEST_PROJECT_ID);
                    newConfig.qTestEmModuleId = map.get(QTEST_EM_MODULE_ID);
                    newConfig.qTestReleaseId = map.get(QTEST_RELEASE_ID);
                    newConfig.qTestReleaseName = map.get(QTEST_RELEASE_NAME);
                    if ( System.getProperty("CLIENT_SECRET") != null
                            && !System.getProperty("CLIENT_SECRET").equals("") )
                    {
                        newConfig.apiClientSecret = System.getProperty("CLIENT_SECRET");
                    }
                    else
                    {
                        throw new RuntimeException("The required system property CLIENT_SECRET was not provided.");
                    }
                    newConfig.edgemanagerUrl = map.get(EDGEMANAGER_URL_KEY);

                    _logger.info("EdgeManager URL: " + newConfig.edgemanagerUrl);
                    HashMap<String, String> queryParams = new HashMap<>();
                    queryParams.put("grant_type", "client_credentials");
                    newConfig.adminUAAToken = TokenUtils.getUAAToken(newConfig.uaaUrl, newConfig.apiClientId,
                            newConfig.apiClientSecret, queryParams);

                    newConfig.tenantId = getTenantIdFromUrl(newConfig.edgemanagerUrl);

                    _logger.info("Tenant Id: " + newConfig.getTenantId());

     /*               if ( map.containsKey(TENANT_MGR_CLIENT_ID_KEY) )
                    {
                        newConfig.tenantMgrClientId = map.get(TENANT_MGR_CLIENT_ID_KEY);
                        if ( System.getProperty("TENANT_MGR_CLIENT_SECRET") != null
                                && !System.getProperty("TENANT_MGR_CLIENT_SECRET").equals("") )
                        {
                            newConfig.tenantMgrClientSecret = System.getProperty("TENANT_MGR_CLIENT_SECRET");
                        }
                        else
                        {
                            throw new RuntimeException(
                                    "The required system. property TENANT_MGR_CLIENT_SECRET was not provided.");
                        }
                        newConfig.tenantMgrToken = TokenUtils.getUAAToken(newConfig.emUaaUrl,
                                newConfig.tenantMgrClientId, newConfig.tenantMgrClientSecret, queryParams)
                                .getAccessToken();
                    }

                    break;  */

                }
            }
            _logger.info(newConfig.toString());

            return newConfig;
        }
        catch (JsonSyntaxException | IOException e)
        {
            _logger.error("failed to parse env.json or retrieve token", e);
            return null;
        }
    }

    /**
     * Loads feature toggles from EM-Tenant
     */
    private static void loadFeatureToggles()
    {
        long epochTimestampBeforeUAARequestSent = Instant.now().toEpochMilli();
        Token adminUAAToken = cfg.getAdminUAAToken();
        boolean hasAdminUAATokenExpired = adminUAAToken.hasTokenExpired(epochTimestampBeforeUAARequestSent);
        if ( hasAdminUAATokenExpired )
        {
            _logger.error("UAA Token used to toggle features has expired");
        }
        String token = adminUAAToken.getAccessToken();
        if ( !hasAdminUAATokenExpired && !token.isEmpty() )
        {
            Response response = RestClient.get(cfg.getEdgeManagerUrl(), "/svc/tenant/v1/features", null, adminUAAToken);
            if ( response.statusCode() == 200 )
            {
                List<Map<String, Object>> featureList = response.jsonPath().getList("$");
                for (Map<String, Object> feature : featureList)
                {
                    String featureName = (String) feature.get("name");
                    if ( (Boolean) feature.get("enabled") )
                    {
                        cfg.availableFeatures.add(featureName);
                    }
                }
            }
        }
    }

    /**
     * @param emUrl em url
     * @return Tenant Id
     */
    private static String getTenantIdFromUrl(String emUrl)
    {
        return emUrl.split("(\\/)|(\\.)")[2];
    }

    /**
     * @return the envProp
     */
    public String getEnvProp()
    {
        return this.envProp;
    }

    /**
     * @param envProp the envProp to set
     */
    private void setEnvProp(String envProp)
    {
        this.envProp = envProp;
    }

    /**
     * @return the uaaUrl
     */
    public String getUaaUrl()
    {
        return this.uaaUrl;
    }

    /**
     * @return the apiClientId
     */
    public String getApiClientId()
    {
        return this.apiClientId;
    }

    /**
     * @return the apiClientSecret
     */
    public String getApiClientSecret()
    {
        return this.apiClientSecret;
    }

    /**
     * @return the deviceManagementUrl
     */
    public String getEdgeManagerUrl()
    {
        return this.edgemanagerUrl;
    }

    /**
     * Returns the tenant id from the URL.
     *
     * @return tenant id that can be passed in Predix-Zone-Id header
     */
    public String getTenantId()
    {
        return this.tenantId;
    }

    /**
     * @return the UAA token in a Token object
     */
    public Token getAdminUAAToken()
    {
        return this.adminUAAToken;
    }

    /**
     * @return the availableFeatures
     */
    public List<String> getAvailableFeatures()
    {
        return this.availableFeatures;
    }

    /**
     * @return the tokenMgrToken
     */
    public String getTenantMgrToken()
    {
        return this.tenantMgrToken;
    }

    /**
     * @return cloud qe EA device name
     */
    public String getQeEADeviceName()
    {
        return this.qeEADeviceName;
    }

    /**
     * @param qeEADeviceName cloud qe EA device name
     */
    public void setQeEADeviceName(String qeEADeviceName)
    {
        this.qeEADeviceName = qeEADeviceName;
    }

    /**
     * @return cloud qe PM device name
     */
    public String getQePMDeviceName()
    {
        return this.qePMDeviceName;
    }

    /**
     * @param qePMDeviceName cloud qe PM device name
     */
    public void setQePMDeviceName(String qePMDeviceName)
    {
        this.qePMDeviceName = qePMDeviceName;
    }

    /**
     * @return cloud qe device name with sim
     */
    public String getQeDeviceNameWithSim()
    {
        return this.qeDeviceNameWithSim;
    }

    /**
     * @return cloud qe EA device name
     */
    public String getQeHTCDeviceName()
    {
        return this.qeEADeviceName;
    }

    /**
     * @param qeEADeviceName cloud qe EA device name
     */
    public void setQeHTCDeviceName(String qeEADeviceName)
    {
        this.qeEADeviceName = qeEADeviceName;
    }

    /**
     * @param cloud qe device name with sim
     */
    public void getQeDeviceNameWithSim(String qeDeviceNameWithSim)
    {
        this.qeDeviceNameWithSim = qeDeviceNameWithSim;
    }

    /**
     * @return timeseries instance id
     */
    public String getTimeseriesInstance()
    {
        return this.timeseriesInstance;
    }

    /**
     * @param timeseriesInstance timeseries instance id
     */
    public void setTimeseriesInstance(String timeseriesInstance)
    {
        this.timeseriesInstance = timeseriesInstance;
    }

    /**
     * @return timeseries url
     */
    public String getTimeseriesUrl()
    {
        return this.timeseriesUrl;
    }

    /**
     * @param timeseriesUrl timeseries url
     */
    public void setTimeseriesUrl(String timeseriesUrl)
    {
        this.timeseriesUrl = timeseriesUrl;
    }

    /**
     * @return eventhub service instance id
     */
    public String getEventhubInstance()
    {
        return this.eventhubInstance;
    }

    /**
     * @param eventhubInstance eventhub service instance id
     */
    public void setEventhubInstance(String eventhubInstance)
    {
        this.eventhubInstance = eventhubInstance;
    }

    /**
     * @return the parentId
     */
    public String getParentId()
    {
        return this.dataMapParentId;
    }

    /**
     * @param dataMapParentId the dataMapParentId to set
     */
    public void setParentId(String dataMapParentId)
    {
        this.dataMapParentId = dataMapParentId;
    }

    /**
     * @return the qTestURL
     */
    public String getQTestUrl()
    {
        return this.qTestURL;
    }

    /**
     * @return the qTestBearerToken
     */
    public String getQTestBearerToken()
    {
        return this.qTestBearerToken;
    }

    /**
     * @return the qTestProjectId
     */
    public String getQTestProjectId()
    {
        return this.qTestProjectId;
    }

    /**
     * @return the qTestEmModuleId
     */
    public String getEmModuleId()
    {
        return this.qTestEmModuleId;
    }

    /**
     * @return the qTestReleaseId
     */
    public String getQTestReleaseId()
    {
        return this.qTestReleaseId;
    }

    /**
     * @return the qTestReleaseName
     */
    public String getQTestReleaseName()
    {
        return this.qTestReleaseName;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString()
    {
        // @formatter:off
        return "Configuration [uaaUrl=" + this.uaaUrl
                + ", emUaaUrl=" + this.emUaaUrl
                + ", apiClientId=" + this.apiClientId
                + ", apiClientSecret=" + (this.apiClientSecret == null ? "null" : "****")
                + ", tenantMgrClientId=" + this.tenantMgrClientId
                + ", tenantMgrClientSecret=" + (this.tenantMgrClientSecret == null ? "null" : "****")
                + ", edgemanagerUrl=" + this.edgemanagerUrl
                + ", token=" + (this.adminUAAToken.getAccessToken() == null ? "null" : "****")
                + ", tenantMgrToken=" + (this.tenantMgrToken == null ? "null" : "****")
                + ", envProp=" + this.envProp
                + ", tenantId=" + this.tenantId
                + ", availableFeatures=" + this.availableFeatures
                + ", qTestURL=" + this.qTestURL
                + ", qTestBearerToken=" + (this.qTestBearerToken == null ? "null" : "****")
                + ", qTestProjectId=" + this.qTestProjectId
                + ", qTestEmModuleId=" + this.qTestEmModuleId
                + ", qTestReleaseId=" + this.qTestReleaseId
                + ", qTestReleaseName=" + this.qTestReleaseName + "]";
        // @formatter:on
    }

}
