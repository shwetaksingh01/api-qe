package com.ge.dspmicro.qe.tools;

@SuppressWarnings("javadoc")
public class QEConstants
{
    public final static String PREDIX_MACHINE       = "PredixMachine";
    public final static String EDGE_AGENT           = "EdgeAgent";
    public final static String ORDER_ASC            = "asc";
    public final static String ORDER_DESC           = "desc";
}
