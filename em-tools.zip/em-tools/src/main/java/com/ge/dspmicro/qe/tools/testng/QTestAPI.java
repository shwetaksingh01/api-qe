/*
 * Copyright (c) 2019 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.tools.testng;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Listeners;

import com.ge.dspmicro.qe.tools.environment.Configuration;
import com.ge.dspmicro.qe.tools.utils.QTestRestClient;
import com.jayway.restassured.response.Response;

/**
 * @author 212775111
 */
@SuppressWarnings({"javadoc", "nls"
}) @Listeners(TestListener.class) public class QTestAPI
{
    private static final Logger        _logger                 = LoggerFactory.getLogger(QTestAPI.class);
    private static       Configuration cfg                     = Configuration.getConfig();
    private static       String        bearerToken             = cfg.getQTestBearerToken();
    private static       String        projectId               = cfg.getQTestProjectId();
    private static       String        moduleID                = cfg.getEmModuleId();
    private static       String        releaseId               = cfg.getQTestReleaseId();
    private static       String        releaseName             = cfg.getQTestReleaseName();
    private static       String        moduleIdName;
    private static       int           testCaseId;
    private static       int           testSuiteId;
    private static       DateFormat    dateFormat              = new SimpleDateFormat("yyyy-MM-dd");
    private static       Date          date                    = new Date();
    private static       String        testSuiteName           = null;
    private static final String        QTEST_URI_PREFIX        = "/api/v3/projects/";
    private static final String        QUERY_URI               = QTEST_URI_PREFIX + projectId + "/search";
    private static final String        CREATE_TEST_CASE_ID_URI = QTEST_URI_PREFIX + projectId + "/test-cases";
    private static final String        LINK_REQUIREMENT_URI    = QTEST_URI_PREFIX + projectId + "/requirements/";
    private static final String        MODULE_ID_URI           = QTEST_URI_PREFIX + projectId + "/modules";
    private static final String        TEST_SUITE_URI          =
            QTEST_URI_PREFIX + projectId + "/test-suites?parentId=" + releaseId + "&parentType=release";
    private static final String        TEST_RUN_URI            = QTEST_URI_PREFIX + projectId + "/test-runs";
    private static final String        TEST_RESULT_URI         = QTEST_URI_PREFIX + projectId + "/test-runs/";
    private static final String        PARENT_ID               = "?parentId=";
    private static final String        FAILURE_RESPONSE        = "\t Failure Response is : ";
    private static final String        ITEMS                   = "items";
    private static       int           currentParentModuleID;

    private static String findOrCreateTestModule(String moduleName)
    {
        Response response = QTestRestClient
                .qtestGet(cfg.getQTestUrl(), MODULE_ID_URI + PARENT_ID + currentParentModuleID, bearerToken);
        _logger.info("\t response of  findOrCreateTestModule is : " + response);

        moduleIdName = "Not Available";

        int statusCode = response.getStatusCode();

        if ( statusCode == HttpStatus.SC_OK )
        {
            List<Map<String, Object>> data = response.jsonPath().getList("$");

            for (Map<String, Object> datum : data)
            {
                if ( (datum.get("name")).equals(moduleName) )
                {
                    moduleIdName = datum.get("pid") + " " + moduleName;
                    currentParentModuleID = (int) datum.get("id");
                    break;
                }
            }

            if ( moduleIdName.equalsIgnoreCase("Not Available") )
            {
                moduleIdName = createQTestModule(moduleName);
            }
        }

        return moduleIdName;
    }

    private static String createQTestModule(String moduleName)
    {

        String payload = "{\n" + "\t\"name\": \"" + moduleName + "\"\n" + "}";

        Response response = QTestRestClient
                .qtestPost(cfg.getQTestUrl(), MODULE_ID_URI + PARENT_ID + currentParentModuleID, payload, bearerToken);

        moduleIdName = null;

        int statusCode = response.getStatusCode();

        if ( statusCode == HttpStatus.SC_CREATED )
        {
            moduleIdName = response.jsonPath().get("pid") + " " + moduleName;
            _logger.info("\t moduleIdName is : " + moduleIdName);
            currentParentModuleID = response.jsonPath().get("id");
            _logger.info("\t currentParentModuleID is : " + currentParentModuleID);
        }

        else
        {
            _logger.info("\t Failed to create Module in QTest with Status Code : " + statusCode);
            _logger.info(FAILURE_RESPONSE + response);
        }

        return moduleIdName;
    }

    static void findOrCreateTestCase(String requirementID, String epicName, String testType, String moduleName,
            String testName, String description, String preCondition)
    {
        try
        {
            currentParentModuleID = Integer.parseInt(moduleID);

            findOrCreateTestModule(moduleName);

            findOrCreateTestModule(epicName);

            moduleIdName = findOrCreateTestModule(testType);

            String payload =
                    "{\n" + "  \"object_type\": \"test-cases\",\n" + "  \"fields\": [\n" + "    \"*\"\n" + "  ],\n"
                            + "  \"query\": \"Module = '" + moduleIdName + "' and Name = '" + testName + "'\"\n" + "} ";

            Response response = QTestRestClient.qtestPost(cfg.getQTestUrl(), QUERY_URI, payload, bearerToken);

            testCaseId = 0;

            int statusCode = response.getStatusCode();

            if ( statusCode == HttpStatus.SC_OK )
            {
                int testAvailability = response.jsonPath().get("total");

                if ( testAvailability == 0 )
                {
                    int moduleId = getModuleId(moduleName);
                    testCaseId = createMissingTestCase(moduleId, testName, description, preCondition);
                }

                else if ( testAvailability == 1 )
                {
                    List<Map<String, Object>> data = response.jsonPath().getList(ITEMS);
                    testCaseId = (int) data.get(0).get("id");
                }

                else if ( testAvailability >= 2 )
                {
                    _logger.info(
                            "\t More than one Test case available with same Test name, considering first test case to update Test result");
                    List<Map<String, Object>> data = response.jsonPath().getList(ITEMS);
                    testCaseId = (int) data.get(0).get("id");
                }
                List<String> requirementIDList = Arrays.asList(requirementID.split(","));
                for (String s : requirementIDList)
                    mapRequirementToTestCase(s);
            }

            else
            {
                _logger.info("\t Failed to integrate with QTest with Status Code : " + statusCode);
                _logger.info(FAILURE_RESPONSE + response);
            }

        }
        catch (Exception exception)
        {
            _logger.info("\t Exception in findOrCreateTestCase: " + exception);
        }

    }

    private static void mapRequirementToTestCase(String requirementID)
    {

        String payload = "[" + testCaseId + "]";

        String requirementMappingUri = LINK_REQUIREMENT_URI + requirementID + "/link?type=test-cases";

        Response response = QTestRestClient.qtestPost(cfg.getQTestUrl(), requirementMappingUri, payload, bearerToken);

        int statusCode = response.getStatusCode();

        if ( statusCode == HttpStatus.SC_CREATED )
        {
            List<Map<String, Object>> data = response.jsonPath().getList("$");
            data.get(0).get("id");
        }
        else
        {
            _logger.info("\t Failed to map requirement ID to the Test Case in QTest with Status Code : " + statusCode);
            _logger.info(FAILURE_RESPONSE + response);
        }
    }

    private static int createMissingTestCase(int moduleId, String testName, String description, String preCondition)
    {

        String payload =
                "{\n" + "  \"name\": \"" + testName + "\",\n" + "  \"parent_id\": \"" + currentParentModuleID + "\",\n"
                        + "  \"precondition\": \"" + preCondition + "\",\n" + "  \"description\": \"" + description
                        + "\"\n" + "}";

        _logger.info("\t Payload is : " + payload);
        Response response = QTestRestClient.qtestPost(cfg.getQTestUrl(), CREATE_TEST_CASE_ID_URI, payload, bearerToken);

        int statusCode = response.getStatusCode();

        if ( statusCode == HttpStatus.SC_OK )
        {
            testCaseId = response.jsonPath().get("id");
        }

        else
        {
            _logger.info("\t Failed to create missing Test Case in QTest with Status Code : " + statusCode);
            _logger.info(FAILURE_RESPONSE + response);
        }
        return testCaseId;
    }

    private static int getModuleId(String moduleName)
    {
        Response response = QTestRestClient.qtestGet(cfg.getQTestUrl(), MODULE_ID_URI, bearerToken);

        int moduleId = 0;

        int statusCode = response.getStatusCode();

        if ( statusCode == HttpStatus.SC_OK )
        {

            List<Map<String, Object>> data = response.jsonPath().getList("$");

            for (Map<String, Object> datum : data)
            {
                if ( (datum.get("name")).equals(moduleName) )
                {
                    moduleId = (int) datum.get("id");
                    break;
                }
            }

        }

        else
        {
            _logger.info("\t Failed to get Module ID with Name in QTest with Status Code : " + statusCode);
            _logger.info(FAILURE_RESPONSE + response);
        }

        return moduleId;
    }

    static void findOrCreateTestSuite()
    {
        try
        {
            Response response = QTestRestClient.qtestGet(cfg.getQTestUrl(), TEST_SUITE_URI, bearerToken);

            testSuiteName = "Automation " + dateFormat.format(date);

            testSuiteId = 0;

            int statusCode = response.getStatusCode();

            if ( statusCode == HttpStatus.SC_OK )
            {

                List<Map<String, Object>> data = response.jsonPath().getList("$");

                for (Map<String, Object> datum : data)
                {
                    if ( (datum.get("name")).equals(testSuiteName) )
                    {
                        testSuiteId = (int) datum.get("id");
                        break;
                    }
                }

                if ( testSuiteId == 0 )
                {
                    testSuiteId = createQTestTestSuite(testSuiteName);
                }
            }

            else
            {
                _logger.info("\t Failed to get Test Suite in QTest with Status Code : " + statusCode);
                _logger.info(FAILURE_RESPONSE + response);
            }
        }
        catch (Exception exception)
        {
            _logger.info("\t Exception in findOrCreateTestCase: " + exception);
        }

    }

    private static int createQTestTestSuite(String testSuiteName)
    {

        String payload = "{\n" + "\t\"name\": \"" + testSuiteName + "\"\n" + "}";

        Response response = QTestRestClient.qtestPost(cfg.getQTestUrl(), TEST_SUITE_URI, payload, bearerToken);

        int statusCode = response.getStatusCode();

        if ( statusCode == HttpStatus.SC_OK )
        {
            testSuiteId = response.jsonPath().get("id");
        }

        else
        {
            _logger.info("\t Failed to create Test Suite in QTest with Status Code : " + statusCode);
            _logger.info(FAILURE_RESPONSE + response);
        }

        return testSuiteId;
    }

    static void findOrCreateTestRunAndUpdateStatus(String testName, String status, String result)
    {

        String payload = "{\n" + "  \"object_type\": \"test-runs\",\n" + "  \"fields\": [\n" + "    \"*\"\n" + "  ],\n"
                + "  \"query\": \"Release = '" + releaseName + "' and 'Created Date' >= '" + dateFormat.format(date)
                + "'T'00:00:00.000Z' and Name = '" + testName + "'\"\n" + "}";

        Response response = QTestRestClient.qtestPost(cfg.getQTestUrl(), QUERY_URI, payload, bearerToken);

        int statusCode = response.getStatusCode();

        if ( statusCode == HttpStatus.SC_OK )
        {
            int testAvailability = response.jsonPath().get("total");

            int testRunId;
            if ( testAvailability == 0 )
            {
                createTestRunAndUpdateStatus(testName, status, result);
            }

            else if ( testAvailability == 1 )
            {
                List<Map<String, Object>> data = response.jsonPath().getList(ITEMS);
                testRunId = (int) data.get(0).get("id");
                submitQTestResult(testName, status, testRunId, result);
            }

            else if ( testAvailability >= 2 )
            {
                _logger.info(
                        "\t More than one Test Run available with same Test name, considering first test case to update Test result");
                List<Map<String, Object>> data = response.jsonPath().getList(ITEMS);
                testRunId = (int) data.get(0).get("id");
                submitQTestResult(testName, status, testRunId, result);
            }
        }

        else
        {
            _logger.info("\t Failed to integrate with QTest with Status Code : " + statusCode);
            _logger.info(FAILURE_RESPONSE + response);
        }

    }

    private static void createTestRunAndUpdateStatus(String testName, String status, String result)
    {

        int testRunId = 0;

        String payload =
                "{\n" + "  \"name\": \"" + testName + "\",\n" + "  \"test_case\": {\n" + "    \"id\": \"" + testCaseId
                        + "\",\n" + "    \"name\": \"" + testName + "\"\n" + "  }\n" + "}";

        Response response = QTestRestClient
                .qtestPost(cfg.getQTestUrl(), TEST_RUN_URI + PARENT_ID + testSuiteId + "&parentType=test-suite",
                        payload, bearerToken);

        int statusCode = response.getStatusCode();

        if ( statusCode == HttpStatus.SC_CREATED )
        {
            testRunId = response.jsonPath().get("id");
        }

        else
        {
            _logger.info("\t Failed to create Test Run in QTest with Status Code : " + statusCode);
            _logger.info(FAILURE_RESPONSE + response);
        }

        submitQTestResult(testName, status, testRunId, result);
    }

    private static void submitQTestResult(String testName, String status, int testRunId, String result)
    {

        Date javaUtilDate = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");

        String payload = "{\n" + "\t\"status\": \"" + status + "\",\n" + "    \"exe_start_date\": \"" + formatter
                .format(javaUtilDate) + "\",\n" + "    \"exe_end_date\": \"" + formatter.format(javaUtilDate) + "\",\n"
                + "    \"name\": \"" + testName + "\",\n" + "    \"automation_content\": \"automation content\",\n"
                + "    \"note\": \"" + result + "\"\n" + "}";

        Response response = QTestRestClient
                .qtestPost(cfg.getQTestUrl(), TEST_RESULT_URI + testRunId + "/auto-test-logs?type=automation", payload,
                        bearerToken);

        int statusCode = response.getStatusCode();

        if ( statusCode == HttpStatus.SC_OK )
        {
            testRunId = response.jsonPath().get("id");
        }

        else
        {
            _logger.info("\t Failed to submit Test Result in QTest with Status Code : " + statusCode);
            _logger.info(FAILURE_RESPONSE + response);
        }

    }

}
