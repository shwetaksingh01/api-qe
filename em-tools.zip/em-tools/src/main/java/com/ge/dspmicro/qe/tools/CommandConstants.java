package com.ge.dspmicro.qe.tools;

@SuppressWarnings("javadoc")
public class CommandConstants
{
    public final static String AGENT_TYPE                     = "agentType";
    public final static String ASSOCIATE_WITH_APP             = "associateWithApp";
    public final static String SYSTEM_COMMAND                 = "SYSTEM";
    public final static String CUSTOM_COMMAND                 = "CUSTOM";
    public final static String COMMAND_TYPE                   = "commandType";
    public final static String HANDLER                        = "handler";
    public final static String COMMAND_DISPLAY_NAME           = "commandDisplayName";
    public final static String DESCRIPTION                    = "description";
    public final static String COMMAND_ID                     = "commandId";
    public final static int    PM_SYSTEM_COMMAND_COUNT        = 28;
    public final static int    EA_SYSTEM_COMMAND_COUNT        = 22;
    public final static int    TOTAL_SYSTEM_COMMAND_COUNT     = EA_SYSTEM_COMMAND_COUNT + PM_SYSTEM_COMMAND_COUNT;
}
