/*
 * Copyright (c) 2012 - 2017 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.tools.utils;

import java.security.KeyPair;

/**
 * 
 * @author 212547153
 */
public class CertEnrolledDeviceInfo
{

    /**
     * @return the deviceId
     */
    public String getDeviceId()
    {
        return this.deviceId;
    }

    /**
     * @param deviceId the deviceId to set
     */
    public void setDeviceId(String deviceId)
    {
        this.deviceId = deviceId;
    }

    /**
     * @return the deviceUUID
     */
    public String getDeviceUUID()
    {
        return this.deviceUUID;
    }

    /**
     * @param deviceUUID the deviceUUID to set
     */
    public void setDeviceUUID(String deviceUUID)
    {
        this.deviceUUID = deviceUUID;
    }

    /**
     * @return the clientID
     */
    public String getClientID()
    {
        return this.clientID;
    }

    /**
     * @param clientID the clientID to set
     */
    public void setClientID(String clientID)
    {
        this.clientID = clientID;
    }

    /**
     * @return the keyPair
     */
    public KeyPair getKeyPair()
    {
        return this.keyPair;
    }

    /**
     * @param keyPair the keyPair to set
     */
    public void setKeyPair(KeyPair keyPair)
    {
        this.keyPair = keyPair;
    }
    private String deviceId;
    private String deviceUUID;
    private String clientID;
    private KeyPair keyPair;
}
