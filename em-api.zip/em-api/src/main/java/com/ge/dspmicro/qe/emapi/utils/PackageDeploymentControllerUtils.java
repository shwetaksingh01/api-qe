/*
 * Copyright (c) 2012 - 2017 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.emapi.utils;

import java.util.HashMap;
import java.util.Map;

import com.ge.dspmicro.qe.tools.environment.Configuration;
import com.ge.dspmicro.qe.tools.utils.RestClient;
import com.ge.dspmicro.qe.tools.utils.Token;
import com.jayway.restassured.response.Response;

/**
 *
 * @author 212547153
 */
@SuppressWarnings(value =
{
        "javadoc", "nls"
})
public class PackageDeploymentControllerUtils
{
    private static Configuration cfg                            = Configuration.getConfig();
    private static Token         token                          = cfg.getAdminUAAToken();
    private static final String  BASE_URI_PACKAGE_MANAGEMENT    = EmapiConstants.EM_API_BETA_BASE
            + EmapiConstants.PACKAGE_MANAGEMENT;
    private static final String  BASE_URI_PACKAGE_DEVICES       = BASE_URI_PACKAGE_MANAGEMENT + "/devices";
    private static final String  BASE_URI_PACKAGE_OPERATIONS    = BASE_URI_PACKAGE_MANAGEMENT + "/operations";
    private static final String  BASE_URI_PACKAGE_DEPLOY        = BASE_URI_PACKAGE_MANAGEMENT + "/packages/deploy";
    private static final String  BASE_URI_PACKAGE_TASKS         = BASE_URI_PACKAGE_MANAGEMENT + "/tasks";

    private static final String  BASE_URI_V1_PACKAGE_MANAGEMENT = EmapiConstants.EM_API_BASE
            + EmapiConstants.PACKAGE_MANAGEMENT;
    private static final String  BASE_URI_V1_PACKAGE_DEVICES    = BASE_URI_V1_PACKAGE_MANAGEMENT + "/devices";
    private static final String  BASE_URI_V1_PACKAGE_OPERATIONS = BASE_URI_V1_PACKAGE_MANAGEMENT + "/operations";
    private static final String  BASE_URI_V1_PACKAGE_DEPLOY     = BASE_URI_V1_PACKAGE_MANAGEMENT + "/packages/deploy";
    private static final String  BASE_URI_V1_PACKAGE_TASKS      = BASE_URI_V1_PACKAGE_MANAGEMENT + "/tasks";

    // GET /emapi/v1/package-management/devices/{deviceId}/packages Retrieve a list of third-party packages which are currently installed on a device
    public static Response getCurrentlyInstalledPackagesV1(String deviceId)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_V1_PACKAGE_DEVICES + "/" + deviceId + "/packages", null,
                token);
    }

    // GET /emapi/v1/package-management/devices/{deviceId}/packages/{packageCategory}/history Retrieve a list of packages that have been installed on a device
    // previously
    public static Response getDevicePackageInstallationHistoryV1(String deviceId, String packageCategory)
    {
        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("limit", 3);
        queryParams.put("offset", 0);
        queryParams.put("sort", "create_time");
        queryParams.put("order", "desc");
        return RestClient.get(cfg.getEdgeManagerUrl(),
                BASE_URI_V1_PACKAGE_DEVICES + "/" + deviceId + "/packages/" + packageCategory + "/history", queryParams,
                token);
    }

    // GET /emapi/v1/package-management/operations Gets the paginated deployment operation history.
    public static Response getPackageOperationHistoryV1(String deviceFilter, int limit)
    {
        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("limit", limit);
        queryParams.put("offset", 0);
        queryParams.put("deviceFilter", deviceFilter);
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_V1_PACKAGE_OPERATIONS, queryParams, token);
    }

    // GET /emapi/v1/package-management/operations/{operationId} Retrieve the details for a package operation.
    public static Response getPackageOperationDetailsV1(String operationId, String deviceFilter) // add more test with device filters
    {
        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("limit", 50);
        queryParams.put("offset", 0);
        queryParams.put("deviceFilter", deviceFilter);
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_V1_PACKAGE_OPERATIONS + "/" + operationId, queryParams,
                token);
    }

    // PATCH /emapi/v1/package-management/operations/{operationId} Cancel a package or BOM deployment operation.
    public static Response cancelDeploymentV1(String operationId, String payload)
    {
        return RestClient.patch(cfg.getEdgeManagerUrl(), BASE_URI_V1_PACKAGE_OPERATIONS + "/" + operationId, payload,
                token);
    }

    // POST /emapi/v1/package-management/packages/deploy Deploy a package to a filtered set of devices
    public static Response deployPackagesToDevicesV1(String payload)
    {
        return RestClient.post(cfg.getEdgeManagerUrl(), BASE_URI_V1_PACKAGE_DEPLOY, payload, token);
    }

    // GET /emapi/v1/package-management/tasks/{taskId}/output Download the deployment output for this task
    public static Response downloadDeploymentTaskOutputV1(String taskId) // done
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_V1_PACKAGE_TASKS + "/" + taskId + "/output", null,
                token);
    }

    // PUT /emapi/v1/package-management/tasks/{taskId}/output Upload the output file produced from the package deployment task
    public static Response uploadDeploymentTaskOutputV1(String taskId, String fileName)
    {
        return RestClient.postWithMultipart(cfg.getEdgeManagerUrl(),
                BASE_URI_V1_PACKAGE_TASKS + "/" + taskId + "/output", null, fileName, token);
    }

    // GET /emapi/v1/package-management/app-installations/instance-ids Get the list of instance ids
    public static Response getAppInstallationsV1()
    {
        return RestClient.get(cfg.getEdgeManagerUrl(),
                BASE_URI_V1_PACKAGE_MANAGEMENT + "/app-installations/instance-ids", null, token);
    }

    public void setToken(Token token)
    {
        PackageDeploymentControllerUtils.token = token;
    }

    public Token getToken()
    {
        return PackageDeploymentControllerUtils.token;
    }
}
