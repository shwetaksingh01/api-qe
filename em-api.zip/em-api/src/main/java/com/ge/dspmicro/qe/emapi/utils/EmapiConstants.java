/*
 * Copyright (c) 2012 - 2017 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.emapi.utils;

/**
 * 
 * @author 212547153
 */
@SuppressWarnings(
{
        "javadoc", "nls"
})
public class EmapiConstants
{

    public static final String EM_API              = "/emapi";
    public static final String EM_API_BETA_VERSION = "/beta";
    public static final String EM_API_BETA_BASE    = EM_API + EM_API_BETA_VERSION;
    public static final String EM_API_V1_VERSION   = "/v1";
    public static final String EM_API_BASE         = EM_API + EM_API_V1_VERSION;
    public static final String DEVICE_MANAGEMENT   = "/device-management";
    public static final String PACKAGE_MANAGEMENT  = "/package-management";
    public static final String BOM_MANAGEMENT      = "/bom-management";
}
