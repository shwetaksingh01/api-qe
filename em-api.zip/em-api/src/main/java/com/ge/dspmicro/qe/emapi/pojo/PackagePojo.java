/*
 * Copyright (c) 2012 - 2017 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.emapi.pojo;

import java.io.File;
import java.util.Map;

import com.google.gson.Gson;

/**
 * 
 * @author 212547153
 */
@SuppressWarnings(
{
        "nls", "javadoc"
})
public class PackagePojo
{
    private String name;
    private String desc;
    private String version;
    private String vendor;
    private String type;
    private String notes;
    private String handler;
    private String fileName;
    private String uploadId;
    private long   totalBytes;
    private String attributes;
    private String agentType;

    /**
     * @param packgeName
     * @param version
     * @param vendor
     * @param desc
     * @param type
     * @param notes
     * @param handler
     * @param fileName
     * @param uploadId
     * @param size
     */
    public PackagePojo(String packgeName, String version, String vendor, String desc, String type, String notes,
            String handler, String fileName, long size, Map<String, String> attributesMap)
    {
        super();
        this.name = packgeName;
        this.version = version;
        this.vendor = vendor;
        this.desc = desc;
        this.type = type;
        this.notes = notes;
        this.handler = handler;
        this.fileName = fileName;
        this.totalBytes = size;
        Gson gson = new Gson();
        this.attributes = gson.toJson(attributesMap);
    }

    public PackagePojo(String handler, String type, String fileName)
    {
        this.name = "QE_Test-" + System.currentTimeMillis() / 1000;
        this.version = "1.1." + System.currentTimeMillis() / 1000;
        this.vendor = "QE Regression Tests";
        this.desc = "Package uploaded from QE regression test";
        this.type = type;
        this.notes = "Auto-generated notes.";
        this.handler = handler;
        this.fileName = fileName;
        this.totalBytes = new File(fileName).length();
        this.attributes = "{}";
    }

    public PackagePojo(String name, String version, String type, String fileName)
    {
        this.name = name;
        this.version = version;
        this.vendor = "";
        this.desc = "Package uploaded from QE deployment test";
        this.type = type;
        this.notes = "Notes Botes Totes";
        this.handler = "Custom";
        this.fileName = fileName;
        this.totalBytes = new File(fileName).length();
        this.attributes = "{}";
    }

    public PackagePojo(String name, String version, String type, String fileName, String agentType)
    {
        this.name = name;
        this.version = version;
        this.vendor = "GE Digital";
        this.desc = "Package for MultiContainer tests";
        this.type = type;
        this.notes = "Notes for MultiContainer tests";
        this.fileName = fileName;
        this.totalBytes = new File(fileName).length();
        this.attributes = "{}";
        this.agentType = agentType;
    }

    /**
     * @return the name
     */
    public String getName()
    {
        return this.name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String pkgName)
    {
        this.name = pkgName;
    }

    /**
     * @return the desc
     */
    public String getDesc()
    {
        return this.desc;
    }

    /**
     * @param desc the desc to set
     */
    public void setDesc(String desc)
    {
        this.desc = desc;
    }

    /**
     * @return the version
     */
    public String getVersion()
    {
        return this.version;
    }

    /**
     * @param version the version to set
     */
    public void setVersion(String version)
    {
        this.version = version;
    }

    /**
     * @return the vendor
     */
    public String getVendor()
    {
        return this.vendor;
    }

    /**
     * @param vendor the vendor to set
     */
    public void setVendor(String vendor)
    {
        this.vendor = vendor;
    }

    /**
     * @return the type
     */
    public String getType()
    {
        return this.type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type)
    {
        this.type = type;
    }

    /**
     * @return the notes
     */
    public String getNotes()
    {
        return this.notes;
    }

    /**
     * @param notes the notes to set
     */
    public void setNotes(String notes)
    {
        this.notes = notes;
    }

    /**
     * @return the handler
     */
    public String getHandler()
    {
        return this.handler;
    }

    /**
     * @param handler the handler to set
     */
    public void setHandler(String handler)
    {
        this.handler = handler;
    }

    /**
     * @return the fileName
     */
    public String getFileName()
    {
        return this.fileName;
    }

    /**
     * @param fileName the fileName to set
     */
    public void setFileName(String fileName)
    {
        this.fileName = fileName;
    }

    /**
     * @return the uploadId
     */
    public String getUploadId()
    {
        return this.uploadId;
    }

    /**
     * @param uploadId the uploadId to set
     */
    public void setUploadId(String uploadId)
    {
        this.uploadId = uploadId;
    }

    /**
     * @return the totalBytes
     */
    public long getTotalBytes()
    {
        return this.totalBytes;
    }

    /**
     * @param totalBytes the totalBytes to set
     */
    public void setTotalBytes(long totalBytes)
    {
        this.totalBytes = totalBytes;
    }

    /**
     * @return the attributes
     */
    public String getAttributes()
    {
        return this.attributes;
    }

    /**
     * @param attributes the attributes to set
     */
    public void setAttributes(String attributes)
    {
        this.attributes = attributes;
    }

    public void setAgentType(String agentType)
    {
        this.agentType = agentType;
    }

    public String getAgentType()
    {
        return this.agentType;
    }
}
