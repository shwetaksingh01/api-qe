/*
 * Copyright (c) 2012 - 2017 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.emapi.pojo;

/**
 * 
 * @author 212547153
 */
@SuppressWarnings("nls")
public class DevicePojo
{

    @SuppressWarnings("javadoc")
    public DevicePojo(String deviceId, String groupId)
    {
        super();
        this.deviceId = deviceId;
        this.modelId = "FieldAgent";
        this.groupId = groupId != null ? groupId : "0";
        this.name = deviceId;
        this.sharedSecret = "sharedSecret";
    }

    private String deviceId;
    private String modelId;
    private String groupId;
    private String name;
    private String sharedSecret;

    /**
     * @return the deviceId
     */
    public String getDeviceId()
    {
        return this.deviceId;
    }

    /**
     * @param deviceId the deviceId to set
     */
    public void setDeviceId(String deviceId)
    {
        this.deviceId = deviceId;
    }

    /**
     * @return the modelId
     */
    public String getModelId()
    {
        return this.modelId;
    }

    /**
     * @param modelId the modelId to set
     */
    public void setModelId(String modelId)
    {
        this.modelId = modelId;
    }

    /**
     * @return the groupId
     */
    public String getGroupId()
    {
        return this.groupId;
    }

    /**
     * @param groupId the groupId to set
     */
    public void setGroupId(String groupId)
    {
        this.groupId = groupId;
    }

    /**
     * @return the name
     */
    public String getName()
    {
        return this.name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name)
    {
        this.name = name;
    }

    /**
     * @return the sharedSecret
     */
    public String getSharedSecret()
    {
        return this.sharedSecret;
    }

    /**
     * @param sharedSecret the sharedSecret to set
     */
    public void setSharedSecret(String sharedSecret)
    {
        this.sharedSecret = sharedSecret;
    }

}
