/*
 * Copyright (c) 2019 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.emapi.test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.SkipException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ge.dspmicro.qe.emapi.utils.DeviceAppManagementControllerUtils;
import com.ge.dspmicro.qe.tools.BaseTest;
import com.ge.dspmicro.qe.tools.environment.Configuration;
import com.ge.dspmicro.qe.tools.testng.TestListener;
import com.ge.predix.edgemanager.qe.annotations.JiraTestCaseInfo;
import com.jayway.restassured.response.Response;

/**
 * @author 212729715
 */
@SuppressWarnings(
{
        "javadoc", "nls"
})
@Listeners(TestListener.class)
public class DeviceAppControllerV1Test extends BaseTest
{
    private static final Logger _logger = LoggerFactory.getLogger(DeviceAppControllerV1Test.class);
    private String              deviceId;
    private String              predixMachineDeviceId;
    private Map<String, Object> queryParams;
    private String              platformType;
    private List<String>        statusList;
    private List<String>        typeList;

    @Override
    @BeforeClass
    public void init()
    {
        deviceId = Configuration.getConfig().getQeEADeviceName();
        predixMachineDeviceId = Configuration.getConfig().getQePMDeviceName();
        _logger.info("Device ID = {} ", deviceId);
        _logger.info("Predix Machine Device ID = {} ", predixMachineDeviceId);
        platformType = "container";
        statusList = Arrays.asList("running", "starting", "stopping", "stopped", "error");
        typeList = Arrays.asList("system", "user", "unknown");
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get device applications", description = "Get device applications", preCondition = "System should have devices to get its applications")
    public void testGetDeviceApplications()
    {
        if (deviceId == null)
        {
            throw new SkipException("Skipping as QE device is not configured for this environment.");
        }

        Response response = DeviceAppManagementControllerUtils.getApplications(deviceId, null);
        List<Map<String, Object>> deviceApps = response.jsonPath().getList("$");

        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK,
                String.format("Expected status code is %d. Found %d", HttpStatus.SC_OK, response.statusCode()));
        softAssert.assertNotNull(deviceApps.get(0).get("id"), "application should have id");
        softAssert.assertNotNull(deviceApps.get(0).get("name"), "application should have name");
        softAssert.assertNotNull(deviceApps.get(0).get("version"), "application should have version");
        softAssert.assertNotNull(deviceApps.get(0).get("type"), "application should have type");
        softAssert.assertNotNull(deviceApps.get(0).get("platformName"), "application should have platformName");
        softAssert.assertNotNull(deviceApps.get(0).get("platformVersion"), "application should have platformVersion");
        softAssert.assertNotNull(deviceApps.get(0).get("platformType"), "application should have platformType");
        softAssert.assertNotNull(deviceApps.get(0).get("status"), "application should have status");
        softAssert.assertNotNull(deviceApps.get(0).get("lastUpdated"), "application should have lastUpdated");
        softAssert.assertEquals(deviceApps.get(0).get("platformType"), platformType, String
                .format("Expected platformType  is %s. Found %s", platformType, deviceApps.get(0).get("platformType")));
        softAssert.assertTrue(statusList.contains(deviceApps.get(0).get("status")),
                String.format("Expected status is any one of [ running, starting, stopping, stopped,error ] . Found %s",
                        deviceApps.get(0).get("status")));
        softAssert.assertTrue(typeList.contains(deviceApps.get(0).get("type")), String.format(
                "Expected type is any one of [ system, user, unknown ] . Found %s", deviceApps.get(0).get("type")));
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get device applications using invalid platform type", description = "Get device applications using invalid platform type and validate the status code as 400(Bad Request)", preCondition = "System should have devices to get its applications")
    public void testGetDeviceAppsWithInvalidPlatform()
    {
        if (deviceId == null)
        {
            throw new SkipException("Skipping as QE device is not configured for this environment.");
        }

        queryParams = new HashMap<>();
        queryParams.put("platformTypes", "container111");
        Response response = DeviceAppManagementControllerUtils.getApplications(deviceId, queryParams);
        Map<String, Object> deviceApps = response.jsonPath().getMap("$");

        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_BAD_REQUEST, String
                .format("Expected status code is %d. Found %d", HttpStatus.SC_BAD_REQUEST, response.statusCode()));
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get device applications using invalid device id", description = "Get device applications using invalid device id and validate the status code as 404(Not Found)", preCondition = "System should have devices to get its applications")
    public void testGetDeviceAppsWithInvalidDeviceId()
    {
        Response response = DeviceAppManagementControllerUtils.getApplications("invalidDeviceId", null);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_NOT_FOUND,
                String.format("Expected status code is %d. Found %d", HttpStatus.SC_NOT_FOUND, response.statusCode()));
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get device applications using PredixMachine Device Id", description = "Get device applications using PredixMachine Device Id and validate the status code as 200(OK)", preCondition = "System should have devices to get its applications")
    public void testGetDeviceAppsWithPredixMachineDeviceId()
    {
        Response response = DeviceAppManagementControllerUtils.getApplications(predixMachineDeviceId, null);
        List<Map<String, Object>> deviceApps = response.jsonPath().getList("$");
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK,
                String.format("Expected status code is %d. Found %d", HttpStatus.SC_OK, response.statusCode()));
        softAssert.assertTrue(deviceApps.isEmpty());
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get device applications by passing the application Id", description = "Get device applications by passing the application Id", preCondition = "System should have devices to get its applications")
    public void testGetDeviceApplication()
    {
        if (deviceId == null)
        {
            throw new SkipException("Skipping as QE device is not configured for this environment.");
        }

        String applicationId = getApplicationId();
        _logger.info("Application ID = {} ", applicationId);

        Response response = DeviceAppManagementControllerUtils.getApplication(deviceId, null, applicationId);
        Map<String, Object> deviceApps = response.jsonPath().getMap("$");

        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK,
                String.format("Expected status code is %d. Found %d", HttpStatus.SC_OK, response.statusCode()));
        softAssert.assertNotNull(deviceApps.get("id"), "application should have id");
        softAssert.assertNotNull(deviceApps.get("name"), "application should have name");
        softAssert.assertNotNull(deviceApps.get("version"), "application should have version");
        softAssert.assertNotNull(deviceApps.get("type"), "application should have type");
        softAssert.assertNotNull(deviceApps.get("platformName"), "application should have platformName");
        softAssert.assertNotNull(deviceApps.get("platformVersion"), "application should have platformVersion");
        softAssert.assertNotNull(deviceApps.get("platformType"), "application should have platformType");
        softAssert.assertNotNull(deviceApps.get("status"), "application should have status");
        softAssert.assertNotNull(deviceApps.get("lastUpdated"), "application should have lastUpdated");
        softAssert.assertNotNull(deviceApps.get("payload"), "application should have payload");
        softAssert.assertEquals(deviceApps.get("platformType"), platformType,
                String.format("Expected platformType  is %s. Found %s", platformType, deviceApps.get("platformType")));
        softAssert.assertTrue(statusList.contains(deviceApps.get("status")),
                String.format("Expected status is any one of [ running, starting, stopping, stopped,error ] . Found %s",
                        deviceApps.get("status")));
        softAssert.assertTrue(typeList.contains(deviceApps.get("type")), String
                .format("Expected type is any one of [ system, user, unknown ] . Found %s", deviceApps.get("type")));
        softAssert.assertAll();
    }

    public String getApplicationId()
    {
        if (deviceId == null)
        {
            throw new SkipException("Skipping as QE device is not configured for this environment.");
        }

        Response response = DeviceAppManagementControllerUtils.getApplications(deviceId, null);
        List<Map<String, Object>> deviceApps = response.jsonPath().getList("$");
        _logger.info("deviceApps is " + deviceApps);
        return (String) deviceApps.get(0).get("id");
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get device applications using invalid device id", description = "Get device applications using invalid device Id and validate the status code as 404(Not Found)", preCondition = "System should have devices to get its applications")
    public void testGetDeviceAppWithInvalidDevice()
    {
        Response response = DeviceAppManagementControllerUtils.getApplication("invalidDevice", null,
                "c69b2cea-aac5-4839-8a52-fd4a1dd8bc2b");
        Map<String, Object> deviceApps = response.jsonPath().getMap("$");
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_NOT_FOUND,
                String.format("Expected status code is %d. Found %d", HttpStatus.SC_NOT_FOUND, response.statusCode()));
        softAssert.assertAll();
    }
}
