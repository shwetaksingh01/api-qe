/*
 * Copyright (c) 2019 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.emapi.utils;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.dspmicro.qe.device.utils.DeviceManagementControllerUtils;
import com.ge.dspmicro.qe.tools.environment.Configuration;
import com.ge.dspmicro.qe.tools.utils.CertEnrolledDeviceInfo;
import com.ge.dspmicro.qe.tools.utils.DeviceManagementUtils;
import com.ge.dspmicro.qe.tools.utils.RestClient;
import com.ge.dspmicro.qe.tools.utils.Token;
import com.ge.predixmachine.datamodel.gateway.EdgeGatewayRequest;
import com.ge.predixmachine.datamodel.gateway.Status;
import com.ge.predixmachine.datamodel.gateway.TaskStatus;
import com.ge.predixmachine.datamodel.gateway.TaskType;
import com.ge.predixmachine.datamodel.packagecomm.PackageStatus;
import com.google.protobuf.Timestamp;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;

/**
 * 
 * @author 212547153
 */

@SuppressWarnings(value =
{
        "javadoc", "nls"
})
public class DeviceControllerUtils
{
    private static final String BASE_URI    = EmapiConstants.EM_API_BETA_BASE + "/device-management/devices";
    private static final String BASE_URI_V1 = EmapiConstants.EM_API_BASE + "/device-management/devices";
    static Configuration        cfg         = Configuration.getConfig();
    static Token                token       = cfg.getAdminUAAToken();
    static Logger               _logger     = LoggerFactory.getLogger(DeviceControllerUtils.class);
    private static final String MODEL       = "FieldAgent";
    private static final String SECRET      = "shared-secret";

    public static CertEnrolledDeviceInfo addAndEnrollDevice(String deviceId)
    {
        // delete device if it exists
        DeviceManagementControllerUtils.deleteDevice(deviceId);

        // add new device
        Response response = DeviceManagementControllerUtils.addDeviceV2(deviceId, "0", MODEL, deviceId, SECRET);
        response.then().assertThat().statusCode(201);

        return DeviceManagementUtils.enrollEdgeAgentDevice(deviceId, SECRET);
    }

    public static Map<String, String> getOperationDevicesDetails(String operationId, String key)
            throws InterruptedException
    {
        Response response;
        List<Map<String, Object>> details = null;
        for (int i = 0; i < 5; i++)
        {
            response = PackageDeploymentControllerUtils.getPackageOperationDetailsV1(operationId, "");
            JsonPath jsonPath = response.jsonPath();

            details = jsonPath.getList("details");
            if ( details != null )
            {
                break;
            }
            else
            {
                Thread.sleep(1000 * (i + 1));
            }
        }
        Map<String, String> taskStatusMap = new HashMap<>();

        if ( details != null )
        {
            for (Map<String, Object> detail : details)
            {
                List<Map<String, Object>> tasks = (List<Map<String, Object>>) detail.get("tasks");
                for (Map<String, Object> task : tasks)
                {
                    taskStatusMap.put((String) detail.get("deviceId"), (String) task.get(key));
                }
            }
        }
        return taskStatusMap;
    }

    public static EdgeGatewayRequest buildUpdateTaskStatusSyncRequest(String deviceId, String deviceUUID,
            int syncInterval, String taskId, TaskStatus taskStatus, TaskType taskType)
    {
        // =================
        // Status
        // =================
        Timestamp timestampStart = Timestamp.newBuilder().setSeconds(10).build();
        Timestamp timestampStop = Timestamp.newBuilder().setSeconds(20).build();
        PackageStatus packageStatus = PackageStatus.newBuilder().setTaskId(taskId).setStatus(taskStatus)
                .setStatusDetailedMessage("Detailed message : Cloud-QE Tests Detailed Message")
                .setStatusMessage("Cloud-QE Tests Status Message").setStartTime(timestampStart)
                .setEndTime(timestampStop).build();
        Status status = Status.newBuilder().setPackageStatus(packageStatus).setTaskType(taskType).build();

        // ========================
        // EdgeGatewayRequest
        // ========================
        return EdgeGatewayRequest.newBuilder().setDeviceId(deviceId).setNumberOfTasks(1).setSyncInterval(syncInterval)
                .addStatus(status).setDeviceUUID(deviceUUID).build();
    }

    // POST /emapi/v1/device-management/devices Create a device
    public static Response createDeviceV1(String payload)
    {
        return RestClient.post(cfg.getEdgeManagerUrl(), BASE_URI_V1, payload, token);
    }

    // POST /emapi/v1/device-management/devices Create a device
    public static Response createDeviceWithDeviceIdAndModeldIdV1(String deviceId, String modelId)
    {
        String payload = "{\"modelId\":\"$modelId\",\"name\":\"$deviceId\",\"deviceId\":\"$deviceId\",\"sharedSecret\":\"sharedSecret\"}"
                .replaceAll("\\$deviceId", deviceId).replaceAll("\\$modelId", modelId);
        _logger.info("\tAddDevicePayload: " + payload);
        return RestClient.post(cfg.getEdgeManagerUrl(), BASE_URI_V1, payload, token);
    }

    // DELETE /emapi/v1/device-management/devices/{deviceId} Remove a device
    public static Response deleteDeviceV1(String deviceId)
    {
        return RestClient.delete(cfg.getEdgeManagerUrl(), BASE_URI_V1 + "/" + deviceId, token);
    }

    /**
     * @param groupId
     *            : GroupId of the Device Group
     * @param csvFile
     *            : csv file with list of devices to be uploaded
     * @return Response
     */
    public static Response addDevicesFromCsvV1(String groupId, String csvFile)
    {

        return RestClient.postWithMultiPart(cfg.getEdgeManagerUrl(),
                EmapiConstants.EM_API_BASE + "/device-management/groups/" + groupId + "/csv-upload-devices", csvFile,
                token);

    }

    // GET /emapi/v1/device-management/devices/{deviceId} Get metadata for specified device
    public static Response getDeviceDetailsV1(String deviceId)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_V1 + "/" + deviceId, null, token);
    }

    // GET /emapi/v1/device-management/devices/{deviceId} Get metadata for specified device
    public static Response getDeviceDetailsWithKeysV1(String deviceId, String keys)
    {
        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("keys", keys);
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_V1 + "/" + deviceId, queryParams, token);
    }

    // GET /emapi/v1/device-management/devices/{deviceId} Get metadata for specified device
    public static Response getDeviceDetailsWithKeyV1(String deviceId, String keys)
    {
        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("keys", keys);
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_V1 + "/" + deviceId + "?keys=" + keys, queryParams,
                token);
    }

    // GET /emapi/v1/device-management/devices/{deviceId} Get metadata for specified device
    public static Response getDeviceDetailsWithNameKeyV1(String deviceName, String keys)
    {
        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("keys", keys);
        return RestClient.get(cfg.getEdgeManagerUrl(),
                BASE_URI_V1 + "?filter=name eq \"" + deviceName + "\"" + "&keys=" + keys, queryParams, token);
    }

    // PATCH /emapi/v1/device-management/devices/{deviceId} Update a device
    public static Response updateDeviceV1(String deviceId, String payload)
    {
        return RestClient.patch(cfg.getEdgeManagerUrl(), BASE_URI_V1 + "/" + deviceId, payload, token);

    }

    // GET /emapi/v1/device-management/devices/attributes Retrieve list of defined attributes for device, including the attribute name, type and display name
    public static Response getDeviceAttributesV1()
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_V1+"/attributes", null, token);
    }

    // GET /emapi/v1/device-management/devices/{deviceId}/path Get device group hierarchy of the specified device
    public static Response getDeviceGroupPathV1(String deviceId)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_V1 + "/" + deviceId + "/path", null, token);
    }

    // POST /emapi/v1/device-management/devices/export Export devices meta data into csv file
    public static Response exportDevicesToCsvV1(String payload, String groupId)
    {
        Map<String, Object> params = new HashMap<>();
        if ( groupId != null )
        {
            params.put("groupId", groupId);
        }
        if ( payload == null )
        {

            return RestClient.postWithParams(cfg.getEdgeManagerUrl(), BASE_URI_V1 + "/export", params, token);
        }
        return RestClient.postWithParams(cfg.getEdgeManagerUrl(), BASE_URI_V1 + "/export", params, payload, token);

    }

    // GET /emapi/v1/device-management/devices/ Get device details with filter
    public static Response getDevicesWithFilterAndLimitV1(String filter, int limit)
    {
        Map<String, Object> queryParams = new HashMap<>();

        queryParams.put("limit", limit);
        queryParams.put("filter", filter);
        queryParams.put("offset", 0);

        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_V1, queryParams, token);
    }

    // GET /emapi/v1/device-management/devices/ Get device details with filter
    public static Response getDevicePathV1(String deviceId)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_V1 + "/" + deviceId + "/path", null, token);
    }

    public static Response getDevicesCountWithFilterV1(String filter)
    {
        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("filter", filter);
        return RestClient.head(cfg.getEdgeManagerUrl(), BASE_URI_V1, queryParams, token);
    }

    // GET /emapi/v1/device-management/devices Get metadata for the device list
    public static Response getDevicesV1(Map<String, Object> params)
    {

        // filter=filter&
        // groupFilter=groupFilter&
        // limit=10&
        // offset=0&
        // contains=abcd&
        // sort=name&
        // order=desc&
        // keys=keys
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_V1, params, token);
    }

    // DELETE /emapi/v1/device-management/devices/batch Create an operation to remove a list of devices
    public static Response batchDeleteDevicesV1(String payload)
    {
        return RestClient.post(cfg.getEdgeManagerUrl(), BASE_URI_V1 + "/batch-delete", payload, token);
    }

    // POST /emapi/v1/device-management/devices/batch Create asynchronous operation to add a list of devices.
    public static Response batchAddDevicesV1(String payload)
    {
        return RestClient.post(cfg.getEdgeManagerUrl(), BASE_URI_V1 + "/batch-create", payload, token);
    }

    // GET /emapi/v1/device-management/devices/{deviceId}/capabilities
    public static Response getDeviceCapabilitiesV1(String deviceId)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_V1 + "/" + deviceId + "/capabilities", null, token);
    }

    // GET GET /emapi/v1/device-management/devices/{deviceId}/capabilities/status
    public static Response getDeviceCapabilityStatusV1(String deviceId, String capabilityId, String capabilityVersion,
            String handler)
    {
        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("capabilityId", capabilityId);
        queryParams.put("capabilityVersion", capabilityVersion);
        queryParams.put("handler", handler);
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_V1 + "/" + deviceId + "/capabilities/status",
                queryParams, token);
    }

    public static String deployApplicationPayload(String name, String type, String version, String filter,
            String appInstanceId, boolean isApplication)
            throws Exception
    {
        Map<String, Object> payLoad = new HashMap<>();
        payLoad.put("deviceFilter", filter);
        payLoad.put("name", name);
        payLoad.put("type", type);
        payLoad.put("version", version);
        Map<String, Object> strategyInsideObj = new HashMap<>();
        strategyInsideObj.put("type", "simple");
        if ( isApplication )
        {
            Map<String, Object> paramsObj = new HashMap<>();
            paramsObj.put("appInstanceId", appInstanceId);
            strategyInsideObj.put("params", paramsObj);

        }
        payLoad.put("strategy", strategyInsideObj);
        return new ObjectMapper().configure(SerializationConfig.Feature.FAIL_ON_EMPTY_BEANS, false)
                .writeValueAsString(payLoad);
    }

    private static Integer getCommandIdDisplayNameContains(String displayName)
    {
        return RestClient
                .get(cfg.getEdgeManagerUrl(),
                        "/svc/command/v1/commands?filter=commandDisplayName eq \"" + displayName + "\"", null, token)
                .body().path("[0].commandId");
    }

    public void setToken(Token token)
    {
        DeviceControllerUtils.token = token;
    }

    public Token getToken()
    {
        return DeviceControllerUtils.token;
    }

}
