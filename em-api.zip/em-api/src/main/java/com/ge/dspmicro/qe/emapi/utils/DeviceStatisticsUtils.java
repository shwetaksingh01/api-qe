/*
 * Copyright (c) 2018 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.emapi.utils;

import java.util.Map;

import com.ge.dspmicro.qe.tools.environment.Configuration;
import com.ge.dspmicro.qe.tools.utils.RestClient;
import com.ge.dspmicro.qe.tools.utils.Token;
import com.jayway.restassured.response.Response;

/**
 * @author 212445102
 */
@SuppressWarnings(value =
{
        "javadoc", "nls"
})
public class DeviceStatisticsUtils
{

    static Configuration        cfg           = Configuration.getConfig();
    private static Token        token         = cfg.getAdminUAAToken();

    private static final String BASE_URI_BETA = EmapiConstants.EM_API_BETA_BASE + "/device-management/devices";
    private static final String BASE_URI_V1   = EmapiConstants.EM_API_BASE + "/device-management/devices";

    // GET /emapi/v1/device-management/devices/{deviceId}/events
    public static Response getEventsV1(String deviceId, Map<String, ?> queryParams)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_V1 + "/" + deviceId + "/events", queryParams, token);
    }

    // GET /emapi/v1/device-management/devices/{deviceId}/resources
    public static Response getResourcesV1(String deviceId, Map<String, ?> queryParams)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_V1 + "/" + deviceId + "/resources", queryParams, token);
    }

    public void setToken(Token token)
    {
        DeviceStatisticsUtils.token = token;
    }

    public Token getToken()
    {
        return DeviceStatisticsUtils.token;
    }
}
