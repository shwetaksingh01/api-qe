/*
 * Copyright (c) 2019 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.emapi.utils;

import java.util.Map;

import com.ge.dspmicro.qe.tools.environment.Configuration;
import com.ge.dspmicro.qe.tools.utils.RestClient;
import com.ge.dspmicro.qe.tools.utils.Token;
import com.jayway.restassured.response.Response;

/**
 *
 * @author 212729715
 */
@SuppressWarnings(
{
        "nls", "javadoc"
})
public class DeviceAppManagementControllerUtils
{
    static Configuration        cfg              = Configuration.getConfig();
    private static Token        token            = cfg.getAdminUAAToken();
    private static final String BASE_URI_COMMAND = EmapiConstants.EM_API_BASE + "/device-management/devices";

    // GET emapi/v1/device-management/devices/{deviceId}/applications //Retrieve edge applications for a specified device
    public static Response getApplications(String deviceId, Map queryParams)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_COMMAND + "/" + deviceId + "/applications", queryParams,
                token);
    }

    // GET /emapi/v1/device-management/devices/{deviceId}/applications/{applicationId} //Retrieve the details for a specified edge application
    public static Response getApplication(String deviceId, Map queryParams, String applicationId)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(),
                BASE_URI_COMMAND + "/" + deviceId + "/applications" + "/" + applicationId, queryParams, token);
    }

    public void setToken(Token token)
    {
        DeviceAppManagementControllerUtils.token = token;
    }

    public Token getToken()
    {
        return DeviceAppManagementControllerUtils.token;
    }
}
