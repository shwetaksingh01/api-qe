/*
 * Copyright (c) 2019 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.emapi.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.dspmicro.qe.tools.environment.Configuration;
import com.ge.dspmicro.qe.tools.utils.RestClient;
import com.ge.dspmicro.qe.tools.utils.Token;
import com.jayway.restassured.response.Response;

/**
 * 
 * @author 212547153
 */

@SuppressWarnings(value =
{
        "javadoc", "nls"
})
public class AlertThresholdControllerUtils
{
    private static Logger        _logger             = LoggerFactory.getLogger(AlertThresholdControllerUtils.class);
    private static Configuration cfg                 = Configuration.getConfig();
    private static Token         token               = cfg.getAdminUAAToken();
    private static final String  BASE_URI            = "/emapi/v1/alert-management/";
    private static final String  ALERT_THRESHOLD_URI = BASE_URI + "thresholds";

    // POST /emapi/v1/alert-management/thresholds
    public static Response createThresholds(String payload)
    {
        return RestClient.post(cfg.getEdgeManagerUrl(), ALERT_THRESHOLD_URI, payload, token);
    }

    // GET /emapi/v1/alert-management/thresholds
    public static Response getThresholds()
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), ALERT_THRESHOLD_URI, null, token);
    }

    // PUT /emapi/v1/alert-management/thresholds/{name}
    public static Response updateThresholds(String thresholdName, String payload)
    {
        return RestClient.put(cfg.getEdgeManagerUrl(), ALERT_THRESHOLD_URI + "/" + thresholdName, payload, token);
    }

    // DELETE /emapi/v1/alert-management/thresholds/{name}
    public static Response deleteThreshold(String thresholdName)
    {
        return RestClient.delete(cfg.getEdgeManagerUrl(), ALERT_THRESHOLD_URI + "/" + thresholdName, token);
    }

    // PUT /emapi/v1/alert-management/thresholds/{thresholdName}/assign
    public static Response assignThresholdToDevices(String thresholdName, String payload)
    {
        return RestClient.put(cfg.getEdgeManagerUrl(), ALERT_THRESHOLD_URI + "/" + thresholdName + "/assign", payload,
                token);
    }

    // PUT /emapi/v1/alert-management/thresholds/{thresholdName}/assign
    public static Response assignThresholdToDevicesWithDeviceFilter(String thresholdName, String deviceFilter)
    {
        String payload = "{\"deviceFilter\": \"DEVICE_FILTER\", \"type\": \"device-online-offline\"}"
                .replaceAll("DEVICE_FILTER", deviceFilter);
        _logger.info("\tAssign Threshold Payload: " + payload);
        return RestClient.put(cfg.getEdgeManagerUrl(), ALERT_THRESHOLD_URI + "/" + thresholdName + "/assign", payload,
                token); /// svc/alert/v1/alert-mgmt/devices/
    }

    // GET /emapi/v1/alert-management/devices/{deviceId}/thresholds
    public static Response getThresholdForDevice(String deviceId)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI + "devices/" + deviceId + "/thresholds", null, token);
    }

    // PUT /emapi/v1/alert-management/thresholds/alerttype/unassign
    public static Response unassignThresholdForDevice(String payload)
    {
        return RestClient.put(cfg.getEdgeManagerUrl(), ALERT_THRESHOLD_URI + "/alerttype/unassign", payload, token);
    }

    // PUT /emapi/v1/alert-management/thresholds/{thresholdName}/assign
    public static Response unassignThresholdWithDeviceFilter(String deviceFilter)
    {
        String payload = "{\"deviceFilter\": \"DEVICE_FILTER\", \"type\": \"device-online-offline\"}"
                .replaceAll("DEVICE_FILTER", deviceFilter);
        _logger.info("\tUnassign Threshold Payload: " + payload);
        return RestClient.put(cfg.getEdgeManagerUrl(), ALERT_THRESHOLD_URI + "/alerttype/unassign", payload, token);
    }

    public void setToken(Token token)
    {
        AlertThresholdControllerUtils.token = token;
    }

    public Token getToken()
    {
        return AlertThresholdControllerUtils.token;
    }
}
