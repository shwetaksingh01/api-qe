/*
 * Copyright (c) 2019 General Electric Company. All rights reserved.

 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.emapi.test;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.security.SignatureException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ge.dspmicro.edgegateway.EdgeGatewayUtils;
import com.ge.dspmicro.qe.emapi.pojo.PackagePojo;
import com.ge.dspmicro.qe.emapi.utils.DeviceControllerUtils;
import com.ge.dspmicro.qe.emapi.utils.EmapiConstants;
import com.ge.dspmicro.qe.emapi.utils.PackageDeploymentControllerUtils;
import com.ge.dspmicro.qe.emapi.utils.PackageManagementControllerUtils;
import com.ge.dspmicro.qe.emapi.utils.TestUtils;
import com.ge.dspmicro.qe.tools.BaseTest;
import com.ge.dspmicro.qe.tools.QEConstants;
import com.ge.dspmicro.qe.tools.environment.Configuration;
import com.ge.dspmicro.qe.tools.testng.TestListener;
import com.ge.dspmicro.qe.tools.utils.CertEnrolledDeviceInfo;
import com.ge.dspmicro.qe.tools.utils.CommonUtils;
import com.ge.predix.edgemanager.qe.annotations.JiraTestCaseInfo;
import com.ge.predixmachine.datamodel.gateway.EdgeGatewayRequest;
import com.ge.predixmachine.datamodel.gateway.TaskStatus;
import com.ge.predixmachine.datamodel.gateway.TaskType;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;

/**
 * @author 212722187
 */
@SuppressWarnings(
{
        "nls", "javadoc"
})
@Listeners(TestListener.class)
public class PackageManagementControllerV1Test extends BaseTest
{
    private static final Logger _logger     = LoggerFactory.getLogger(PackageManagementControllerV1Test.class);
    private List<String>        deviceList  = new ArrayList<>();
    static List<PackagePojo>    packageList = new ArrayList<>();
    static List<String>         uploadIds   = new ArrayList<>();
    static String               str255      = "G20t6VRlhGaggGyLQwExZpIApqqHVwnmy3kGcvaaGHewXgE11s2kwWbhUTythx9cvDTkpmz8WYrYCWGVbGoQAhOjoWbTcmUQ6UsQU1444Zsk8HZ8RbL5Ek6ayG9AFVZjO1PRwYG8l3elWPcIPl60rISBWbsEApfUNUzYATVzC8NwuvsWkYPMrNFEQScRwe99zQleXceGsmva0qozO4vhiZDJSQi9NvuWGDTu0Kji2hFM5nUFaZFkzzBPwCujpHe";

    /**
     * Set the respective value before running the tests;
     */
    @Override
    @BeforeClass(alwaysRun = true)
    public void init()
    {
        cfg = Configuration.getConfig();
    }

    /**
     * Get the list of the packages;
     */
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get the list of packages for a Device", description = "Get the list of packages for a Device and validate the status code as 200(OK)", preCondition = "Packages should be available for a device")
    public void testGetPackageListV1()
            throws InterruptedException
    {
        PackagePojo pkg = new PackagePojo("machine", "configuration", "fail.zip");
        if ( uploadNewPackage(pkg) )
        {
            packageList.add(pkg);
        }
        Response response = PackageManagementControllerUtils.getPackageListV1();
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
        String packageLists = response.getBody().jsonPath().prettify();
        softAssert.assertTrue(packageLists.startsWith("["));
        softAssert.assertTrue(packageLists.endsWith("]"));

        // getting the list of the packages with filter.
        response = PackageManagementControllerUtils.getPackageListV1(pkg.getName(), null, "name", "desc");
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
        softAssert.assertTrue(response.getBody().jsonPath().getString("version").contains(pkg.getVersion()));
        softAssert.assertTrue(response.getBody().jsonPath().getString("name").contains(pkg.getName()));

        // bad request.
        response = PackageManagementControllerUtils.getPackageListV1(pkg.getName(), null, "name", "error error");
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_BAD_REQUEST);
    }

    /**
     * Helper method to upload a new package to em.
     * 
     * @param pkg
     * @return true if package is uploaded successfully other wise false.
     * @throws InterruptedException
     */
    private boolean uploadNewPackage(PackagePojo pkg)
            throws InterruptedException
    {
        String payload = CommonUtils.getResourceAsString("/package/uploadRequest.json")
                .replaceAll("\\$NAME", pkg.getName()).replaceAll("\\$VERSION", pkg.getVersion())
                .replaceAll("\\$VENDOR", pkg.getVendor()).replaceAll("\\$DESCRIPTION", pkg.getDesc())
                .replaceAll("\\$TYPE", pkg.getType()).replaceAll("\\$NOTES", pkg.getNotes())
                .replaceAll("\\$HANDLER", pkg.getHandler()).replaceAll("\\$SIZE", pkg.getTotalBytes() + "")
                .replaceAll("\\$ATTRIBUTES", pkg.getAttributes());

        // 1. GetUploadId
        Response response = PackageManagementControllerUtils.createUploadIdV1(payload);

        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_CREATED,
                "createUploadId status code do not match expected code of 201");

        JsonPath jsonPath = response.jsonPath();

        // set uploadid in the pkg pojo
        pkg.setUploadId(jsonPath.getString("uploadId"));
        pkg.setFileName("configuration.zip");

        boolean isPkgUploaded = TestUtils.uploadPackage(pkg);
        if ( !isPkgUploaded )
        {
            uploadIds.add(pkg.getUploadId());
            response = PackageManagementControllerUtils.getPackageUploadStatusV1(pkg.getUploadId());
            _logger.info("\tFailed to upload package.");
        }
        return isPkgUploaded;
    }

    /**
     * Test case to get the list of the grouped by packages.
     *
     * @throws InterruptedException -- Interrupted Exception.
     */
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get the list of packages grouped by name", description = "et the list of packages grouped by name and validate the status code as 200(OK)", preCondition = "Packages grouped by name should be available in the system")
    public void testGetListofPackegeGroupedByName()
            throws InterruptedException
    {
        // 1. setup package meta data
        PackagePojo pkg1 = new PackagePojo("machine", "configuration", "fail.zip");
        if ( uploadNewPackage(pkg1) )
        {
            packageList.add(pkg1);
        }

        Thread.sleep(2000);

        PackagePojo pkg2 = new PackagePojo("machine", "configuration", "fail.zip");
        if ( uploadNewPackage(pkg2) )
        {
            packageList.add(pkg2);
        }

        Response response = PackageManagementControllerUtils.getGroupedPackagesV1(pkg1.getName(), null, "name", "desc");
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK,
                "get grouped package code do not match expected code of 201");

        softAssert.assertEquals(response.getBody().jsonPath().getString("name"), "[" + pkg1.getName() + "]");

        // test for the 400, order by value is invalid.
        response = PackageManagementControllerUtils.getGroupedPackagesV1("", null, "name", "error order");
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_BAD_REQUEST);

        // retrieve all the uploaded package.
        response = PackageManagementControllerUtils.getGroupedPackagesV1(
                "QE_Test-" + System.currentTimeMillis() / 1000000, "handler co \"machine\"", "name", "desc");
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK,
                "getGrouped package response code do not match expected code of HttpStatus.SC_OK");
        softAssert.assertTrue(response.getBody().jsonPath().getString("name").contains(pkg1.getName()));
        softAssert.assertTrue(response.getBody().jsonPath().getString("name").contains(pkg2.getName()));

    }

    /*
     * Test Case to verify upload (Success scenario)
     * 1. Get uploadId
     * 2. Start uploading package in a new thread
     * 3. Wait for upload to complete
     * 4. get upload status. Expected status successful
     * 5. cancel upload. Expected to fail
     */
    // Happy path E2E COMPLETE
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Test Upload Package,download Package,download Signature,download Metadata,verify Signature and update Package Metadata", description = "Test Upload Package,download Package,download Signature,download Metadata,verify Signature and update Package Metadata and validate the status code respectively", preCondition = "System should be stable and packages should be available to the user for deployment")
    public void testUploadPackage_downloadPackage_downloadSignature_downloadMetadata_verifySignature_updatePackageMetadata()
            throws InterruptedException, IOException
    {
        HashSet<String> statusSet = new LinkedHashSet<>(); // linked list to get all the status while package upload

        // Step 1:get uploadId

        PackagePojo pkg = new PackagePojo("machine", "application", "machine_large.zip");

        packageList.add(pkg);
        String payload = CommonUtils.getResourceAsString("/package/uploadRequest.json")
                .replaceAll("\\$NAME", pkg.getName()).replaceAll("\\$VERSION", pkg.getVersion())
                .replaceAll("\\$VENDOR", pkg.getVendor()).replaceAll("\\$DESCRIPTION", pkg.getDesc())
                .replaceAll("\\$TYPE", pkg.getType()).replaceAll("\\$NOTES", pkg.getNotes())
                .replaceAll("\\$HANDLER", pkg.getHandler()).replaceAll("\\$SIZE", pkg.getTotalBytes() + "")
                .replaceAll("\\$ATTRIBUTES", pkg.getAttributes());

        Response response = PackageManagementControllerUtils.createUploadIdV1(payload);

        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_CREATED,
                "createUploadId status code do not match expected code of 201");

        JsonPath jsonPath = response.jsonPath();

        // set uploadid in the pkg pojo
        pkg.setUploadId(jsonPath.getString("uploadId"));

        String status = jsonPath.getString("status");
        softAssert.assertTrue(CommonUtils.isLowerCase(status));
        statusSet.add(status);
        softAssert.assertEquals(jsonPath.getString("name"), pkg.getName(), "createUploadId name assertion failed");
        softAssert.assertEquals(jsonPath.getString("version"), pkg.getVersion(),
                "createUploadId version assertion failed");
        softAssert.assertEquals(jsonPath.getString("vendor"), pkg.getVendor(),
                "createUploadId vendor assertion failed");
        softAssert.assertEquals(jsonPath.getString("description"), pkg.getDesc(),
                "createUploadId description assertion failed");
        softAssert.assertEquals(jsonPath.getString("type"), pkg.getType(), "createUploadId name type failed");
        softAssert.assertEquals(jsonPath.getString("notes"), pkg.getNotes(), "createUploadId name notes failed");
        softAssert.assertEquals(jsonPath.getString("handler"), pkg.getHandler(),
                "createUploadId handler assertion failed");
        // softAssert.assertEquals(jsonPath.getString("containerType"), pkg.getContainerType(),
        // "createUploadId conatinerType assertion failed");
        softAssert.assertEquals(jsonPath.getLong("totalBytes"), pkg.getTotalBytes(),
                "createUploadId totalBytes assertion failed");
        softAssert.assertNotNull(jsonPath.getString("uploadId"), "createUploadId uploadId is null");
        softAssert.assertEquals(jsonPath.getString("status"), "pending-upload", "createUploadId status is null");
        softAssert.assertEquals(jsonPath.getString("uploadedBy"), cfg.getApiClientId(),
                "uploadedBy do not match clientId");
        _logger.info("\tpackage upload id: " + jsonPath.getString("uploadId"));

        // Step 2: upload file in new thread
        uploadPackageInNewThread(pkg.getUploadId(), pkg.getFileName(), statusSet);

        // Step 3: wait for package to upload
        int timeOut = 180; // 180 seconds
        int retryCount = 0;
        do
        {
            retryCount++;
            _logger.info("\tPackage Upload Test: checking upload status try " + retryCount);
            response = PackageManagementControllerUtils.getPackageUploadStatusV1(pkg.getUploadId());
            softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK,
                    "getPackageUploadStatus status code do not match expected code of 200");

            jsonPath = response.jsonPath();
            status = jsonPath.getString("status");
            statusSet.add(status);
            // assert on response once
            if ( retryCount < 2 )
            {
                softAssert.assertEquals(jsonPath.getString("name"), pkg.getName(),
                        "getPackageUploadStatus name assertion failed");
                softAssert.assertEquals(jsonPath.getString("version"), pkg.getVersion(),
                        "getPackageUploadStatus version assertion failed");
                softAssert.assertEquals(jsonPath.getString("vendor"), pkg.getVendor(),
                        "getPackageUploadStatus vendor assertion failed");
                softAssert.assertEquals(jsonPath.getString("description"), pkg.getDesc(),
                        "getPackageUploadStatus description assertion failed");
                softAssert.assertEquals(jsonPath.getString("type"), pkg.getType(),
                        "getPackageUploadStatus name type failed");
                softAssert.assertEquals(jsonPath.getString("notes"), pkg.getNotes(),
                        "getPackageUploadStatus name notes failed");
                softAssert.assertEquals(jsonPath.getString("handler"), pkg.getHandler(),
                        "getPackageUploadStatus handler assertion failed");
                // softAssert.assertEquals(jsonPath.getString("containerType"), pkg.getContainerType(),
                // "getPackageUploadStatus conatinerType assertion failed");
                softAssert.assertEquals(jsonPath.getLong("totalBytes"), pkg.getTotalBytes(),
                        "getPackageUploadStatus totalBytes assertion failed");
                softAssert.assertEquals(jsonPath.getString("uploadId"), pkg.getUploadId(),
                        "getPackageUploadStatus uploadId assertion failed");
                softAssert.assertEquals(jsonPath.getString("uploadedBy"), cfg.getApiClientId(),
                        "uploadedBy do not match clientId");
            }
            if ( !status.equals("successful") && !status.equals("failed") )
            {
                // sleep for 5 seconds
                timeOut = timeOut - 1;
                Thread.sleep(500);

            }
            else
            {
                softAssert.assertEquals("successful", jsonPath.getString("status"), "Status assertion failed.");
                softAssert.assertEquals(jsonPath.getInt("progressPercentage") + "", 100 + "", "getPackageUploadStatus "
                        + retryCount + " progressPercentage assertion after successful upload failed");
                softAssert.assertEquals(jsonPath.getLong("processedBytes"), pkg.getTotalBytes(),
                        "getPackageUploadStatus " + retryCount
                                + " processedBytes assertion after successful upload failed");
                break;
            }
        }
        while (timeOut > 0);

        // assert on different status during upload
        _logger.info("\tOrder of status during package upload: " + statusSet.toString());
        softAssert.assertEquals(statusSet.toString(), "[pending-upload, uploading, validating, successful]",
                "status set do not match");

        Thread.sleep(1500);
        PackageManagementControllerUtils.getPackageUploadStatusV1(pkg.getUploadId());
        response = PackageManagementControllerUtils.cancelUploadV1(pkg.getUploadId());
        assertEquals(response.statusCode(), HttpStatus.SC_NOT_FOUND);

        // download the package and compare contents

        // download package
        response = PackageManagementControllerUtils.downloadPackageV1(pkg.getType(), pkg.getName(), pkg.getVersion());
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK,
                "Download Package Status code do not match. Expected 200 found " + response.statusCode());
        // save config to file
        String downloadFileName = System.currentTimeMillis() + ".zip";

        CommonUtils.writeResponseToFile(response, downloadFileName);

        // assert that downloaded file contents match with the uploades file.
        softAssert.assertTrue(FileUtils.contentEquals(new File("machine_large.zip"), new File(downloadFileName)),
                "files donot match");

        // Download Package Signature
        response = PackageManagementControllerUtils.downloadPackageSignatureV1(pkg.getType(), pkg.getName(),
                pkg.getVersion());
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK,
                "downloadPackageSignature Status code do not match. Expected 200 found " + response.statusCode());
        // non-acceptable
        // response = PackageManagementControllerUtils.downloadPackageSignature("Invalid package Name", pkg.getName(),
        // pkg.getVersion());
        // softAssert.assertEquals(response.statusCode(), 406,
        // "downloadPackageSignature Status code do not match. Expected 403 found " + response.statusCode());

        softAssert.assertTrue(response.asString().contains("sigType=sha256"), "signature missing signType");
        softAssert.assertTrue(response.asString().contains("packageType=application"), "signature missing packageType");
        softAssert.assertTrue(response.asString().contains("appName=" + pkg.getName()), "signature missing appName");
        softAssert.assertTrue(response.asString().contains("version=" + pkg.getVersion()),
                "signature missing app version");
        softAssert.assertTrue(response.asString().contains("hash"), "signature missing hash");
        String pkgHash = response.asString().substring(response.asString().indexOf("hash=")).replaceAll("hash=", "");
        FileUtils.forceDelete(new File(downloadFileName));

        // Get Package Metadata
        response = PackageManagementControllerUtils.getPackageMetadataV1(pkg.getType(), pkg.getName(),
                pkg.getVersion());
        jsonPath = response.jsonPath();
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK,
                "getPackageMetadata Status code do not match. Expected 200 found " + response.statusCode());

        softAssert.assertEquals(jsonPath.getString("version"), pkg.getVersion(), "pkg metadata version do not match");
        softAssert.assertEquals(jsonPath.getString("vendor"), pkg.getVendor(), "pkg metadata vendor do not match");
        softAssert.assertEquals(jsonPath.getString("description"), pkg.getDesc(),
                "pkg metadata description do not match");
        softAssert.assertEquals(jsonPath.getString("handler"), pkg.getHandler(), "pkg metadata handler do not match");
        softAssert.assertEquals(jsonPath.getString("notes"), pkg.getNotes(), "pkg metadata notes do not match");
        softAssert.assertEquals(jsonPath.getString("name"), pkg.getName(), "pkg metadata name do not match");
        softAssert.assertEquals(jsonPath.getString("type"), pkg.getType(), "pkg metadata type do not match");
        softAssert.assertEquals(jsonPath.getString("uploadedBy"), cfg.getApiClientId(),
                "pkg metadata uploadedBy do not match");
        softAssert.assertTrue(jsonPath.getLong("uploaded") < System.currentTimeMillis(),
                "pkg metadata uploaded time is not before current time");
        softAssert.assertNotNull(jsonPath.getString("packageId"), "pkg metadata packageId is null");
        softAssert.assertTrue(jsonPath.getBoolean("active"), "pkg metadata active is false");

        // validate signature

        response = PackageManagementControllerUtils.verifySignatureV1(pkg.getType(), pkg.getName(), pkg.getVersion(),
                pkgHash.trim(), null, null);
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK,
                "verifySignature Status code do not match. Expected 200 found " + response.statusCode());
        response = PackageManagementControllerUtils.verifySignatureV1(pkg.getType(), pkg.getName(), "Invalid version",
                pkgHash.trim(), null, null);

        // update package metadata and validate
        String metaDataPayload = CommonUtils.getResourceAsString("/package/editMetadata.json")
                .replaceAll("PACKAGE_NAME", pkg.getName()).replaceAll("PACKAGE_VERSION", pkg.getVersion())
                .replaceAll("PACKAGE_TYPE", pkg.getType()).replaceAll("NOTES", "update package metadata test notes");
        response = PackageManagementControllerUtils.updatePackageMetadataV1(metaDataPayload);
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_NO_CONTENT,
                "updatePackageMetadata Status code do not match. Expected 204 found " + response.statusCode());

        // Get Package Metadata
        response = PackageManagementControllerUtils.getPackageMetadataV1(pkg.getType(), pkg.getName(),
                pkg.getVersion());
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK,
                "getPackageMetadata Status code do not match. Expected 200 found " + response.statusCode());

        jsonPath = response.jsonPath();

        softAssert.assertEquals(jsonPath.getString("version"), pkg.getVersion(), "pkg metadata version do not match");
        softAssert.assertEquals(jsonPath.getString("vendor"), pkg.getVendor(), "pkg metadata vendor do not match");
        softAssert.assertEquals(jsonPath.getString("description"), pkg.getDesc(),
                "pkg metadata description do not match");
        softAssert.assertEquals(jsonPath.getString("handler"), pkg.getHandler(), "pkg metadata handler do not match");

        softAssert.assertEquals(jsonPath.getString("notes"), "update package metadata test notes");

        softAssert.assertEquals(jsonPath.getString("name"), pkg.getName(), "pkg metadata name do not match");
        softAssert.assertEquals(jsonPath.getString("type"), pkg.getType(), "pkg metadata type do not match");
        softAssert.assertEquals(jsonPath.getString("uploadedBy"), cfg.getApiClientId(),
                "pkg metadata uploadedBy do not match");
        softAssert.assertTrue(jsonPath.getLong("uploaded") < System.currentTimeMillis(),
                "pkg metadata uploaded time is not before current time");
        softAssert.assertNotNull(jsonPath.getString("packageId"), "pkg metadata packageId is null");
        softAssert.assertTrue(jsonPath.getBoolean("active"), "pkg metadata active is false");

        softAssert.assertAll();

    }

    /**
     * Test Case to verify cancel upload when upload is in progress
     * 1. Get uploadId
     * 2. Start uploading package in a new thread
     * 3. Cancel upload
     * 4. get upload status
     *
     * @throws InterruptedException -- Interrupted Exception
     */
    // COMPLETE
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Test Cancel Upload when upload is InProgress", description = "Test Cancel Upload when upload is InProgress and validate the status code as 202(ACCEPTED)", preCondition = "System should be stable and packages should be available to the user for deployment")
    public void testCancelUploadWhenUploadInProgress()
            throws InterruptedException
    {

        // Step 1:get uploadId

        PackagePojo pkg = new PackagePojo("machine", "application", "machine.zip");

        String payload = CommonUtils.getResourceAsString("/package/uploadRequest.json")
                .replaceAll("\\$NAME", pkg.getName()).replaceAll("\\$VERSION", pkg.getVersion())
                .replaceAll("\\$VENDOR", pkg.getVendor()).replaceAll("\\$DESCRIPTION", pkg.getDesc())
                .replaceAll("\\$TYPE", pkg.getType()).replaceAll("\\$NOTES", pkg.getNotes())
                .replaceAll("\\$HANDLER", pkg.getHandler()).replaceAll("\\$SIZE", pkg.getTotalBytes() + "")
                .replaceAll("\\$ATTRIBUTES", pkg.getAttributes());

        Response response = PackageManagementControllerUtils.createUploadIdV1(payload);

        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_CREATED,
                "createUploadId status code do not match expected code of 201");

        // set uploadid in the pkg pojo
        JsonPath jsonPath = response.jsonPath();
        pkg.setUploadId(jsonPath.getString("uploadId"));

        // Step 2: upload file in new thread
        uploadPackageInNewThread(pkg.getUploadId(), pkg.getFileName());

        Thread.sleep(1500);

        // 3. Cancel upload
        response = PackageManagementControllerUtils.cancelUploadV1(pkg.getUploadId());
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_ACCEPTED, "Failed to cancel upload");

        // 4. get upload status

        response = PackageManagementControllerUtils.getPackageUploadStatusV1(pkg.getUploadId());
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_NOT_FOUND,
                "UplaodStatus response code do not match after cancelUpload");
        softAssert.assertEquals(response.jsonPath().getString("message"), "uploadId not found");
    }

    /**
     * Test if same package can be uploaded with mixed case name
     */
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Test if same package can be uploaded with mixed case name", description = "Test if same package can be uploaded with mixed case name(Lower case) and validate the status code as 200(Created)", preCondition = "System should be stable and packages should be available to the user for deployment")
    public void testUploadPackageWithSameNameDifferentCase()
    {
        PackagePojo pkg = new PackagePojo("machine", "application", "machine.zip");

        String payload = CommonUtils.getResourceAsString("/package/uploadRequest.json")
                .replaceAll("\\$NAME", pkg.getName()).replaceAll("\\$VERSION", pkg.getVersion())
                .replaceAll("\\$VENDOR", pkg.getVendor()).replaceAll("\\$DESCRIPTION", pkg.getDesc())
                .replaceAll("\\$TYPE", pkg.getType()).replaceAll("\\$NOTES", pkg.getNotes())
                .replaceAll("\\$HANDLER", pkg.getHandler()).replaceAll("\\$SIZE", pkg.getTotalBytes() + "")
                .replaceAll("\\$ATTRIBUTES", pkg.getAttributes());

        Response response = PackageManagementControllerUtils.createUploadIdV1(payload);

        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_CREATED,
                "createUploadId status code do not match expected code of 201");
        softAssert.assertNotNull(response.jsonPath().getString("uploadId"), "uploadId was not generated");
        uploadIds.add(response.jsonPath().getString("uploadId"));

        payload = CommonUtils.getResourceAsString("/package/uploadRequest.json")
                .replaceAll("\\$NAME", pkg.getName().toLowerCase()).replaceAll("\\$VERSION", pkg.getVersion())
                .replaceAll("\\$VENDOR", pkg.getVendor()).replaceAll("\\$DESCRIPTION", pkg.getDesc())
                .replaceAll("\\$TYPE", pkg.getType()).replaceAll("\\$NOTES", pkg.getNotes())
                .replaceAll("\\$HANDLER", pkg.getHandler()).replaceAll("\\$SIZE", pkg.getTotalBytes() + "")
                .replaceAll("\\$ATTRIBUTES", pkg.getAttributes());
        response = PackageManagementControllerUtils.createUploadIdV1(payload);

        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_CREATED,
                "createUploadId status code do not match expected code of 201");
        softAssert.assertNotNull(response.jsonPath().getString("uploadId"), "uploadId was not generated");
        uploadIds.add(response.jsonPath().getString("uploadId"));

        payload = CommonUtils.getResourceAsString("/package/uploadRequest.json")
                .replaceAll("\\$NAME", pkg.getName().toUpperCase()).replaceAll("\\$VERSION", pkg.getVersion())
                .replaceAll("\\$VENDOR", pkg.getVendor()).replaceAll("\\$DESCRIPTION", pkg.getDesc())
                .replaceAll("\\$TYPE", pkg.getType()).replaceAll("\\$NOTES", pkg.getNotes())
                .replaceAll("\\$HANDLER", pkg.getHandler()).replaceAll("\\$SIZE", pkg.getTotalBytes() + "")
                .replaceAll("\\$ATTRIBUTES", pkg.getAttributes());
        response = PackageManagementControllerUtils.createUploadIdV1(payload);

        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_CREATED,
                "createUploadId status code do not match expected code of 201");
        softAssert.assertNotNull(response.jsonPath().getString("uploadId"), "uploadId was not generated");
        uploadIds.add(response.jsonPath().getString("uploadId"));
    }

    /**
     * Data Provider for invalid upload requests
     *
     * @return Object[][];
     */
    @DataProvider
    public Object[][] getUploadIdTestInvalidDataProvider()
    {
        return new Object[][]
        {
                // {"scenario","packageName", "version", "vendor", "description", "type", "notes","handler","fileName", "size",
                // expectedStatusCode}
                {
                        "No Package Name", "", "1.1.1", "QE", "Package from QE", "configuration", "", "machine",
                        "configuration.zip", 10, 400
                },
                {
                        "Package Name 1 character", "b", "1.1.1", "QE", "Package from QE", "configuration", "",
                        "machine", "configuration.zip", 10, 400
                },
                {
                        "Package Name with space \"a b\"", "a b", "1.1.1", "", "", "configuration", "", "machine",
                        "configuration.zip", 10, 400
                },
                {
                        "Package Name with special character \"Test!)(*&^%@#\"",
                        StringEscapeUtils.escapeJava("Test!)(*&^%@#"), "1.1.1", "", "", "configuration", "", "machine",
                        "configuration.zip", 10, 400
                },
                {
                        "No Package Version", "TestPackage" + System.currentTimeMillis() / 1000, "", "", "",
                        "configuration", "", "machine", "configuration.zip", 10, 400
                },
                {
                        "Invalid Package Version", "TestPackage" + System.currentTimeMillis() / 1000, "10.a.b", "", "",
                        "CONFIGURATION", "", "machine", "configuration.zip", 10, 400
                },
                {
                        "Empty Package type", "TestPackage" + System.currentTimeMillis() / 1000, "1.1.1", "", "", "",
                        "", "machine", "configuration.zip", 10, 400
                },
                {
                        "Invalid Package type", "TestPackage" + System.currentTimeMillis() / 1000, "1.1.1", "", "",
                        "invalid", "", "machine", "configuration.zip", 10, 400
                },
                {
                        "File Size 0 bytes", "TestPackage" + System.currentTimeMillis() / 1000, "1.1.1", "", "",
                        "CONFIGURATION", "", "mac###hine", "configuration", 0, 400
                },
                {
                        "File Size -10 bytes", "TestPackage" + System.currentTimeMillis() / 1000, "1.1.1", "", "",
                        "CONFIGURATION", "", "mac###hine", "configuration", -10, 400
                },
                {
                        "Description with more than 1023 characters", "TestPackage" + System.currentTimeMillis() / 1000,
                        "1.1.1", "", str255 + str255 + str255 + str255 + "abcdefghijklmnop", "CONFIGURATION", "",
                        "mac###hine", "configuration", 10, 400
                },
                {
                        "No PackageName, Version, fileSize", "", "", "", str255.substring(0, 20), "CONFIGURATION",
                        str255.substring(0, 10) + "1", "mac###hine", "configuration", 0, 400
                },

        };
    }

    /*
     * Negative test scenarios
     * 1. Test getUploadId with invalid payload (invalid attribute values)
     * 2. Test UploadFile with different metadata than getUplaodId
     * 3. Test Cancel Upload on invalid uploadId
     */
    @Test(dataProvider = "getUploadIdTestInvalidDataProvider")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Test getUploadId with invalid payload (invalid attribute values)", description = "Test getUploadId with invalid payload (invalid attribute values) and validate the status code as 400(BAD REQUEST)", preCondition = "System should be stable and packages should be uploaded")
    public void testGetUploadIdWithInvalidData(String scenario, String packageName, String version, String vendor,
            String desc, String type, String notes, String handler, String fileName, long size, int expectedStatusCode)
    {

        _logger.info("\tRUNNING SCENARIO: " + scenario);
        PackagePojo pkg = new PackagePojo(packageName, version, vendor, desc, type, notes, handler, fileName, size,
                new HashMap<>());

        String payload = CommonUtils.getResourceAsString("/package/uploadRequest.json")
                .replaceAll("\\$NAME", pkg.getName()).replaceAll("\\$VERSION", pkg.getVersion())
                .replaceAll("\\$VENDOR", pkg.getVendor()).replaceAll("\\$DESCRIPTION", pkg.getDesc())
                .replaceAll("\\$TYPE", pkg.getType()).replaceAll("\\$NOTES", pkg.getNotes())
                .replaceAll("\\$HANDLER", pkg.getHandler()).replaceAll("\\$SIZE", pkg.getTotalBytes() + "")
                .replaceAll("\\$ATTRIBUTES", pkg.getAttributes());
        _logger.info("\tPayload:" + payload);
        Response response = PackageManagementControllerUtils.createUploadIdV1(payload);

        softAssert.assertEquals(response.statusCode(), expectedStatusCode,
                "createUploadId status code do not match expected code of " + expectedStatusCode);

    }

    /**
     * @throws InterruptedException --
     */
    // COMPLETE
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Test upload invalid packages and check the status of upload as failed", description = "Test upload invalid packages and check the status of upload and validate the statusof upload as failed", preCondition = "System should be stable and packages should be available to the user for deployment")
    public void testUploadInvalidPackageAndCheckStatus()
            throws InterruptedException
    {

        // 1. setup package meta data
        PackagePojo pkg = new PackagePojo("machine", "configuration", "fail.zip");
        packageList.add(pkg);
        String payload = CommonUtils.getResourceAsString("/package/uploadRequest.json")
                .replaceAll("\\$NAME", pkg.getName()).replaceAll("\\$VERSION", pkg.getVersion())
                .replaceAll("\\$VENDOR", pkg.getVendor()).replaceAll("\\$DESCRIPTION", pkg.getDesc())
                .replaceAll("\\$TYPE", pkg.getType()).replaceAll("\\$NOTES", pkg.getNotes())
                .replaceAll("\\$HANDLER", pkg.getHandler()).replaceAll("\\$SIZE", pkg.getTotalBytes() + "")
                .replaceAll("\\$ATTRIBUTES", pkg.getAttributes());

        // 1. GetUploadId
        Response response = PackageManagementControllerUtils.createUploadIdV1(payload);

        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_CREATED,
                "createUploadId status code do not match expected code of 201");

        JsonPath jsonPath = response.jsonPath();

        // set uploadid in the pkg pojo
        pkg.setUploadId(jsonPath.getString("uploadId"));

        // 2. Upload config pkg with invalid file format
        boolean isPkgUploaded = TestUtils.uploadPackage(pkg);
        softAssert.assertFalse(isPkgUploaded); // package upload is expected to fail

        // 3. Call getPackageUploadStatus with the uploadId
        response = PackageManagementControllerUtils.getPackageUploadStatusV1(pkg.getUploadId());
        jsonPath = response.jsonPath();
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK);
        softAssert.assertEquals(jsonPath.getString("status"), "failed",
                "Expected status do not match after failure with invalid package");

        // 4. Upload valid package
        pkg.setFileName("configuration.zip");

        isPkgUploaded = TestUtils.uploadPackage(pkg);
        if ( !isPkgUploaded )
        {
            response = PackageManagementControllerUtils.getPackageUploadStatusV1(pkg.getUploadId());
            _logger.info("\tFailed to upload package.");
        }
        softAssert.assertEquals(isPkgUploaded, true, "Failed to upload the package");

        // 5. Call getUploadStatus with the uploadId
        response = PackageManagementControllerUtils.getPackageUploadStatusV1(pkg.getUploadId());
        jsonPath = response.jsonPath();
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK);
        softAssert.assertEquals(jsonPath.getString("status"), "successful",
                "Expected status do not match after failure with invalid package");

    }

    /**
     * Test Case to test uploading of a HostOS
     * 1. Upload a valid new Host OS
     * 2. Verify uploaded Host OS is in the repo
     * 3. Upload an invalid/incomplete Host OS
     * 4. Upload an existing version of Host OS
     *
     * @throws InterruptedException --
     */
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Test upload valid host OS", description = "Test upload valid host OS and check the status of upload and validate the status of upload 200(CREATED)", preCondition = "System should be stable")
    public void testUploadValidNewHostOS()
            throws InterruptedException
    {

        // 1. Upload a valid new Host OS
        int fileSize = 2 * 5 * 1024 * 1024; // 2 * 5 Mebibytes: total size of both chunks
        String fileName = "5mibs"; // the minimum size of a chunk is 5Mibs

        // get uploadId

        PackagePojo pkg = new PackagePojo("", "operating-system", "uploadvalidnewhostos");
        pkg.setVendor("GE Digital");
        pkg.setTotalBytes(fileSize); // autoboxing from int to long

        packageList.add(pkg);
        String payload = CommonUtils.getResourceAsString("/package/uploadRequest.json")
                .replaceAll("\\$NAME", pkg.getName()).replaceAll("\\$VERSION", pkg.getVersion())
                .replaceAll("\\$VENDOR", pkg.getVendor()).replaceAll("\\$DESCRIPTION", pkg.getDesc())
                .replaceAll("\\$TYPE", pkg.getType()).replaceAll("\\$NOTES", pkg.getNotes())
                .replaceAll("\\$HANDLER", pkg.getHandler()).replaceAll("\\$SIZE", pkg.getTotalBytes() + "")
                .replaceAll("\\$ATTRIBUTES", pkg.getAttributes());

        // 2. Verify uploaded Host OS is in the repo
        Response response = PackageManagementControllerUtils.createUploadIdV1(payload);
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_CREATED,
                "createUploadId status code do not match expected code of 201");

        JsonPath jsonPath = response.jsonPath();

        // set uploadId in the pkg pojo
        pkg.setUploadId(jsonPath.getString("uploadId"));

        String status = jsonPath.getString("status");
        softAssert.assertTrue(CommonUtils.isLowerCase(status));
        softAssert.assertEquals(jsonPath.getLong("totalBytes"), pkg.getTotalBytes(),
                "createUploadId totalBytes assertion failed");

        softAssert.assertEquals(jsonPath.getString("name"), pkg.getName(), "createUploadId name assertion failed");
        softAssert.assertEquals(jsonPath.getString("version"), pkg.getVersion(),
                "createUploadId version assertion failed");
        softAssert.assertEquals(jsonPath.getString("vendor"), pkg.getVendor(),
                "createUploadId vendor assertion failed");
        softAssert.assertEquals(jsonPath.getString("description"), pkg.getDesc(),
                "createUploadId description assertion failed");
        softAssert.assertEquals(jsonPath.getString("type"), pkg.getType(), "createUploadId name type failed");
        softAssert.assertEquals(jsonPath.getString("notes"), pkg.getNotes(), "createUploadId name notes failed");
        softAssert.assertEquals(jsonPath.getString("handler"), pkg.getHandler(),
                "createUploadId handler assertion failed");
        softAssert.assertNotNull(jsonPath.getString("uploadId"), "createUploadId uploadId is null");
        softAssert.assertEquals(jsonPath.getString("status"), "pending-upload", "createUploadId status is null");
        softAssert.assertEquals(jsonPath.getString("uploadedBy"), cfg.getApiClientId(),
                "uploadedBy do not match clientId");

        softAssert.assertAll();

        checkUploadAndAssert(pkg, "pending-upload");

        // 3. Upload an invalid/incomplete Host OS
        uploadChunkAndAssert(fileName, pkg, 1, 204);

        checkUploadAndAssert(pkg, "uploading");

        uploadChunkAndAssert(fileName, pkg, 2, 204);

        // since the processing of the file in the server is asynchronous, it might happen that
        // we ask the file to be completed
        completeUploadAndAssert(pkg);

        TimeUnit.SECONDS.sleep(3);
        // Get Package Metadata
        response = PackageManagementControllerUtils.getPackageMetadataV1(pkg.getType(), pkg.getName(),
                pkg.getVersion());
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK);

        jsonPath = response.jsonPath();

        softAssert.assertTrue(jsonPath.getLong("uploaded") < System.currentTimeMillis(),
                "completing multipart upload: uploaded time is not before current time");

        softAssert.assertNotNull(jsonPath.getString("packageId"), "completing multipart upload: packageId is null");
        softAssert.assertTrue(jsonPath.getBoolean("active"), "completing multipart upload: active is false");

        softAssert.assertEquals(jsonPath.getString("name"), pkg.getName(),
                "completing multipart upload: name assertion failed");
        softAssert.assertEquals(jsonPath.getString("version"), pkg.getVersion(),
                "completing multipart upload: version assertion failed");
        softAssert.assertEquals(jsonPath.getString("vendor"), pkg.getVendor(),
                "completing multipart upload: vendor assertion failed");
        softAssert.assertEquals(jsonPath.getString("description"), pkg.getDesc(),
                "completing multipart upload: description assertion failed");
        softAssert.assertEquals(jsonPath.getString("type"), pkg.getType(),
                "completing multipart upload: name type failed");
        softAssert.assertEquals(jsonPath.getString("notes"), pkg.getNotes(),
                "completing multipart upload: name notes failed");

        softAssert.assertEquals(jsonPath.getString("handler"), "MACHINE",
                "completing multipart upload: handler assertion failed");
        softAssert.assertEquals(jsonPath.getString("uploadedBy"), cfg.getApiClientId(),
                "completing multipart upload: uploadedBy do not match clientId");

        softAssert.assertAll();

        // 4. Upload an existing version of Host OS
        uploadChunkAndAssert(fileName, pkg, 1, 409);

    }

    /**
     * Test Case of deploy Host OS Update
     * 1. Deploy a Host OS Update to a enrolled device
     *
     * @throws SignatureException --
     */
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Test deploy a Host OS Update to a enrolled device", description = "Test deploy a Host OS Update to a enrolled device and validate the status of upload 200(CREATED)", preCondition = "System should be stable")
    public void testDeployOSUpdate1()
            throws SignatureException
    {
        int fileSize = 33849;
        String fileName = "fail.zip";

        // get uploadId
        PackagePojo pkg = new PackagePojo("", "operating-system", "deployosupdate1");
        pkg.setVendor("GE Digital");
        pkg.setTotalBytes(fileSize); // autoboxing from int to long
        pkg.setAgentType(QEConstants.EDGE_AGENT);

        packageList.add(pkg);
        String payload = CommonUtils.getResourceAsString("/package/uploadRequestMultiContainer.json")
                .replaceAll("\\$NAME", pkg.getName()).replaceAll("\\$VERSION", pkg.getVersion())
                .replaceAll("\\$VENDOR", pkg.getVendor()).replaceAll("\\$DESCRIPTION", pkg.getDesc())
                .replaceAll("\\$TYPE", pkg.getType()).replaceAll("\\$NOTES", pkg.getNotes())
                .replaceAll("\\$AGENTTYPE", pkg.getAgentType()).replaceAll("\\$SIZE", pkg.getTotalBytes() + "")
                .replaceAll("\\$ATTRIBUTES", pkg.getAttributes());

        // verify uploaded Host OS is in the repo
        Response response = PackageManagementControllerUtils.createUploadIdV1(payload);
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_CREATED,
                "createUploadId status code do not match expected code of 201");

        JsonPath jsonPath = response.jsonPath();

        // set uploadId in the pkg pojo
        pkg.setUploadId(jsonPath.getString("uploadId"));

        checkUploadAndAssert(pkg, "pending-upload");

        // upload an invalid/incomplete Host OS
        uploadChunkAndAssert(fileName, pkg, 1, 204);

        checkUploadAndAssert(pkg, "uploading");

        // since the processing of the file in the server is asynchronous, it might happen that
        // we ask the file to be completed
        completeUploadAndAssert(pkg);

        // Deploy a Host OS Update to an enrolled device

        // add a device
        String deviceId = "qe-device-" + System.currentTimeMillis() / 1000;
        this.deviceList.add(deviceId);

        CertEnrolledDeviceInfo cedi = DeviceControllerUtils.addAndEnrollDevice(deviceId);

        // deploy OS to device
        payload = CommonUtils.getResourceAsString("/package/deployOperatingSystemPayload.json")
                .replaceAll("PACKAGE-NAME", pkg.getName()).replaceAll("VERSION", pkg.getVersion())
                .replaceAll("DEVICE-ID", deviceId).replaceAll("'", "\"");

        response = PackageDeploymentControllerUtils.deployPackagesToDevicesV1(payload);

        // b. Response returns a HttpStatus.SC_ACCEPTED. Get operationId from the location in the headers (Location /v1/operations/{operationId})
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_ACCEPTED);
        _logger.info(response.getHeader("Location"));
        softAssert.assertTrue(response.getHeader("Location")
                .contains(EmapiConstants.EM_API_V1_VERSION + EmapiConstants.PACKAGE_MANAGEMENT + "/operations/"));

        String operationId = response.getHeader("Location").split("/")[response.getHeader("Location").split("/").length
                - 1];

        Map<String, String> deviceIdTaskStatusMap = null;
        try
        {
            deviceIdTaskStatusMap = DeviceControllerUtils.getOperationDevicesDetails(operationId, "taskId");
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }

        String taskId = deviceIdTaskStatusMap.get(deviceId);

        // 1.c. Wait a few minutes and GET /emapi/beta/package-management/operations/{operationId}
        String deviceFilter = "name eq \"" + deviceId + "\"";

        EdgeGatewayRequest request = DeviceControllerUtils.buildUpdateTaskStatusSyncRequest(deviceId, deviceId, 1,
                taskId, TaskStatus.SUCCESS, TaskType.APPLICATION);

        String status;
        boolean statusIsSuccessOrFailed = false;

        // we'll try to get the status of the deployment to the device
        int numMinutes = 10;
        long future = TimeUnit.MINUTES.toMillis(numMinutes) + System.currentTimeMillis();
        do
        {

            EdgeGatewayUtils.sendGeGatewaySyncRequest(cedi, request);

            response = PackageDeploymentControllerUtils.getPackageOperationDetailsV1(operationId, deviceFilter);
            jsonPath = response.jsonPath();
            status = jsonPath.getString("status");

            // did device pick that up?
            if ( !status.equals("success") && !status.equals("failed") )
            {
                // no. sleep for a while
                try
                {
                    Thread.sleep(5000);
                }
                catch (InterruptedException e)
                {
                    e.printStackTrace();
                }

            }
            else
            {
                statusIsSuccessOrFailed = true;
            }
        }
        while (System.currentTimeMillis() < future && !statusIsSuccessOrFailed);

        // we check for success or failure, as they are the final states, but we are only
        // interested if the flow can continue. For that, we need a successful deploy of the package
        // to the device
        softAssert.assertTrue(statusIsSuccessOrFailed,
                "After " + numMinutes + " the package is still not being picked up by the device.");

    }

    /**
     * Test Case of deploy Host OS Update
     * 2. Deploy an invalid/incomplete Host OS Update to a enrolled device
     */
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Test deploy an invalid/incomplete Host OS Update to a enrolled device", description = "Test deploy an invalid/incomplete Host OS Update to a enrolled device", preCondition = "System should be stable")
    public void testDeployOSUpdate2()
    {

        int fileSize = 33849;
        String fileName = "fail.zip";

        PackagePojo pkg = new PackagePojo("", "operating-system", "deployosupdate2");
        pkg.setVendor("GE Digital");
        pkg.setTotalBytes(fileSize); // autoboxing from int to long

        packageList.add(pkg);
        String payload = CommonUtils.getResourceAsString("/package/uploadRequest.json")
                .replaceAll("\\$NAME", pkg.getName()).replaceAll("\\$VERSION", pkg.getVersion())
                .replaceAll("\\$VENDOR", pkg.getVendor()).replaceAll("\\$DESCRIPTION", pkg.getDesc())
                .replaceAll("\\$TYPE", pkg.getType()).replaceAll("\\$NOTES", pkg.getNotes())
                .replaceAll("\\$HANDLER", pkg.getHandler()).replaceAll("\\$SIZE", pkg.getTotalBytes() + "")
                .replaceAll("\\$ATTRIBUTES", pkg.getAttributes());

        // verify uploaded Host OS is in the repo
        Response response = PackageManagementControllerUtils.createUploadIdV1(payload);
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_CREATED,
                "createUploadId status code do not match expected code of 201");

        JsonPath jsonPath = response.jsonPath();

        // set uploadId in the pkg pojo
        pkg.setUploadId(jsonPath.getString("uploadId"));

        checkUploadAndAssert(pkg, "pending-upload");

        // Upload a part of a Host OS
        uploadChunkAndAssert(fileName, pkg, 1, 204);

        checkUploadAndAssert(pkg, "uploading");

        // add a device
        String deviceId = "qe-device-" + System.currentTimeMillis() / 1000;
        this.deviceList.add(deviceId);

        response = DeviceControllerUtils.createDeviceWithDeviceIdAndModeldIdV1(deviceId, "FieldAgent");
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_CREATED);

        // deploy OS to device
        payload = CommonUtils.getResourceAsString("/package/deployOperatingSystemPayload.json")
                .replaceAll("PACKAGE-NAME", pkg.getName()).replaceAll("VERSION", pkg.getVersion())
                .replaceAll("DEVICE-ID", deviceId).replaceAll("'", "\\\"");

        response = PackageDeploymentControllerUtils.deployPackagesToDevicesV1(payload);

        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_NOT_FOUND);
    }

    /**
     * Test Case of deploy Host OS Update
     * 3. Deploy a Host OS Update with empty filter
     */
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Test deploy a Host OS Update with empty filter", description = "Test Deploy a Host OS Update with empty filter and validate the status code as 400(BAD REQUEST)", preCondition = "System should be stable")
    public void testDeployOSUpdate3()
    {

        int fileSize = 33849;
        String fileName = "fail.zip";

        // get uploadId

        PackagePojo pkg = new PackagePojo("", "operating-system", "deployosupdate3");
        pkg.setVendor("GE Digital");
        pkg.setTotalBytes(fileSize); // autoboxing from int to long

        packageList.add(pkg);
        String payload = CommonUtils.getResourceAsString("/package/uploadRequest.json")
                .replaceAll("\\$NAME", pkg.getName()).replaceAll("\\$VERSION", pkg.getVersion())
                .replaceAll("\\$VENDOR", pkg.getVendor()).replaceAll("\\$DESCRIPTION", pkg.getDesc())
                .replaceAll("\\$TYPE", pkg.getType()).replaceAll("\\$NOTES", pkg.getNotes())
                .replaceAll("\\$HANDLER", pkg.getHandler()).replaceAll("\\$SIZE", pkg.getTotalBytes() + "")
                .replaceAll("\\$ATTRIBUTES", pkg.getAttributes());

        // verify uploaded Host OS is in the repo
        Response response = PackageManagementControllerUtils.createUploadIdV1(payload);
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_CREATED,
                "createUploadId status code do not match expected code of 201");

        JsonPath jsonPath = response.jsonPath();

        // set uploadId in the pkg pojo
        pkg.setUploadId(jsonPath.getString("uploadId"));

        checkUploadAndAssert(pkg, "pending-upload");

        // Upload a part of a Host OS
        uploadChunkAndAssert(fileName, pkg, 1, 204);

        checkUploadAndAssert(pkg, "uploading");

        // since the processing of the file in the server is asynchronous, it might happen that
        // we ask the file to be completed
        completeUploadAndAssert(pkg);

        // add a device
        String deviceId = "qe-device-" + System.currentTimeMillis() / 1000;
        this.deviceList.add(deviceId);

        response = DeviceControllerUtils.createDeviceWithDeviceIdAndModeldIdV1(deviceId, "FieldAgent");
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_CREATED);

        // deploy OS to device
        payload = CommonUtils.getResourceAsString("/package/deployOperatingSystemPayloadEmptyFilter.json")
                .replaceAll("PACKAGE-NAME", pkg.getName()).replaceAll("VERSION", pkg.getVersion())
                .replaceAll("DEVICE-ID", deviceId).replaceAll("'", "\\\"");

        response = PackageDeploymentControllerUtils.deployPackagesToDevicesV1(payload);

        // b. Response returns a 400:
        // Filter string cannot be empty. Supported filter format: <field> eq|co \"<value>\".
        // Example: id eq \"1111\" and name co \"abc\""}
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_BAD_REQUEST);
    }

    /**
     * Test Case of deploy Host OS Update
     * 5. Deploy a Host OS Update to an invalid device, response returns 404.
     */
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Test Deploy a Host OS Update to an invalid device, response returns 404", description = "Deploy a Host OS Update to an invalid device and validate the status code as 404(NOT FOUND)", preCondition = "System should be stable")
    public void testDeployOSUpdate5()
    {
        int fileSize = 33849;
        String fileName = "fail.zip";

        // get uploadId

        PackagePojo pkg = new PackagePojo("", "operating-system", "deployosupdate5");
        pkg.setVendor("GE Digital");
        pkg.setTotalBytes(fileSize); // autoboxing from int to long

        packageList.add(pkg);
        String payload = CommonUtils.getResourceAsString("/package/uploadRequest.json")
                .replaceAll("\\$NAME", pkg.getName()).replaceAll("\\$VERSION", pkg.getVersion())
                .replaceAll("\\$VENDOR", pkg.getVendor()).replaceAll("\\$DESCRIPTION", pkg.getDesc())
                .replaceAll("\\$TYPE", pkg.getType()).replaceAll("\\$NOTES", pkg.getNotes())
                .replaceAll("\\$HANDLER", pkg.getHandler()).replaceAll("\\$SIZE", pkg.getTotalBytes() + "")
                .replaceAll("\\$ATTRIBUTES", pkg.getAttributes());

        // verify uploaded Host OS is in the repo
        Response response = PackageManagementControllerUtils.createUploadIdV1(payload);
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_CREATED,
                "createUploadId status code do not match expected code of 201");

        JsonPath jsonPath = response.jsonPath();

        // set uploadId in the pkg pojo
        pkg.setUploadId(jsonPath.getString("uploadId"));

        checkUploadAndAssert(pkg, "pending-upload");

        // upload an invalid/incomplete Host OS
        uploadChunkAndAssert(fileName, pkg, 1, HttpStatus.SC_NO_CONTENT);

        checkUploadAndAssert(pkg, "uploading");

        // since the processing of the file in the server is asynchronous, it might happen that
        // we ask the file to be completed
        completeUploadAndAssert(pkg);

        // Deploy a Host OS Update to a enrolled device

        String deviceId = "non-existing-device-" + System.currentTimeMillis() / 1000;

        // deploy OS to device
        payload = CommonUtils.getResourceAsString("/package/deployOperatingSystemPayload.json");
        payload = payload.replaceAll("PACKAGE-NAME", pkg.getName()).replaceAll("VERSION", pkg.getVersion())
                .replaceAll("DEVICE-ID", deviceId);

        response = PackageDeploymentControllerUtils.deployPackagesToDevicesV1(payload);

        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_ACCEPTED);

        String operationId = response.getHeader("Location").split("/")[response.getHeader("Location").split("/").length
                - 1];

        Map<String, String> deviceIdTaskStatusMap = null;
        try
        {
            deviceIdTaskStatusMap = DeviceControllerUtils.getOperationDevicesDetails(operationId, "taskId");
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }

        // since the device doesn't exist, it should not be returned in the list of devices for that taskId
        softAssert.assertEquals(deviceIdTaskStatusMap.size(), 0);

    }

    private void completeUploadAndAssert(PackagePojo pkg)
    {
        Response response = PackageManagementControllerUtils.completePackageUploadV1(pkg.getUploadId());
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_NO_CONTENT,
                "Package completion failed with status code: " + response.statusCode());
    }

    private void checkUploadAndAssert(PackagePojo pkg, String status)
    {
        Response response = PackageManagementControllerUtils.getPackageUploadStatusV1(pkg.getUploadId());
        JsonPath jsonPath = response.jsonPath();
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK);
        softAssert.assertEquals(jsonPath.getString("status"), status);
    }

    /**
     * @param fileName file name
     * @param pkg package
     * @param chunkNumber chunkNumber
     * @param expectedStatusCode expected response status code
     */
    private void uploadChunkAndAssert(String fileName, PackagePojo pkg, int chunkNumber, int expectedStatusCode)
    {
        Response response = PackageManagementControllerUtils.putFileAsChunkV1(pkg.getUploadId(), fileName, chunkNumber);
        softAssert.assertEquals(response.statusCode(), expectedStatusCode,
                "Package uploading failed with status code: " + response.statusCode() + " for chunk " + chunkNumber);
    }

    /**
     * Run after the class for clean up.
     */
    @AfterClass(alwaysRun = true)
    public void cleanup()
    {
        _logger.info("CLEANUP: deleting uploadIds");
        for (String uploadId : uploadIds)
        {

            Response response = PackageManagementControllerUtils.cancelUploadV1(uploadId);
            if ( response.statusCode() == HttpStatus.SC_ACCEPTED )

            {
                _logger.info(String.format("\tCancelled upload %s", uploadId));
            }
            else
            {
                _logger.info(String.format("\tFailed to delete upload %s", uploadId));
            }
        }

        _logger.info("CLEANUP: deleting packages");
        for (PackagePojo pkg : packageList)
        {

            Response response = PackageManagementControllerUtils.deletePackageV1(pkg.getType(), pkg.getName(),
                    pkg.getVersion());
            if ( response.statusCode() == HttpStatus.SC_NO_CONTENT )

            {
                _logger.info(String.format("\tDeleted Name: %s Version:%s Type:%s", pkg.getName(), pkg.getVersion(),
                        pkg.getType()));
            }
            else
            {
                _logger.info(String.format("\tFailed to delete package. Name: %s Version:%s Type:%s", pkg.getName(),
                        pkg.getVersion(), pkg.getType()));
            }
        }

        _logger.info("CLEANUP: deleting devices");
        this.deviceList.forEach(deviceId -> {
            Response response = DeviceControllerUtils.deleteDeviceV1(deviceId);
            if ( response.statusCode() == HttpStatus.SC_NO_CONTENT )
            {
                _logger.info(String.format("\tDeleted device %s", deviceId));
            }
            else
            {
                _logger.info(String.format("\tFailed to delete device %s", deviceId));
            }
        });
    }

    /**
     * @param id Id
     * @param file file
     * @param statusSet set of status
     */
    private static void uploadPackageInNewThread(String id, String file, HashSet<String> statusSet)
    {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        try
        {

            executor.execute(() -> {
                Response res = PackageManagementControllerUtils.uploadPackageV1(id, file);
                softAssert.assertEquals(res.statusCode(), HttpStatus.SC_OK,
                        "Package upload failed with status code: " + res.statusCode());

                statusSet.add(res.jsonPath().getString("status"));
            });

        }
        finally
        {
            executor.shutdown();
        }
    }

    /**
     * @param id Id
     * @param file File
     */
    private static void uploadPackageInNewThread(String id, String file)
    {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        try
        {

            executor.execute(() -> {
                Response res = PackageManagementControllerUtils.uploadPackageV1(id, file);
                softAssert.assertEquals(res.statusCode(), HttpStatus.SC_OK,
                        "Package upload failed with status code: " + res.statusCode());

            });
        }
        finally
        {
            executor.shutdown();
        }
    }

}
