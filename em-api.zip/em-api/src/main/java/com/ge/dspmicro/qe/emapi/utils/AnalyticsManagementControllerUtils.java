/*
 * Copyright (c) 2019 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.emapi.utils;

import java.util.HashMap;
import java.util.Map;

import com.ge.dspmicro.qe.tools.environment.Configuration;
import com.ge.dspmicro.qe.tools.utils.RestClient;
import com.ge.dspmicro.qe.tools.utils.Token;
import com.jayway.restassured.response.Response;

/**
 *
 * @author 212756555
 */

@SuppressWarnings(value =
{
        "javadoc", "nls"
})
public class AnalyticsManagementControllerUtils
{
    private static Configuration cfg         = Configuration.getConfig();
    private static Token         token       = cfg.getAdminUAAToken();
    private static final String  BASE_URI_V1 = EmapiConstants.EM_API_BASE + EmapiConstants.DEVICE_MANAGEMENT
            + "/devices";

    /**
     * private constructors to prevent instantiation of this class
     */
    private AnalyticsManagementControllerUtils()
    {

    }

    /**
     * emapi/v1/device-management/devices/{deviceId}/analytics/app-info Get analytics app info by device id and app instance id and/or handler
     * 
     * @param deviceId deviceId
     * @param appInstanceId appInstanceId
     * @return Http response
     */
    public static Response getDeviceAnalyticsAppInfo(String deviceId, String appInstanceId)
    {
        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("appInstanceId", appInstanceId);
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_V1 + "/" + deviceId + "/analytics/app-info",
                queryParams, token);
    }

    /**
     * emapi/v1/device-management/devices/{deviceId}/analytics/status Get a list analytics component status by device id
     * 
     * @param deviceId deviceId
     * @return Http response
     */
    public static Response getDeviceAnalyticsStatus(String deviceId)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_V1 + "/" + deviceId + "/analytics/status", null, token);
    }
}
