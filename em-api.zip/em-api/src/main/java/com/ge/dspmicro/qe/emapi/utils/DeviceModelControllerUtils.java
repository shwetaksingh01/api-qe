/*
 * Copyright (c) 2012 - 2018 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.emapi.utils;

import com.ge.dspmicro.qe.tools.environment.Configuration;
import com.ge.dspmicro.qe.tools.utils.RestClient;
import com.ge.dspmicro.qe.tools.utils.Token;
import com.jayway.restassured.response.Response;

/**
 * 
 * @author 212547153
 */
@SuppressWarnings(value =
{
        "javadoc", "nls"
})
public class DeviceModelControllerUtils
{

    private static final String BASE_URI_BETA = EmapiConstants.EM_API_BETA_BASE + "/device-management/models";
    private static final String BASE_URI_V1   = EmapiConstants.EM_API_BASE + "/device-management/models";
    static Configuration        cfg           = Configuration.getConfig();
    private static Token        token         = cfg.getAdminUAAToken();

    // GET /emapi/v1/device-management/models Return list of device models
    public static Response getDeviceModelsV1()
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_V1, null, token);
    }

    // POST /emapi/v1/device-management/models Create a device model
    public static Response addDeviceModelV1(String payload)
    {
        return RestClient.post(cfg.getEdgeManagerUrl(), BASE_URI_V1, payload, token);
    }

    // GET /emapi/v1/device-management/models/device-counts Retrieve list of device counts associated with each device model
    public static Response getDeviceCountPerModelV1()
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_V1 + "/device-counts", null, token);
    }

    // DELETE /emapi/v1/device-management/models/{modelId} Delete a device model.
    public static Response deleteDeviceModelV1(String modelId)
    {
        return RestClient.delete(cfg.getEdgeManagerUrl(), BASE_URI_V1 + "/" + modelId, token);
    }

    // PUT /emapi/v1/device-management/models/{modelId} Create and Update device models
    public static Response updateOrAddDeviceModelsV1(String modelId, String payload)
    {
        return RestClient.put(cfg.getEdgeManagerUrl(), BASE_URI_V1 + "/" + modelId, payload, token);
    }

    // GET /emapi/v1/device-management/models/{modelId}/image Retrieve device model images or icon
    public static Response getDeviceModelImageV1(String modelId)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_V1 + "/" + modelId + "/image", null, token);
    }

    public void setToken(Token token)
    {
        DeviceModelControllerUtils.token = token;
    }

    public Token getToken()
    {
        return DeviceModelControllerUtils.token;
    }
}
