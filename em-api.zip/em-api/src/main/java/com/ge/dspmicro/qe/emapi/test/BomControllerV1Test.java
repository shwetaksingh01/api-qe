/*
 * Copyright (c) 2019 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.emapi.test;

import com.ge.dspmicro.qe.device.utils.DeviceManagementControllerUtils;
import com.ge.dspmicro.qe.emapi.pojo.PackagePojo;
import com.ge.dspmicro.qe.emapi.utils.*;
import com.ge.dspmicro.qe.tools.BaseTest;
import com.ge.dspmicro.qe.tools.testng.TestListener;
import com.ge.dspmicro.qe.tools.utils.CommonUtils;
import com.ge.predix.edgemanager.qe.annotations.JiraTestCaseInfo;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.HttpStatus;
import org.assertj.core.api.SoftAssertions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.*;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.TimeUnit;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

/**
 *
 * @author 212722003
 */
@SuppressWarnings(
{
        "javadoc", "nls", "unused"
})
@Listeners(TestListener.class)
public class BomControllerV1Test extends BaseTest
{
    private static final Logger       _logger               = LoggerFactory.getLogger(BomControllerV1Test.class);
    private static final String       PKG_1                 = "QE-BOM-API-Test-Package-001"
            + RandomStringUtils.randomAlphanumeric(10);
    private static final String       PKG_2                 = "QE-BOM-API-Test-Package-002"
            + RandomStringUtils.randomAlphanumeric(10);
    private static final String       PKG_3                 = "QE-BOM-API-Test-Package-003"
            + RandomStringUtils.randomAlphanumeric(10);
    private static final String       PKG_4                 = "QE-BOM-API-Test-Package-004"
            + RandomStringUtils.randomAlphanumeric(10);
    private static final String       CFG_PKG               = "QE-BOM-API-Test-Config-Package-001"
            + RandomStringUtils.randomAlphanumeric(10);
    private static String             bomName               = "";
    private static String             bomJson               = "";
    private static String             bomId                 = "";
    private static String             pkgVerison            = "";
    private static String             bomVersion            = "";
    private static String             deviceId;
    private static String             deviceIdWithModelIdV1;
    private static PackagePojo        bom                   = new PackagePojo("", "bom", "");
    private static PackagePojo        bom2                  = new PackagePojo("", "bom", "");
    private static final List<String> operationTypes        = new ArrayList<>(
            Arrays.asList("application", "configuration", "bom", "container", "analytics", "deviceConfiguration",
                    "analytics_template", "analytics_data_map", "virtual_machine", "operating_system"));
    private String                    deploymentOperationId = "";
    private static SoftAssertions     softly                = new SoftAssertions();

    @BeforeClass
    public void bomTestSetup()
            throws InterruptedException
    {
        deviceId = cfg.getQePMDeviceName();
        deviceIdWithModelIdV1 = "qe_" + System.currentTimeMillis() / 1000;
        long curTimeInSec = System.currentTimeMillis() / 1000;
        pkgVerison = "1.0." + curTimeInSec;
        uploadPackage(PKG_1, pkgVerison, "application", "BOM-Test-Pacakge-001", "GE Digital", "configuration.zip");
        uploadPackage(PKG_2, pkgVerison, "configuration", "BOM-Test-Pacakge-002", "GE Digital", "configuration.zip");
        uploadPackage(PKG_3, pkgVerison, "application", "BOM-Test-Pacakge-003", "GE Digital", "configuration.zip");
        uploadPackage(PKG_4, pkgVerison, "application", "BOM-Test-Pacakge-004", "GE Digital", "configuration.zip");
        uploadPackage(CFG_PKG, pkgVerison, "configuration", "BOM-Test-Config-Package-005", "GE Digital",
                "configuration.zip");
        softly.assertAll();
    }

    // CreateBOM Tests

    @Test(priority = 1)
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Post request to Upload two different BOM version with same name and then deploy BOM to a device", description = "Verify that user gets Bom Id after posting a request to Upload BOM and is successfully able to deploy BOM,also BOM deploment fails for Invalid BOM name used in POST request ", preCondition = "The application and configuration files should be available to the user")
    public void testUploadBOM()
            throws IOException
    {
        bomVersion = "1.0." + System.currentTimeMillis();
        _logger.info("RUNNING:  Create BOM");
        bomName = "QE-BOM-" + CommonUtils.getTimeStamp_HH_mm_ss_yyyy_MM_dd();
        String createBOMpayload = "{\"name\":\"" + bomName + "\",\"version\": \"" + bomVersion
                + "\",\"description\":\"Automation test suite\",\"packages\":[{\"name\":\"" + CFG_PKG
                + "\",\"version\":\"" + pkgVerison + "\",\"type\":\"configuration\"},{\"name\":\"" + PKG_1
                + "\",\"version\":\"" + pkgVerison + "\"}]}";

        bomJson = bomName + ".json";
        _logger.info("\tBOM Json: " + createBOMpayload);

        FileUtils.writeStringToFile(new File(bomJson), createBOMpayload);

        Response response = BomControllerUtils.createBomV1(bomJson);
        bomId = response.asString();

        // set bomname and version in the packagePojo for bom deployment
        bom.setName(bomName);
        bom.setVersion(bomVersion);
        bom.setDesc("Automation test suite");
        softly.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_CREATED);
        softly.assertThat(response.asString()).isNotNull();

        // upload second bom with same name but different version
        String bomJson2 = bomName + "_2.json";

        createBOMpayload = createBOMpayload.replace(bomVersion, "1.1.1");
        _logger.info("\tBOM Json2: " + createBOMpayload);

        FileUtils.writeStringToFile(new File(bomJson2), createBOMpayload);

        response = BomControllerUtils.createBomV1(bomJson2);
        bomId = response.asString();
        bom2.setName(bomName);
        bom2.setVersion("1.1.1");
        bom2.setDesc("Automation test suite");
        softly.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_CREATED);
        Assert.assertNotNull(response.asString());

        String payload = CommonUtils.getResourceAsString("/package/deployBOMPayload.json")
                .replaceAll("BOM-NAME", bom2.getName()).replaceAll("simple", "simple")
                .replaceAll("VERSION", bom2.getVersion()).replaceAll("BOOL", "true")
                .replaceAll("FILTER", "deviceId in \\\\\"" + deviceId + "\\\\\"");

        _logger.info("\tInstall BOM payload : " + payload);
        // deploy the bom in device
        response = BomControllerUtils.deployBOMV1(payload);

        softly.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_ACCEPTED);

        // BOM name does not exist - 404 validation
        payload = CommonUtils.getResourceAsString("/package/deployBOMPayload.json")
                .replaceAll("BOM-NAME", bom2.getName() + "_invalid").replaceAll("simple", "simple")
                .replaceAll("VERSION", bom2.getVersion()).replaceAll("BOOL", "true")
                .replaceAll("FILTER", "deviceId in \\\\\"" + deviceId + "\\\\\"");

        _logger.info("\tInstall BOM payload : " + payload);
        // deploy the bom in device
        response = BomControllerUtils.deployBOMV1(payload);

        softly.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_NOT_FOUND);

        // invalid body request - 400 validation
        payload = CommonUtils.getResourceAsString("/package/deployBOMPayload.json")
                .replaceAll("BOM-NAME", bom2.getName()).replaceAll("simple", "type")
                .replaceAll("VERSION", bom2.getVersion()).replaceAll("BOOL", "true")
                .replaceAll("FILTER", "deviceId in \\\\\"" + deviceId + "\\\\\"");

        _logger.info("\tInstall BOM payload : " + payload);
        // deploy the bom in device
        response = BomControllerUtils.deployBOMV1(payload);

        softly.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_BAD_REQUEST);

        softly.assertAll();
    }

    @Test(dependsOnMethods =
    {
            "testUploadBOM"
    })
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Post request to Upload BOM with same name and version fails", description = "Verify that user gets 409 Status Code if user tries to upload another BOM with same name and version", preCondition = "A BOM with same name and version should have been uploaded before.")
    public void testUploadSameBOMFailsWith409()
            throws IOException
    {
        Response response = BomControllerUtils.createBomV1(bomJson);

        softly.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_CONFLICT);
        assertTrue(response.asString().contains("Bom already exists."));
        FileUtils.forceDelete(new File(bomJson));
        softly.assertAll();
    }

    @DataProvider(name = "bomUploadTestDataProvider")
    public static Object[][] bomUploadTestDataProvider()
    {
        Object[][] params =
        {
                // scenario, payloadJson, bomName, bomVersion, bomDescription,
                // pkgName, pkgVersion, expectedStatusCode,
                // expectedResponseMessage
                {
                        "Upload BOM with no name", "", "1.1.0", "QE Regression BOM Test", PKG_1, pkgVerison,
                        HttpStatus.SC_BAD_REQUEST, "Invalid BOM name."
                },
                {
                        "Upload BOM with Invalid characters in name", "BOM &*((%^*&^%*&^%*^", "1.1",
                        "QE Regression BOM Test", PKG_1, pkgVerison, HttpStatus.SC_BAD_REQUEST, "Invalid BOM name."
                },
                // Defect {"Upload BOM with name length 1 characters","B",
                // "1.1", "QE Regression BOM Test", PKG_1,pkg_verison, 400,
                // "Invalid BOM name."},
                // Defect {"Upload BOM with name more than supported
                // length",str255Characters, "1.1", "QE Regression BOM Test",
                // PKG_1, pkg_verison, 400, "Invalid BOM name."},
                {
                        "Upload BOM with no version", "QE-Regression-Test-BOM", "", "QE Regression BOM Test", PKG_1,
                        pkgVerison, HttpStatus.SC_BAD_REQUEST, "Invalid BOM version"
                },
                {
                        "Upload BOM with invalid version format 1.$", "QE-Regression-Test-BOM", "1.$",
                        "QE Regression BOM Test", PKG_1, pkgVerison, HttpStatus.SC_BAD_REQUEST, "Invalid BOM version"
                },
                {
                        "Upload BOM with invalid version format $", "QE-Regression-Test-BOM", "$",
                        "QE Regression BOM Test", PKG_1, pkgVerison, HttpStatus.SC_BAD_REQUEST, "Invalid BOM version"
                },
                {
                        "Upload BOM with invalid version format 1.11.1.1.1.2.1.1.1.1.1", "QE-Regression-Test-BOM",
                        "1.11.1.1.1.2.1.1.1.1.1", "QE Regression BOM Test", PKG_1, pkgVerison,
                        HttpStatus.SC_BAD_REQUEST, "Invalid BOM version"
                },
                {
                        "Upload BOM with invalid json file", "QE-Regression-Test-BOM", "$", "QE Regression BOM Test",
                        PKG_1, pkgVerison, HttpStatus.SC_BAD_REQUEST, "Failed to parse BOM json file."
                },

        };
        return params;
    }

    @Test(dataProvider = "bomUploadTestDataProvider")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Post request to Upload BOM with invalid scenarios", description = "Verify that user gets 400 Status Code if user tries to upload BOM with invalid scenarios like  Upload BOM with no name\n"
            + "  Upload BOM with Invalid characters in name\n" + "  Upload BOM with no version\n"
            + "  pload BOM with invalid version format 1.$\n" + "  Upload BOM with invalid version format $\n"
            + "  Upload BOM with invalid version format 1.11.1.1.1.2.1.1.1.1.1\n"
            + "  Upload BOM with invalid json file\", \"QE-Regression-Test-BOM", preCondition = "The application and configuration files should be available to the user")
    public static void testUploadBOMScenarios(String scenario, String bomName1, String bomVersion1,
            String bomDescription, String pkgName, String pkgVersion, int expectedStatusCode, String errorMessage)
            throws IOException
    {
        _logger.info("\tRunning scenario: " + scenario);
        String bomJsonStr = "{\"name\":\"bomName\",\"version\": \"bomVersion\",\"description\":\"bomDescription\",\"packages\":[{\"name\":\"pkgName\",\"version\":\"pkgVersion\",\"vendor\":\"GE Digital\",\"provider\":\"pkgProvider\",\"description\":\"pkgDescription\"}]}";
        if ( scenario.equals("Upload BOM with invalid json file") )
        {
            bomJsonStr = "{\"name\":\"bomName\"n\": \"bomVersion\",\"description\":\"bomDescription\",\"packages\":[{\"name\":\"pkgName\",\"version\":\"pkgVersion\",\"vendor\":\"GE Digital\",\"provider\":\"pkgProvider\",\"description\":\"pkgDescription\"}]}";
        }
        else
        {
                bomJsonStr = bomJsonStr.replace("bomName", bomName1).replace("bomVersion", bomVersion1)
                        .replace("bomDescription", bomDescription).replace("pkgName", pkgName)
                        .replace("pkgVersion", pkgVersion);
        }
        String bomJsonFile = "testBom-" + System.currentTimeMillis() + ".json";
        FileUtils.writeStringToFile(new File(bomJsonFile), bomJsonStr);
        Response response = BomControllerUtils.createBomV1(bomJsonFile);

        softly.assertThat(response.getStatusCode()).isEqualTo(expectedStatusCode);
        assertTrue(response.asString().contains(errorMessage));
        FileUtils.forceDelete(new File(bomJsonFile));
        softly.assertAll();
    }

    // GetListOfBOMs Tests

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get list of BOMs", description = "Verify that user gets 200 Status Code and gets name,version,description and created values for the created BOMs", preCondition = "User should have uploaded the BOMs")
    public void testgetBOMs()
    {
        _logger.info("RUNNING:  Get list of BOMs");
        int limit = 5;
        Map<String, Object> params = new HashMap<>();
        params.put("limit", 5);
        params.put("offset", 0);
        Response response = BomControllerUtils.getBomsV1(params);

        softly.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_OK);
        softly.assertThat(response.asString()).isNotNull();

        JsonPath jsonPath = response.jsonPath();
        List<Object> bomList = jsonPath.getList("");

        _logger.info("\tNumber of bom in response: " + bomList.size());
        softly.assertThat(bomList.size()).isEqualTo(limit);

        for (int i = 0; i < bomList.size(); i++)
        {
            softAssert.assertNotNull(jsonPath.get("[" + i + "].name"));
            softAssert.assertNotNull(jsonPath.get("[" + i + "].version"));
            softAssert.assertNotNull(jsonPath.get("[" + i + "].description"));
            softAssert.assertNotNull(jsonPath.getLong("[" + i + "].created"));

        }

        softAssert.assertAll();

    }

    // GetBom Tests

    @DataProvider
    public static Object[][] getBomDataProvider()
    {
        Object[][] params =
        {
                {
                        "Valid Bom Name and Verison", bomName, bomVersion, HttpStatus.SC_OK, ""
                },
                {
                        "Invalid Bom Name and Version", "BomDonotExist", "1.2.2", HttpStatus.SC_NOT_FOUND,
                        "Invalid bom id sadf. The bomId has to be a positive number."
                },
        };
        return params;
    }

    @Test(dataProvider = "getBomDataProvider", dependsOnMethods =
    {
            "testUploadBOM"
    })
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get Bom details for different scenarios", description = "Verify that user gets different Statuses for different scenarios like valid Bom Name and Verison,Invalid Bom Name and Version", preCondition = "The application and configuration files should be available to the user")
    public void testGetBOM(String scenario, String testBomName, String testBomVersion, int statusCode,
            String expectedResponseMessage)
    {

        Response response = BomControllerUtils.getBomV1(testBomName, testBomVersion);

        softly.assertThat(response.statusCode()).isEqualTo(statusCode);
        if ( scenario.equals("Valid BomId") )
        {
            assertTrue(response.asString().contains(testBomName));
        }
        else
        {
            Assert.assertNotNull(response.asString().contains(expectedResponseMessage));
        }
        softly.assertAll();
    }

    @Test(dependsOnMethods = "testUploadBOM")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get Bom details grouped by name", description = "Verify that user gets Bom details grouped by name", preCondition = "Application should have BOMs uploaded")
    public void testGetBOMGroupedByName()
    {

        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("contains", bomName);
        Response response = BomControllerUtils.getBomGroupedByNameV1(queryParams);
        softly.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_OK);
        JsonPath jsonPath = response.jsonPath();

        List<Map<String, Object>> bomPackages = jsonPath.getList("$");
        Collections.sort(bomPackages, Collections.reverseOrder());

        softly.assertThat(bomPackages.get(0).get("name")).isEqualTo(bomName);
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> details = (List<Map<String, Object>>) bomPackages.get(0).get("details");

        softly.assertThat(details.get(0).get("version")).isEqualTo(bom2.getVersion());
        softly.assertThat(details.get(0).get("description")).isEqualTo(bom2.getDesc());
        softly.assertThat(details.get(0).get("created")).isNotNull();
        softly.assertThat(details.get(1).get("version")).isEqualTo(bom.getVersion());
        softly.assertThat(details.get(1).get("description")).isEqualTo(bom.getDesc());
        softly.assertThat(details.get(1).get("created")).isNotNull();
        softAssert.assertAll();

    }

    // GetRunningAndDesiredBom Tests
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get Running and desired BOM from Device in Created State", description = "Verify that User gets Running and desired BOM from Device in Created State", preCondition = "Application should have BOMs uploaded")
    public void testGetRunningAndDesiredBOMfromDeviceInCreatedState()
    {

        Response response = DeviceControllerUtils.createDeviceWithDeviceIdAndModeldIdV1(deviceIdWithModelIdV1,
                "FieldAgent");
        Assert.assertEquals(response.getStatusCode(), HttpStatus.SC_CREATED);
        _logger.info("\tDevice added successfully with device id " + deviceIdWithModelIdV1);

        response = BomControllerUtils.getDesiredAndRunningBomOfDeviceV1(deviceIdWithModelIdV1);

        softly.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_OK);

        // invalid device id for bom details
        response = BomControllerUtils.getDesiredAndRunningBomOfDeviceV1(deviceIdWithModelIdV1 + "invalid");
        softly.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_NOT_FOUND);

        // cleanup
        response = DeviceManagementControllerUtils.deleteDevice(deviceIdWithModelIdV1);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_NO_CONTENT);
        _logger.info("\tDeleted device successfully with device id " + deviceIdWithModelIdV1);
        softly.assertAll();
    }

    // Delete a BOM installation for a specified device
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Delete a BOM installation for a specified device", description = "Delete a BOM installation for a specified device", preCondition = "Application should have BOMs uploaded")
    public void testDeleteBOMInstallationForADevice()
            throws IOException
    {
        Response response = DeviceControllerUtils.createDeviceWithDeviceIdAndModeldIdV1(deviceIdWithModelIdV1,
                "FieldAgent");
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_CREATED);
        _logger.info("\tDevice added successfully with device id " + deviceIdWithModelIdV1);

        bomVersion = "1.0." + System.currentTimeMillis();
        _logger.info("RUNNING:  Create BOM");
        bomName = "QE-BOM-" + CommonUtils.getTimeStamp_HH_mm_ss_yyyy_MM_dd();
        String createBOMpayload = "{\"name\":\"" + bomName + "\",\"version\": \"" + bomVersion
                + "\",\"description\":\"Automation test suite\",\"packages\":[{\"name\":\"" + CFG_PKG
                + "\",\"version\":\"" + pkgVerison + "\",\"type\":\"configuration\"},{\"name\":\"" + PKG_1
                + "\",\"version\":\"" + pkgVerison + "\"}]}";

        bomJson = bomName + ".json";
        _logger.info("\tBOM Json: " + createBOMpayload);

        FileUtils.writeStringToFile(new File(bomJson), createBOMpayload);

        response = BomControllerUtils.createBomV1(bomJson);
        bomId = response.asString();

        // set bomname and version in the packagePojo for bom deployment
        bom.setName(bomName);
        bom.setVersion(bomVersion);
        bom.setDesc("Automation test suite");

        String payload = CommonUtils.getResourceAsString("/package/deployBOMPayload.json")
                .replaceAll("BOM-NAME", bom.getName()).replaceAll("simple", "simple")
                .replaceAll("VERSION", bom.getVersion()).replaceAll("BOOL", "true")
                .replaceAll("FILTER", "deviceId in \\\\\"" + deviceIdWithModelIdV1 + "\\\\\"");

        _logger.info("\tInstall BOM payload : " + payload);
        // deploy the bom in device
        response = BomControllerUtils.deployBOMV1(payload);

        response = BomControllerUtils.deleteBomOnDeviceV1(deviceIdWithModelIdV1);

        softly.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_NO_CONTENT);

        // invalid device id for bom details
        response = BomControllerUtils.deleteBomOnDeviceV1(deviceIdWithModelIdV1 + "invalid");
        softly.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_NOT_FOUND);

        // cleanup
        response = DeviceManagementControllerUtils.deleteDevice(deviceIdWithModelIdV1);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_NO_CONTENT);
        _logger.info("\tDeleted device successfully with device id " + deviceIdWithModelIdV1);
        softly.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get running and desired BOM with invalid id installation for an invalid device id", description = "Verify that status code 404 is received when user posts get request for running desired BOM with invalid id installation for an invalid device id", preCondition = "Application should have BOMs uploaded")
    public void testGetRunningAndDesiredBOMwithinvalidid()
    {

        Response response = BomControllerUtils.getDesiredAndRunningBomOfDeviceV1("device-device-device-device-device");

        softly.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_NOT_FOUND);
        assertTrue(response.asString().contains("Device not found for device ID: device-device-device-device-device"));
        softly.assertAll();

    }

    @Test(dependsOnMethods =
    {
            "testUploadBOM"
    })
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Deploy BOM for a valid device and assert that package id is not Null", description = "Verify BOM deployment for a valid device and assert that package id is not Null", preCondition = "Application should have BOMs uploaded")
    public void testDeployBOM()
    {
        // create payload
        String payload = CommonUtils.getResourceAsString("/package/deployPackageMinPayload.json")
                .replaceAll("PACKAGE-NAME", bom.getName()).replaceAll("TYPE", bom.getType())
                .replaceAll("VERSION", bom.getVersion())
                .replaceAll("FILTER", "deviceId eq \\\\\"" + deviceId + "\\\\\"");

        _logger.info("\tInstall BOM payload : " + payload);
        // schedule
        Response response = PackageDeploymentControllerUtils.deployPackagesToDevicesV1(payload);

        softly.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_ACCEPTED);
        _logger.info("\tLocation Header: " + response.getHeader("Location"));
        assertTrue(response.getHeader("Location")
                .contains(EmapiConstants.EM_API_V1_VERSION + EmapiConstants.PACKAGE_MANAGEMENT + "/operations/"));
        deploymentOperationId = response.getHeader("Location")
                .split("/")[response.getHeader("Location").split("/").length - 1];
        // get operation details for the bom deployment operation
        response = BomControllerUtils.getBomPackageOperationDetailsV1(deploymentOperationId,
                "deviceId eq \"" + deviceId + "\"");

        JsonPath jsonPath = response.jsonPath();

        long currentTime = System.currentTimeMillis();

        softAssert.assertTrue(jsonPath.getLong("scheduled") <= currentTime,
                "Scheduled time is after current time for getBomPackageOperationDetails.");
        softAssert.assertTrue(jsonPath.getLong("created") <= currentTime,
                "Created time is after current time for getBomPackageOperationDetails.");
        softAssert.assertEquals(jsonPath.get("name"), bom.getName() + "." + bom.getVersion());
        softAssert.assertEquals(jsonPath.get("type"), "bom", "Type do not match for getBomPackageOperationDetails.");
        softAssert.assertEquals(jsonPath.get("status"), "pending", "status do not match");
        String thisOperationId = jsonPath.get("operationId");
        softAssert.assertEquals(jsonPath.get("operationId"), deploymentOperationId,
                "operationId do not match for getBomPackageOperationDetails.");
        softAssert.assertEquals(jsonPath.get("scheduledBy"), cfg.getApiClientId(), "scheduledBy do not match ClientId");

        List<Map<String, Object>> details = jsonPath.getList("details");

        for (Map<String, Object> detail : details)
        {
            softly.assertThat(detail).isNotNull();
            softly.assertThat(detail.get("deviceId")).isNotNull();
            softAssert.assertTrue(!detail.get("deviceId").equals(""),
                    "Task Operation deviceId is empty for " + thisOperationId);
            softAssert.assertTrue(!detail.get("deviceName").equals(""),
                    "Task Operation deviceName is empty for " + thisOperationId);

            softly.assertThat(detail.get("packageId")).isNotNull();
            softly.assertThat(detail.get("priority")).isNotNull();

            List<Map<String, Object>> tasks = (List<Map<String, Object>>) detail.get("tasks");
            for (Map<String, Object> task : tasks)
            {
                softAssert.assertTrue(operationTypes.contains(task.get("type")), String.format(
                        "Operation type not found in expected list of operation types: %s. Actual operation type: %s",
                        operationTypes.toString(), task.get("type")));
                softly.assertThat(task.get("name")).isNotNull();
                softly.assertThat(task.get("status")).isNotNull();
                softly.assertThat(task.get("logAvailable")).isNotNull();
                softAssert.assertNotNull(task.get("scheduled"), "scheduled is null");
                softAssert.assertNotNull(task.get("created"), "created is null");
                softAssert.assertTrue(task.get("status").equals("pending"),
                        "Operation status does not match for " + thisOperationId);
                softAssert.assertEquals((String) task.get("scheduledBy"), cfg.getApiClientId(),
                        "scheduledBy do not match clientId");
            }

        }

        // get bom installation detail from the device
        response = BomControllerUtils.getBomInstallationDetailFromDeviceV1(deviceId);
        softly.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_OK);
        jsonPath = response.jsonPath();

        softAssert.assertTrue(jsonPath.getLong("scheduled") <= currentTime, "Scheduled time is after current time.");
        softAssert.assertTrue(jsonPath.getLong("created") <= currentTime, "Created time is after current time.");
        softAssert.assertEquals(jsonPath.get("scheduledBy"), cfg.getApiClientId(),
                "scheduledBy do not match with the ClientId");
        softAssert.assertEquals(jsonPath.get("operationId"), deploymentOperationId, "operationId do not match");
        softAssert.assertEquals(jsonPath.get("status"), "pending", "status do not match");
        softAssert.assertEquals(jsonPath.get("bom.name"), bom.getName(),
                "bom name do not match for getBomInstallationDetailFromDevice");
        softAssert.assertEquals(jsonPath.get("bom.version"), bom.getVersion(),
                "bom version do not match for getBomInstallationDetailFromDevice");
        softAssert.assertEquals(jsonPath.get("bom.description"), bom.getDesc(),
                "bom description do not match for getBomInstallationDetailFromDevice");

        softAssert.assertEquals(jsonPath.get("bom.packageStatus[0].status"), "pending",
                "first package task status do not match for getBomInstallationDetailFromDevice");
        softAssert.assertTrue(CommonUtils.isUuidValid(jsonPath.get("bom.packageStatus[0].taskId")),
                "taskId is not a valid uuid string for getBomInstallationDetailFromDevice");
        String taskId = jsonPath.getString("bom.packageStatus[0].taskId");
        softAssert.assertTrue(jsonPath.getLong("bom.packageStatus[0].scheduled") <= currentTime,
                "Scheduled time is after current time for getBomInstallationDetailFromDevice");
        softAssert.assertEquals(jsonPath.get("bom.packageStatus[1].status"), "pending",
                "second package task status do not match for getBomInstallationDetailFromDevice");

        softAssert.assertAll();
    }

    @Test(dependsOnMethods = "testUploadBOM")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Deploy BOM for a device that has been created with Model id and get operation details for the bom deployment operation", description = "Deploy BOM for a device that has been created with Model id and get operation details for the bom deployment operation", preCondition = "Application should have BOMs uploaded")
    public void testDeployBOMtoDeviceInCreatedState()
    {

        Response response = DeviceControllerUtils.createDeviceWithDeviceIdAndModeldIdV1(deviceIdWithModelIdV1,
                "FieldAgent");
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_CREATED);

        // deploy bom to device
        String payload = CommonUtils.getResourceAsString("/package/deployPackageMinPayload.json")
                .replaceAll("PACKAGE-NAME", bom.getName()).replaceAll("TYPE", bom.getType())
                .replaceAll("VERSION", bom.getVersion())
                .replaceAll("FILTER", "deviceId eq \\\\\"" + deviceIdWithModelIdV1 + "\\\\\"");

        _logger.info("\tInstall BOM payload : " + payload);

        response = PackageDeploymentControllerUtils.deployPackagesToDevicesV1(payload);
        softly.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_ACCEPTED);
        _logger.info("\tLocation Header: " + response.getHeader("Location"));
        assertTrue(response.getHeader("Location")
                .contains(EmapiConstants.EM_API_V1_VERSION + EmapiConstants.PACKAGE_MANAGEMENT + "/operations/"));
        // extract
        String operationId = response.getHeader("Location").split("/")[response.getHeader("Location").split("/").length
                - 1];

        // get operation details for the bom deployment operation
        response = BomControllerUtils.getBomPackageOperationDetailsV1(operationId, "");
        JsonPath jsonPath = response.jsonPath();

        long currentTime = System.currentTimeMillis();

        softAssert.assertTrue(jsonPath.getLong("scheduled") <= currentTime,
                "Scheduled time is after current time for getBomPackageOperationDetails.");
        softAssert.assertTrue(jsonPath.getLong("created") <= currentTime,
                "Created time is after current time for getBomPackageOperationDetails.");
        softAssert.assertEquals(jsonPath.get("name"), bom.getName() + "." + bom.getVersion());
        softAssert.assertEquals(jsonPath.get("type"), "bom", "Type do not match for getBomPackageOperationDetails.");
        softAssert.assertEquals(jsonPath.get("status"), "pending", "status do not match");
        softAssert.assertEquals(jsonPath.get("operationId"), operationId,
                "operationId do not match for getBomPackageOperationDetails.");
        softAssert.assertEquals(jsonPath.get("scheduledBy"), cfg.getApiClientId(), "scheduledBy do not match ClientId");

        List<Map<String, Object>> details = jsonPath.getList("details");

        for (Map<String, Object> detail : details)
        {

            softly.assertThat(detail).isNotNull();
            softly.assertThat(detail.get("deviceId")).isNotNull();
            softly.assertThat(detail.get("packageId")).isNotNull();
            softly.assertThat(detail.get("priority")).isNotNull();
            softAssert.assertTrue(!detail.get("deviceId").equals(""),
                    "Task Operation deviceId is empty for " + operationId);
            softAssert.assertTrue(!detail.get("deviceName").equals(""),
                    "Task Operation deviceName is empty for " + operationId);

            List<Map<String, Object>> tasks = (List<Map<String, Object>>) detail.get("tasks");
            for (Map<String, Object> task : tasks)
            {
                softAssert.assertTrue(operationTypes.contains(task.get("type")), String.format(
                        "Operation type not found in expected list of operation types: %s. Actual operation type: %s",
                        operationTypes.toString(), task.get("type")));
                softAssert.assertNotNull(task.get("name"), "name is null");
                softAssert.assertNotNull(task.get("scheduled"), "scheduled is null");
                softAssert.assertNotNull(task.get("created"), "created is null");
                softAssert.assertNotNull(task.get("status"), "Task status is null");
                softAssert.assertTrue(task.get("status").equals("pending"),
                        "Operation status does not match for " + operationId);
                softly.assertThat(task.get("logAvailable")).isNotNull();
                softAssert.assertEquals((String) task.get("scheduledBy"), cfg.getApiClientId(),
                        "scheduledBy do not match clientId");
            }
        }

        // get bom installation detail from the device
        response = BomControllerUtils.getBomInstallationDetailFromDeviceV1(deviceIdWithModelIdV1);
        softly.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_OK);
        response.prettyPrint();
        jsonPath = response.jsonPath();

        softAssert.assertTrue(jsonPath.getLong("scheduled") <= currentTime, "Scheduled time is after current time.");
        softAssert.assertTrue(jsonPath.getLong("created") <= currentTime, "Created time is after current time.");
        softAssert.assertEquals(jsonPath.get("scheduledBy"), cfg.getApiClientId(),
                "scheduledBy do not match with the ClientId");
        softAssert.assertEquals(jsonPath.get("operationId"), operationId, "operationId do not match");
        softAssert.assertEquals(jsonPath.get("status"), "pending", "status do not match");
        softAssert.assertEquals(jsonPath.get("bom.name"), bom.getName(),
                "bom name do not match for getBomInstallationDetailFromDevice");
        softAssert.assertEquals(jsonPath.get("bom.version"), bom.getVersion(),
                "bom version do not match for getBomInstallationDetailFromDevice");
        softAssert.assertEquals(jsonPath.get("bom.description"), bom.getDesc(),
                "bom description do not match for getBomInstallationDetailFromDevice");

        softAssert.assertEquals(jsonPath.get("bom.packageStatus[0].status"), "pending",
                "first package task status do not match for getBomInstallationDetailFromDevice");
        softAssert.assertTrue(CommonUtils.isUuidValid(jsonPath.get("bom.packageStatus[0].taskId")),
                "taskId is not a valid uuid string for getBomInstallationDetailFromDevice");
        jsonPath.getString("bom.packageStatus[0].taskId");
        softAssert.assertTrue(jsonPath.getLong("bom.packageStatus[0].scheduled") <= currentTime,
                "Scheduled time is after current time for getBomInstallationDetailFromDevice");
        softAssert.assertEquals(jsonPath.get("bom.packageStatus[1].status"), "pending",
                "second package task status do not match for getBomInstallationDetailFromDevice");

        // when device id not found
        response = BomControllerUtils.getBomInstallationDetailFromDeviceV1(deviceIdWithModelIdV1 + "Invalid");
        softly.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_NOT_FOUND);

        response = DeviceManagementControllerUtils.deleteDevice(deviceIdWithModelIdV1);
        softly.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_NO_CONTENT);
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Deploy BOM with invalid BOM deails for a device", description = "Deploy BOM for a device that has been created with Model id and get operation details for the bom deployment operation", preCondition = "Application should have BOMs uploaded")
    public void testDeployBOMwithInvalidBomDetails()
    {
        String payload = CommonUtils.getResourceAsString("/package/deployPackageMinPayload.json")
                .replaceAll("PACKAGE-NAME", bom.getName()).replaceAll("TYPE", bom.getType())
                .replaceAll("VERSION", "1.2.3").replaceAll("FILTER", "deviceId eq \\\\\"" + deviceId + "\\\\\"");

        _logger.info("\tInstall BOM payload : " + payload);
        Response response = PackageDeploymentControllerUtils.deployPackagesToDevicesV1(payload);
        softly.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_NOT_FOUND);
        softAssert.assertEquals(response.jsonPath().getString("message"), "Application with name " + bom.getName()
                + " and version 1.2.3 and type " + bom.getType() + " could not be found");
        softAssert.assertAll();
    }

    // DeleteBOM Tests
    @DataProvider
    public static Object[][] deleteBomDataProvider()
    {
        Object[][] params =
        {
                {
                        "Valid Bom Name and Version in use", bomName, bomVersion, HttpStatus.SC_CONFLICT, ""
                },
                {
                        "Invalid Bom", "DoNotExist", "1.1.1", HttpStatus.SC_NOT_FOUND,
                        "BOM not found with name DoNotExist and version 1.1.1."
                },
        };
        return params;
    }

    @Test(dataProvider = "deleteBomDataProvider", dependsOnMethods = "testGetBOM")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Delete BOM with Bom Name and Version in use and delete BOM with Invalid Bom details", description = "Verify the status code as 409 when user tried to delete BOM with BOM name and version in Use and gets status code 404 when tried to delete BOM with invalid BOM details", preCondition = "Application should have BOMs uploaded")
    public void testdeleteBOM(String scenario, String testBomName, String testBomVersion, int httpCode,
            String responseMessage)
    {
        _logger.info("\tRunning Scenario: " + scenario);

        Response response = BomControllerUtils.deleteBomV1(testBomName, testBomVersion);

        softly.assertThat(response.statusCode()).isEqualTo(httpCode);
        assertTrue(response.asString().contains(responseMessage));
        softly.assertAll();
    }

    // get BOM bt bom id Tests
    @DataProvider
    public static Object[][] getBomByIdDataProvider()
    {
        Object[][] params =
        {
                {
                        "Valid Bom Name and Version in use, get the bom by bomid", bomName, bomVersion,
                        HttpStatus.SC_OK, ""
                },

        };
        return params;
    }

    @Test(dataProvider = "getBomByIdDataProvider", dependsOnMethods = "testGetBOM")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get the bom by bomid using valid Bom Name and Version", description = "Verify the status code as 200 for the response of get request for valid Bom Name and Version", preCondition = "Application should have BOMs uploaded")
    public void testGetBOMById(String scenario, String testBomName, String testBomVersion, int httpCode,
            String responseMessage)
    {

        String filter = "name eq \"bomName\"";
        filter = filter.replace("bomName", testBomName);
        Response response = BomControllerUtils.getFilteredBOMsV1(1, 0, filter);
        Map<String, Object> jsonPath = (Map<String, Object>) response.jsonPath().getList("$").get(0);

        bomId = String.valueOf(jsonPath.get("bomId"));
        _logger.info("\tRunning Scenario: " + scenario);

        response = BomControllerUtils.getBomByBomIdV1(bomId);

        softly.assertThat(response.statusCode()).isEqualTo(httpCode);
        softly.assertAll();
    }

    private static void uploadPackage(String name, String version, String type, String description, String vendor,
            String pathToFile)
            throws InterruptedException
    {
        PackagePojo pkg = new PackagePojo("machine", type, pathToFile);
        pkg.setName(name);
        pkg.setVersion(version);
        pkg.setDesc(description);
        pkg.setVendor(vendor);

        String payload = CommonUtils.getResourceAsString("/package/uploadRequest.json")
                .replaceAll("\\$NAME", pkg.getName()).replaceAll("\\$VERSION", pkg.getVersion())
                .replaceAll("\\$VENDOR", pkg.getVendor()).replaceAll("\\$DESCRIPTION", pkg.getDesc())
                .replaceAll("\\$TYPE", pkg.getType()).replaceAll("\\$NOTES", pkg.getNotes())
                .replaceAll("\\$HANDLER", pkg.getHandler()).replaceAll("\\$SIZE", pkg.getTotalBytes() + "")
                .replaceAll("\\$ATTRIBUTES", pkg.getAttributes());

        Response response = PackageManagementControllerUtils.createUploadIdV1(payload);

        softly.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_CREATED);

        JsonPath jsonPath = response.jsonPath();

        // set uploadid in the pkg pojo
        pkg.setUploadId(jsonPath.getString("uploadId"));

        response = PackageManagementControllerUtils.uploadPackageV1(pkg.getUploadId(), pkg.getFileName());

        softly.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_OK);

        TimeUnit.SECONDS.sleep(3);
        int count = 0;
        while (count < 5)
        {
            _logger.info("upload in progress....."+pkg.getUploadId());
            response = PackageManagementControllerUtils.getPackageUploadStatusV1(pkg.getUploadId());
            assertEquals(response.statusCode(), 200, "Package get differs with status code: " + response.statusCode());
            if ( "successful".equals(response.jsonPath().get("status")) )
            {
                break;
            }
            TimeUnit.SECONDS.sleep(3);
            count++;
        }
        assertEquals(response.jsonPath().get("status"), "successful");

    }

    @AfterClass(alwaysRun = true)
    public void cleanup()
    {
        _logger.info("Performing cleanup for BOM Deployment");
        Response response = BomControllerUtils.getBomInstallationDetailFromDeviceV1(deviceId);
        softly.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_OK);

        if ( response.jsonPath().get("status").equals("pending") )
        {
            String cancelPayload = "{\"deploymentActions\":[{\"action\":\"CANCEL\",\"params\":{}}]}";
            _logger.info("Cancelling BOM Deployment Operation: " + deploymentOperationId);

            response = PackageDeploymentControllerUtils.cancelDeploymentV1(deploymentOperationId, cancelPayload);
            softly.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_ACCEPTED);
            softAssert.assertAll();
            System.setProperty("api.version.number", "");
        }
    }

    // GetBOMInstallationDetails
    @Test(dependsOnMethods =
    {
            "testDeployBOM"
    })
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get BOM installation details from the device", description = "Verify the status code as 200 for the response of get request of BOM installation details.Also verify that the values like Status,Operation ID,Created,Scheduled,Scheduled By,name,versiondescription is also retrived", preCondition = "Application should have BOMs uploaded")
    public void testGetBOMInstallDetails()
    {
        Response response = BomControllerUtils.getBomInstallationDetailFromDeviceV1(deviceId);

        softly.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_OK);

        JsonPath jsonPath = response.jsonPath();
        softAssert.assertNotNull(jsonPath.get("status"), "status");
        softAssert.assertNotNull(jsonPath.get("operationId"), "operationId");
        softAssert.assertNotNull(jsonPath.getLong("created"), "created");
        softAssert.assertNotNull(jsonPath.getLong("scheduled"), "scheduled");
        softAssert.assertEquals(jsonPath.get("scheduledBy"), cfg.getApiClientId(),
                "scheduledBy do not match with the ClientId");

        softAssert.assertNotNull(jsonPath.get("bom.name"), "bom.name");
        softAssert.assertNotNull(jsonPath.get("bom.version"), "bom.version");
        softAssert.assertNotNull(jsonPath.get("bom.description"), "bom.description");

        softAssert.assertNotNull(jsonPath.get("bom.packageStatus[0].scheduled"), "bom.packageStatus[0].scheduled");
        softAssert.assertNotNull(jsonPath.get("bom.packageStatus[0].status"), "bom.packageStatus[0].status");
        softAssert.assertNotNull(jsonPath.get("bom.packageStatus[0].taskId"), "bom.packageStatus[0].taskId");

        if ( jsonPath.get("status").equals("success") )
        {
            softAssert.assertNotNull(jsonPath.getLong("started"), "started");
            softAssert.assertNotNull(jsonPath.getLong("ended"), "ended");

        }
        softAssert.assertAll();
    }

    // DE51079
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get BOM installation details from New Created Device", description = "Verify the status code as 200 for the response of get request for BOM installation details from newly created device", preCondition = "Application should have BOMs uploaded")
    public void testGetBOMInstallDetailsFromNewCreatedStatedDevice()
    {
        String testDevice = "qe-device-bom-test-" + System.currentTimeMillis() / 1000;
        Response response = DeviceManagementControllerUtils.addDeviceV2UsingDeviceId(testDevice);
        softly.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_CREATED);
        response = BomControllerUtils.getBomInstallationDetailFromDeviceV1(testDevice);

        DeviceManagementControllerUtils.deleteDevice(testDevice);
        softly.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_OK);
        // V3 endpoints getBomInstallation() and getBomInstallationDetails() requests for created devices, returns 200 with a empty body
        // softAssert.assertTrue(response.asString().contains(testDevice));
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Upload BOM and delete BOM test", description = "Post a request to ipload BOM and then delete BOM", preCondition = "User should have the payload to post the request of BOM upload")
    public void testUploadAndDeleteBOM()
            throws IOException
    {
        String version = "1.0." + System.currentTimeMillis();
        String name = "QE-BOM-" + CommonUtils.getTimeStamp_HH_mm_ss_yyyy_MM_dd();
        String createBOMpayload = "{\"name\":\"" + name + "\",\"version\": \"" + version
                + "\",\"description\":\"Automation test suite\",\"packages\":[{\"name\":\"" + CFG_PKG
                + "\",\"version\":\"" + pkgVerison + "\",\"type\":\"configuration\"},{\"name\":\"" + PKG_1
                + "\",\"version\":\"" + pkgVerison + "\"}]}";
        bomJson = bomName + ".json";
        _logger.info("\tBOM Json: " + createBOMpayload);

        FileUtils.writeStringToFile(new File(bomJson), createBOMpayload);

        Response response = BomControllerUtils.createBomV1(bomJson);
        softly.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_CREATED);
        response = BomControllerUtils.deleteBomV1(name, version);

        softly.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_NO_CONTENT);
        assertTrue(response.asString().contains(""));
        FileUtils.forceDelete(new File(bomJson));
        softly.assertAll();
    }
}
