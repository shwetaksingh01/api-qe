/*
 * Copyright (c) 2012 - 2018 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.emapi.utils;

import com.ge.dspmicro.qe.tools.environment.Configuration;
import com.ge.dspmicro.qe.tools.utils.RestClient;
import com.ge.dspmicro.qe.tools.utils.Token;
import com.jayway.restassured.response.Response;

/**
 * 
 * @author 212547153
 */

@SuppressWarnings(value =
{
        "javadoc", "nls"
})

public class DeviceOperationControllerUtils
{

    private static final String BASE_URI = EmapiConstants.EM_API_BETA_BASE + "/device-management/operations/";
    static Configuration        cfg      = Configuration.getConfig();
    private static Token        token    = cfg.getAdminUAAToken();

    // GET /emapi/v1/device-management/operations/{operationId} Retrieve status of the specified operation
    public static Response getDeviceManagementOperationStatus(String operationId)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI + operationId, null, token);
    }

    public void setToken(Token token)
    {
        DeviceOperationControllerUtils.token = token;
    }

    public Token getToken()
    {
        return DeviceOperationControllerUtils.token;
    }
}
