/*
 * Copyright (c) 2019 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.emapi.test;

import com.ge.dspmicro.qe.emapi.utils.AnalyticsManagementControllerUtils;
import com.ge.dspmicro.qe.emapi.utils.TestUtils;
import com.ge.dspmicro.qe.tools.BaseTest;
import com.ge.dspmicro.qe.tools.testng.TestListener;
import com.ge.predix.edgemanager.qe.annotations.JiraTestCaseInfo;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.SkipException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;

/**
 * @author 212756555
 */

@SuppressWarnings(value =
{
        "javadoc", "nls"
})
@Listeners(TestListener.class)
public class    AnalyticsManagementControllerV1Test extends BaseTest
{
    private static final Logger _logger                 = LoggerFactory
            .getLogger(AnalyticsManagementControllerV1Test.class);
    private String              deviceId                = "";
    private boolean             isSupported             = true;
    private static final String DEVICE_NAME             = "deviceId";
    private static final String RESPONSE_CODE_MISMATCH  = "Response code is not as expected";
    private static final String MESSAGE                 = "message";
    private static final String MESSAGE_NOT_AS_EXPECTED = "Message is not matching the expected";

    @BeforeClass
    public void setup()
    {
        this.deviceId = cfg.getQeEADeviceName();
        this.isSupported = TestUtils.envSupportCheck(cfg);
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get Analytics application information for an invalid device", description = "Verify that user gets message No device Found with this Id when user tries to get Analytics application information for an Invalid device ", preCondition = "Get Request should use an Invalid device ID")
    public void getDeviceAnalyticsAppInfoDummyDeviceTest()
    {
        String dummyDeviceId = DEVICE_NAME + System.currentTimeMillis();
        String invalidDeviceIdMessage = String.format("No device found with deviceId %s.", dummyDeviceId);
        Response response = AnalyticsManagementControllerUtils.getDeviceAnalyticsAppInfo(dummyDeviceId,
                "dummyInstanceId");
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_NOT_FOUND, "No device Found with this Id");
        softAssert.assertEquals(response.jsonPath().getString(MESSAGE), invalidDeviceIdMessage,
                MESSAGE_NOT_AS_EXPECTED);
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get Analytics application information for a device without passign the Query parameters", description = "Verify that user gets message Expected at least application instance Id or handler to be defined but both were null when user tries to get Analytics application information for a device without passing the Query Parameters ", preCondition = "Get Request should be send without passing any query parameters")
    public void getDeviceAnalyticsAppInfoNoQueryParamsTest()
    {
        Response response = AnalyticsManagementControllerUtils
                .getDeviceAnalyticsAppInfo(DEVICE_NAME + System.currentTimeMillis(), null);
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_BAD_REQUEST, RESPONSE_CODE_MISMATCH);
        softAssert.assertEquals(response.jsonPath().getString(MESSAGE),
                "Expected at least application instance Id or handler to be defined but both were null.",
                MESSAGE_NOT_AS_EXPECTED);
        softAssert.assertAll();
    }

    // disabled until downloads are faster and package is uploaded to CF3 INC0089133
    @Test(enabled = false)
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get Analytics application information for a valid device and application Id", description = "Get Analytics application information for a valid device and application Id", preCondition = "Get Request should be made with valid device and application Id")
    public void getDeviceAnalyticsAppInfoTest()
    {
        if ( !this.isSupported )
        {
            throw new SkipException("Skipping as test is supported only for int, sysint, stage environments.");
        }
        Response response = AnalyticsManagementControllerUtils.getDeviceAnalyticsAppInfo(this.deviceId,
                "CSenseRuntime");
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK, RESPONSE_CODE_MISMATCH);
        _logger.info("\tAssert on count of system commands");
        softAssert.assertTrue(response.asString().contains("attributes"), "Resoponse must contain attributes");
        softAssert.assertTrue(response.asString().contains("lastUpdated"), "Resoponse must contain lastUpdated");
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get Analytics status information for an invalid device", description = "Verify that user gets message No device Found with this Id when user tries to get Analytics status information for an Invalid device ", preCondition = "Get Request should use an Invalid device ID")
    public void getAnalyticsStatusForDummyDeviceTest()
    {
        String dummyDeviceId = DEVICE_NAME + System.currentTimeMillis();
        String invalidDeviceIdMessage = String.format("No device found with deviceId %s.", dummyDeviceId);
        Response response = AnalyticsManagementControllerUtils.getDeviceAnalyticsStatus(dummyDeviceId);
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_NOT_FOUND, RESPONSE_CODE_MISMATCH);
        softAssert.assertEquals(response.jsonPath().getString(MESSAGE), invalidDeviceIdMessage,
                MESSAGE_NOT_AS_EXPECTED);
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get Analytics status information for a valid device", description = "Verify that user gets Package ID in the response to get status informationmation for a valid device ", preCondition = "Get Request should use an valid device Id")
    public void getAnalyticsStatusForDeviceTest()
    {
        if ( !this.isSupported )
        {
            throw new SkipException("Skipping as test is supported only for int, sysint, stage environments.");
        }
        Response response = AnalyticsManagementControllerUtils.getDeviceAnalyticsStatus(this.deviceId);
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK, RESPONSE_CODE_MISMATCH);
        JsonPath jsonPath = response.jsonPath();
        List<Map<String, Object>> apps = jsonPath.getList("$");
        softAssert.assertTrue(!apps.isEmpty(), "Atleast one analytics app must be running");
        softAssert.assertNotNull(apps.get(0).get("packageId"), "packageId must be present in response");
        softAssert.assertAll();
    }

}
