/*
 * Copyright (c) 2019 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.emapi.test;

import java.time.Instant;
import java.time.Period;
import java.util.HashMap;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ge.dspmicro.qe.emapi.utils.DeviceStatisticsUtils;
import com.ge.dspmicro.qe.tools.BaseTest;
import com.ge.dspmicro.qe.tools.environment.Configuration;
import com.ge.dspmicro.qe.tools.testng.TestListener;
import com.ge.predix.edgemanager.qe.annotations.JiraTestCaseInfo;
import com.jayway.restassured.response.Response;

/**
 *
 * @author 212758475
 */
@SuppressWarnings(
{
        "javadoc", "nls"
})
@Listeners(TestListener.class)
public class DeviceStatisticsManagementControllerV1Test extends BaseTest
{

    private static final Logger _logger = LoggerFactory.getLogger(DeviceStatisticsManagementControllerV1Test.class);
    private static String       deviceId;
    private Map<String, Object> queryParams;

    @Override
    @BeforeClass
    public void init()
    {
        deviceId = Configuration.getConfig().getQePMDeviceName();
        _logger.info("Device ID = {} ", deviceId);
    }

    @BeforeMethod
    public void beforeMethod()
    {
        this.queryParams = new HashMap<>();
    }

    // Test cases for GET /emapi/v1/device-management/devices/{deviceId}/resources
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get device resource usage data for valid device", description = "Get device resource usage data for valid device and validate the status code as 200(OK)", preCondition = "Device should be added in the system")
    public void testGetDeviceResourceUsageDataForValidDevice()
    {
        Response response = DeviceStatisticsUtils.getResourcesV1(deviceId, this.queryParams);
        softAssert.assertNotNull(response);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get device resource usage data for valid device with valid type", description = "Get device resource usage data for valid device with valid type and validate the status code as 200(OK)", preCondition = "Device should be added in the system")
    public void testGetDeviceResourceUsageDataForValidDeviceWithValidType()
    {
        String validType = "cpu";
        this.queryParams.put("type", validType);
        Response response = DeviceStatisticsUtils.getResourcesV1(deviceId, this.queryParams);
        softAssert.assertNotNull(response);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get device resource usage data for valid device with Invalid type", description = "Get device resource usage data for valid device with Invalid type and validate the status code as 400(BAD REQUEST)", preCondition = "Device should be added in the system")
    public void testGetDeviceResourceUsageDataForValidDeviceInvalidType()
    {
        String invalidType = "cpu_invalid";
        this.queryParams.put("type", invalidType);
        Response response = DeviceStatisticsUtils.getResourcesV1(deviceId, this.queryParams);
        softAssert.assertNotNull(response);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_BAD_REQUEST);
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get device resource usage data for valid device with Invalid type", description = "Get device resource usage data for valid device with Invalid Start Time and validate the status code as 400(BAD REQUEST)", preCondition = "Device should be added in the system")
    public void testGetDeviceResourceUsageDataForValidDeviceInvalidStartTime()
    {
        long startTime = Instant.now().plus(Period.ofDays(7)).toEpochMilli();
        this.queryParams.put("startTime", startTime);
        Response response = DeviceStatisticsUtils.getResourcesV1(deviceId, this.queryParams);
        softAssert.assertNotNull(response);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_BAD_REQUEST);
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get device resource usage data for Invalid device", description = "Get device resource usage data for Invalid device and validate the status code as 404(NOT FOUND)", preCondition = "Device should be added in the system")
    public void testGetDeviceResourceUsageDataForInvalidDevice()
    {
        String invalidDeviceId = deviceId + "_invalid";
        Response response = DeviceStatisticsUtils.getResourcesV1(invalidDeviceId, this.queryParams);
        softAssert.assertNotNull(response);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_NOT_FOUND);
        softAssert.assertAll();

    }

    // Test cases for GET /emapi/v1/device-management/devices/{deviceId}/events
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get device events for valid device", description = "Get device events for valid device and validate the status code as 200(OK)", preCondition = "Device should be added in the system")
    public void testGetDeviceEventsForValidDevice()
    {
        Response response = DeviceStatisticsUtils.getEventsV1(deviceId, this.queryParams);
        softAssert.assertNotNull(response);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
        Map<String, Object> events = response.jsonPath().getMap("$");
        softAssert.assertNotNull(events.get("initialStates"));
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get device events for valid device with valid type", description = "Get device events for valid device with valid type and validate the status code as 200(OK)", preCondition = "Device should be added in the system")
    public void testGetDeviceEventsForValidDeviceWithValidType()
    {
        String validType = "device-status";
        this.queryParams.put("type", validType);
        Response response = DeviceStatisticsUtils.getEventsV1(deviceId, this.queryParams);
        softAssert.assertNotNull(response);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
        Map<String, Object> events = response.jsonPath().getMap("$");
        softAssert.assertNotNull(events.get("initialStates"));
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get device events for valid device with Invalid type", description = "Get device events for valid device with Invalid type and validate the status code as 400(BAD REQUEST)", preCondition = "Device should be added in the system")
    public void testGetDeviceEventsForValidDeviceInvalidType()
    {
        String invalidType = "device-status_invalid";
        this.queryParams.put("type", invalidType);
        Response response = DeviceStatisticsUtils.getEventsV1(deviceId, this.queryParams);
        softAssert.assertNotNull(response);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_BAD_REQUEST);
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get device events for valid device with Invalid Stat time", description = "Get device events for valid device with Invalid Start time and validate the status code as 400(BAD REQUEST)", preCondition = "Device should be added in the system")
    public void testGetDeviceEventsForValidDeviceInvalidStartTime()
    {
        long startTime = Instant.now().plus(Period.ofDays(7)).toEpochMilli();
        this.queryParams.put("startTime", startTime);
        Response response = DeviceStatisticsUtils.getEventsV1(deviceId, this.queryParams);
        softAssert.assertNotNull(response);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_BAD_REQUEST);
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get device events for Invalid device", description = "Get device events for Invalid device and validate the status code as 404(NOT FOUND)", preCondition = "Device should be added in the system")
    public void testGetDeviceEventsForInvalidDevice()
    {
        String invalidDeviceId = deviceId + "_invalid";
        Response response = DeviceStatisticsUtils.getEventsV1(invalidDeviceId, this.queryParams);
        softAssert.assertNotNull(response);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_NOT_FOUND);
        softAssert.assertAll();
    }

}
