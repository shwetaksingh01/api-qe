/*
 * Copyright (c) 2012 - 2018 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.emapi.utils;

import java.util.HashMap;
import java.util.Map;

import com.ge.dspmicro.qe.tools.environment.Configuration;
import com.ge.dspmicro.qe.tools.utils.RestClient;
import com.ge.dspmicro.qe.tools.utils.Token;
import com.jayway.restassured.response.Response;

/**
 *
 * @author 212547153
 */
@SuppressWarnings(value =
{
        "javadoc", "nls"
})
public class PackageManagementControllerUtils
{
    private static Configuration cfg           = Configuration.getConfig();
    private static Token         token         = cfg.getAdminUAAToken();
    private static final String  BASE_URI_BETA = EmapiConstants.EM_API_BETA_BASE + EmapiConstants.PACKAGE_MANAGEMENT
            + "/packages";
    private static final String  BASE_URI_V1   = EmapiConstants.EM_API_BASE + EmapiConstants.PACKAGE_MANAGEMENT
            + "/packages";

    // PATCH /emapi/v1/package-management/packages [Not implemented] Update package metadata
    public static Response updatePackageMetadataV1(String payload)
    {
        return RestClient.patch(cfg.getEdgeManagerUrl(), BASE_URI_V1, payload, token);
    }

    // GET /emapi/v1/package-managment/packages get the list of the package.
    public static Response getPackageListV1(String contains, String filter, String sort, String order)
    {
        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("contains", contains);
        queryParams.put("filter", filter);
        queryParams.put("offset", 0);
        queryParams.put("sort", sort);
        queryParams.put("order", order);
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_V1, queryParams, token);
    }

    // GET /emapi/v1/package-managment/packages get the list of the package.
    public static Response getPackageListV1()
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_V1, null, token);
    }

    // POST /emapi/v1/package-management/packages Create a package.
    public static Response createUploadIdV1(String payload)
    {
        return RestClient.post(cfg.getEdgeManagerUrl(), BASE_URI_V1, payload, token);
    }

    // GET /emapi/v1/package-management/packages/grouped Get a list of all package grouped by type, name.
    public static Response getGroupedPackagesV1(String contains, String filter, String sort, String order)
    {
        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("contains", contains);
        queryParams.put("filter", filter);
        queryParams.put("offset", 0);
        queryParams.put("sort", sort);
        queryParams.put("order", order);

        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_V1 + "/grouped", queryParams, token);
    }

    // POST /emapi/v1/package-management/packages/signature/validate Verify signature for package
    public static Response verifySignatureV1(String type, String name, String version, String hash, String deviceId,
            String revision)
    {
        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("type", type);
        queryParams.put("name", name);
        queryParams.put("version", version);
        queryParams.put("hash", hash);
        if ( deviceId != null )
        {
            queryParams.put("deviceId", deviceId);
        }
        if ( revision != null )
        {
            queryParams.put("revision", revision);
        }
        return RestClient.postWithParams(cfg.getEdgeManagerUrl(), BASE_URI_V1 + "/signature/validate", queryParams,
                token);
    }

    // DELETE /emapi/v1/package-management/packages/uploads/{uploadId} Cancel upload and delete upload ID
    public static Response cancelUploadV1(String uploadId)
    {
        return RestClient.delete(cfg.getEdgeManagerUrl(), BASE_URI_V1 + "/uploads/" + uploadId, token);
    }

    // GET /emapi/v1/package-management/packages/uploads/{uploadId} Get package upload progress
    public static Response getPackageUploadStatusV1(String uploadId)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_V1 + "/uploads/" + uploadId, null, token);
    }

    // POST /emapi/v1/package-management/packages/uploads/{uploadId} Upload content for a package.
    public static Response uploadPackageV1(String uploadId, String fileName)
    {
        return RestClient.postWithMultiPart(cfg.getEdgeManagerUrl(), BASE_URI_V1 + "/uploads/" + uploadId, fileName,
                token);
    }

    // PUT /emapi/v1/package-management/packages/uploads/{uploadId} Upload content for a package.
    public static Response putFileAsChunkV1(String uploadId, String fileName, int chunkNumber)
    {
        return RestClient.putFileAsChunk(cfg.getEdgeManagerUrl() + BASE_URI_V1 + "/uploads/" + uploadId, fileName,
                chunkNumber, token);
    }

    // PUT /emapi/v1/package-management/packages/uploads/{uploadId} Upload content for a package.
    public static Response uploadMultipartPackagePutSingleChunkV1(String uploadId, String fileName)
    {
        return RestClient.putWithMultipartChunked(cfg.getEdgeManagerUrl(), BASE_URI_V1 + "/uploads/" + uploadId,
                fileName, token);
    }

    // PUT /emapi/v1/package-management/packages/uploads/complete/{uploadId} Finish upload operation
    public static Response completePackageUploadV1(String uploadId)
    {
        return RestClient.put(cfg.getEdgeManagerUrl(), BASE_URI_V1 + "/uploads/complete/" + uploadId, "", token);
    }

    // DELETE /emapi/v1/package-management/packages/{type}/{name}/{version} Delete a package
    public static Response deletePackageV1(String type, String name, String version)
    {
        return RestClient.delete(cfg.getEdgeManagerUrl(), BASE_URI_V1 + "/" + type + "/" + name + "/" + version, token);
    }

    // GET /emapi/v1/package-management/packages/{type}/{name}/{version} Get metadata for a package
    public static Response getPackageMetadataV1(String type, String name, String version)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_V1 + "/" + type + "/" + name + "/" + version, null,
                token);
    }

    // GET /emapi/v1/package-management/packages/{type}/{name}/{version}/content Download a package
    public static Response downloadPackageV1(String type, String name, String version)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(),
                BASE_URI_V1 + "/" + type + "/" + name + "/" + version + "/content", null, token);
    }

    // GET /emapi/v1/package-management/packages/{type}/{name}/{version}/signature Download a package signature
    public static Response downloadPackageSignatureV1(String type, String name, String version)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(),
                BASE_URI_V1 + "/" + type + "/" + name + "/" + version + "/signature", null, token);
    }

    public void setToken(Token token)
    {
        PackageManagementControllerUtils.token = token;
    }

    public Token getToken()
    {
        return PackageManagementControllerUtils.token;
    }

}
