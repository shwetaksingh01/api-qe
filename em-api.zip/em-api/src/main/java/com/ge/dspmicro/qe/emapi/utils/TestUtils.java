/*
 * Copyright (c) 2012 - 2017 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.emapi.utils;

import static org.testng.Assert.assertEquals;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import com.ge.dspmicro.qe.emapi.pojo.PackagePojo;
import com.ge.dspmicro.qe.tools.environment.Configuration;
import com.jayway.restassured.response.Response;

/**
 * 
 * @author 212547153
 */
@SuppressWarnings(
{
        "nls", "javadoc"
})
public class TestUtils
{
    private static Logger _logger = LoggerFactory.getLogger(TestUtils.class);

    public static boolean uploadPackage(PackagePojo pkg)
            throws InterruptedException
    {

        Response response = PackageManagementControllerUtils.uploadPackageV1(pkg.getUploadId(), pkg.getFileName());
        Assert.assertEquals(response.statusCode(), 200,
                "Package upload failed with status code: " + response.statusCode());
        boolean isPkgUploaded = false, wait = true;
        int retryCount = 0;
        while (wait)
        {
            response = PackageManagementControllerUtils.getPackageUploadStatusV1(pkg.getUploadId());
            assertEquals(response.statusCode(), 200);
            String status = response.jsonPath().getString("status");
            if ( status.equalsIgnoreCase("successful") )
            {
                wait = false;
                isPkgUploaded = true;
            }
            else if ( status.equalsIgnoreCase("failed") )
            {
                wait = false;
            }
            else if ( retryCount < 10 )
            {
                retryCount++;
                Thread.sleep(3000);
            }
            else
            {
                _logger.info("\tFailed to upload Package upload package in about 30 secs for " + pkg.getUploadId());
                break;
            }
        }

        return isPkgUploaded;

    }

    public static boolean envSupportCheck(Configuration cfg)
    {
        boolean isSupported = true;
        List<String> supportedEnv = Arrays.asList("int", "sysint", "stage");
        if ( !supportedEnv.contains(cfg.getEnvProp()) )
        {
            isSupported = false;
        }
        return isSupported;
    }
}
