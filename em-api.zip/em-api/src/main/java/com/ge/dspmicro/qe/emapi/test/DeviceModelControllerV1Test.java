/*
 * Copyright (c) 2019 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.emapi.test;

import static com.ge.dspmicro.qe.tools.utils.CommonUtils.encodeFileToBase64Binary;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ge.dspmicro.qe.emapi.utils.DeviceControllerUtils;
import com.ge.dspmicro.qe.emapi.utils.DeviceModelControllerUtils;
import com.ge.dspmicro.qe.tools.BaseTest;
import com.ge.dspmicro.qe.tools.testng.TestListener;
import com.ge.dspmicro.qe.tools.utils.CommonUtils;
import com.ge.dspmicro.qe.tools.utils.RestClient;
import com.ge.predix.edgemanager.qe.annotations.JiraTestCaseInfo;
import com.jayway.restassured.response.Response;

/**
 *
 * @author 212722187
 */

@SuppressWarnings(
{
        "javadoc", "nls"
})
@Listeners(TestListener.class)
public class DeviceModelControllerV1Test extends BaseTest
{

    private static final Logger _logger = LoggerFactory.getLogger(DeviceModelControllerV1Test.class);

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get request to return list of device models", description = "Get request to return list of device models and validate the status code as 200(OK)", preCondition = "Device with model id should be added in the system")
    public void testGetDeviceModels()
    {

        Response response = DeviceModelControllerUtils.getDeviceModelsV1();
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK,
                String.format("Expected status code is %d. Found %d", HttpStatus.SC_OK, response.statusCode()));
        List<Map<String, Object>> models = response.jsonPath().getList("$");
        _logger.info("\tTotal models : {}", models.size());
        softAssert.assertTrue(models.size() <= 100);
        for (Map<String, Object> model : models)
        {
            softAssert.assertTrue(model.containsKey("modelId"), model.get("modelId") + " modelId is not not present");
        }
        softAssert.assertAll();

    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Test to create,update and delete device model", description = "Test to create,update and delete device model", preCondition = "Device with model id should be added in the system")
    public void testAddUpdateDeleteDeviceModel()
            throws IOException
    {

        String modelId = "QE-Model-" + System.currentTimeMillis() / 1000;
        // get bomid for assigning to device model
        Response response = RestClient.get(cfg.getEdgeManagerUrl(), "/emapi/v1/bom-management/boms?limit=1&offset=0",
                null, cfg.getAdminUAAToken());
        int bomId = response.jsonPath().getInt("[0].bomId");
        Assert.assertNotNull(bomId, "BomId is expected not to be null");

        String payload = CommonUtils.getResourceAsString("/deviceModel/addDeviceModel.json")
                .replace("$bomId", bomId + "").replace("$core", "4").replace("$description", "QE-Test Device Model")
                .replace("$icon",
                        encodeFileToBase64Binary(CommonUtils.getResourceAsInputStream("/deviceModel/icon.png")))
                .replace("$modelid", modelId).replace("$memory", "16").replace("$os", "Windows XP")
                .replace("$photo",
                        encodeFileToBase64Binary(CommonUtils.getResourceAsInputStream("/deviceModel/photo.jpeg")))
                .replace("$processor", "Intel").replace("$storage", "24");

        _logger.info("\tAddDeviceModel request payload: {}", payload.replaceAll("\n", ""));

        response = DeviceModelControllerUtils.addDeviceModelV1(payload);

        _logger.info("\tAddDeviceModel response status code: {}", response.statusCode());

        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_CREATED,
                String.format("Expected status code is %d. Found %d", HttpStatus.SC_CREATED, response.statusCode()));

        // Add the same device model again. Should fail with 409 Bad Request.
        response = DeviceModelControllerUtils.addDeviceModelV1(payload);
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_CONFLICT,
                String.format("Expected status code is %d. Found %d", HttpStatus.SC_CONFLICT, response.statusCode()));
        softAssert.assertEquals(response.jsonPath().getString("message"),
                String.format("Device model %s is already exist.", modelId));

        // GetDeviceModels and verify the device model added exist. Assert on all the attributes.
        response = DeviceModelControllerUtils.getDeviceModelsV1();

        List<Map<String, Object>> models = response.jsonPath().getList("$");
        _logger.info("\tTotal models : {}", models.size());
        softAssert.assertTrue(models.size() > 0, "");
        softAssert.assertTrue(response.asString().contains(modelId));
        for (Map<String, Object> model : models)
        {
            if ( model.get("modelId").equals(modelId) )
            {
                _logger.info("\tModel Id details: {}", model.toString());
                softAssert.assertTrue(model.get("modelId").equals(modelId), "Expected modelId is" + modelId);
                softAssert.assertTrue(model.get("autoBomId").equals(bomId + ""),
                        "Expected autoBomeId is " + bomId);
                softAssert.assertTrue(model.get("description").equals("QE-Test Device Model"),
                        "Expected description is QE-Test Device Model");
                softAssert.assertTrue(model.get("os").equals("Windows XP"), "Expected os is Windows XP");
                softAssert.assertTrue(model.get("processor").equals("Intel"), "Expected processor is Intel");
                softAssert.assertTrue((Integer) model.get("coreNum") == 4, "Expected number of core is 4");
                softAssert.assertTrue((Float) model.get("memoryGB") == 16, "Expected memory is 16 GB");
                softAssert.assertTrue((Float) model.get("storageGB") == 24, "Expected storage is 24 GB");

                // validate custom attributes
                String customAttr = model.get("customAttributes").toString();
                softAssert.assertTrue(customAttr.contains("attribute01"), "Does not contain attribute01");
                softAssert.assertTrue(customAttr.contains("attribute02"), "Does not contain attribute02");
                softAssert.assertTrue(customAttr.contains("attr01"), "Does not contain attr01");
                softAssert.assertTrue(customAttr.contains("attr02"), "Does not contain attr02");
            }
        }

        // update device model. Assert on attributes after update
        payload = IOUtils.toString(CommonUtils.getResourceAsInputStream("/deviceModel/updateDeviceModel.json"))
                .replace("$bomId", bomId + "").replace("$processor", "AMD")
                .replace("$description", "QE-Test Updated Device Model").replace("$os", "Ubuntu")
                .replace("$storage", "128").replace("$memory", "32").replace("$core", "8").replace("$modelid", modelId)
                .replace("$photo",
                        encodeFileToBase64Binary(CommonUtils.getResourceAsInputStream("/deviceModel/photo.jpeg")))
                .replace("$icon",
                        encodeFileToBase64Binary(CommonUtils.getResourceAsInputStream("/deviceModel/icon.png")));

        _logger.info("\tUpdateDeviceModel payload: {}", payload.replaceAll("\n", ""));
        response = DeviceModelControllerUtils.updateOrAddDeviceModelsV1(modelId, payload);

        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_NO_CONTENT,
                String.format("Expected status code is %d. Found %d", HttpStatus.SC_NO_CONTENT, response.statusCode()));

        response = DeviceModelControllerUtils.getDeviceModelsV1();
        models = response.jsonPath().getList("$");
        _logger.info("\tTotal models : {}", models.size());
        softAssert.assertTrue(models.size() > 0, "models size is == 0");
        softAssert.assertTrue(response.asString().contains(modelId), "Expected to have modelId : " + modelId);
        for (Map<String, Object> model : models)
        {
            if ( model.get("modelId").equals(modelId) )
            {
                softAssert.assertTrue(model.get("modelId").equals(modelId),
                        "Expected modelId is: " + modelId);
                softAssert.assertTrue(model.get("autoBomId").equals(bomId + ""),
                        "Expected autoBomeId is : " + bomId);
                softAssert.assertTrue(model.get("description").equals("QE-Test Updated Device Model"),
                        "Expected description is QE-Test Updated Device Model");
                softAssert.assertTrue(model.get("os").equals("Ubuntu"),
                        "Expected os is : Ubuntu but found os is: " + model.get("os"));
                softAssert.assertTrue(model.get("processor").equals("AMD"),
                        "Expected processor is AMD but found :" + model.get("processor"));
                softAssert.assertTrue((Integer) model.get("coreNum") == 8,
                        "Expected number of core is 8 but found :" + model.get("coreNum"));
                softAssert.assertTrue((Float) model.get("memoryGB") == 32,
                        "Expected memory is 32 GB but found :" + model.get("memoryGB") + " GB");
                softAssert.assertTrue((Float) model.get("storageGB") == 128,
                        "Expected storage is 128 GB but found :" + model.get("storageGB" + " GB"));
                // validate custom attributes
                String customAttr = model.get("customAttributes").toString();
                softAssert.assertTrue(customAttr.contains("attribute01"), "Does not contain attribute01");
                softAssert.assertTrue(customAttr.contains("attribute02"), "Does not contain attribute02");
                softAssert.assertTrue(customAttr.contains("updatedAttr01"), "Does not contain updatedAttr01");
                softAssert.assertTrue(customAttr.contains("attr02"), "Does not contain attr02");
            }
        }

        // Add Device with new device model
        String deviceId = "qe-device-" + System.currentTimeMillis() / 1000;
        response = DeviceControllerUtils.createDeviceWithDeviceIdAndModeldIdV1(deviceId, modelId);
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_CREATED,
                String.format("Expected status code is %d. Found %d", HttpStatus.SC_CREATED, response.statusCode()));

        // Delete device model associated with a device. Expected to fail
        response = DeviceModelControllerUtils.deleteDeviceModelV1(modelId);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_NOT_ACCEPTABLE, String
                .format("Expected status code is %d. Found %d", HttpStatus.SC_NOT_ACCEPTABLE, response.statusCode()));
        softAssert.assertEquals(response.jsonPath().getString("message"),
                String.format("Cannot delete device model being used, id: %s.", modelId));
        response = DeviceControllerUtils.deleteDeviceV1(deviceId);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_NO_CONTENT,
                String.format("Expected status code is %d. Found %d", HttpStatus.SC_NO_CONTENT, response.statusCode()));

        // delete device model
        response = DeviceModelControllerUtils.deleteDeviceModelV1(modelId);

        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_NO_CONTENT,
                String.format("Expected status code is %d. Found %d", HttpStatus.SC_NO_CONTENT, response.statusCode()));

        // try to delete again
        response = DeviceModelControllerUtils.deleteDeviceModelV1(modelId);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_NOT_FOUND,
                String.format("Expected status code is %d. Found %d", HttpStatus.SC_NOT_FOUND, response.statusCode()));
        softAssert.assertTrue(response.asString().contains(String.format("model : %s not found", modelId)));

        // update device model after delete (should add device model again
        response = DeviceModelControllerUtils.updateOrAddDeviceModelsV1(modelId, payload);
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_CREATED,
                String.format("Expected status code is %d. Found %d", HttpStatus.SC_CREATED, response.statusCode()));

        // delete device model
        response = DeviceModelControllerUtils.deleteDeviceModelV1(modelId);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_NO_CONTENT,
                String.format("Expected status code is %d. Found %d", HttpStatus.SC_NO_CONTENT, response.statusCode()));

        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Test to create device model with minimum payload", description = "Test to create device model with minimum payload and validate the status code as 201(Created)", preCondition = "Systemshould be stable to post a request")
    public void testDeviceModelWithMinPayload()
    {

        String modelId = "QE-Model-" + System.currentTimeMillis() / 1000;
        Response response;
        try
        {
            String payload = CommonUtils.getResourceAsString("/deviceModel/addDeviceModelMinPayload.json")
                    .replace("$core", "4")
                    .replace("$icon",
                            encodeFileToBase64Binary(CommonUtils.getResourceAsInputStream("/deviceModel/icon.png")))
                    .replace("$modelid", modelId).replace("$memory", "16")
                    .replace("$description", "Test device with min payload").replace("$os", "Windows XP")
                    .replace("$photo",
                            encodeFileToBase64Binary(CommonUtils.getResourceAsInputStream("/deviceModel/photo.jpeg")))
                    .replace("$processor", "Intel").replace("$storage", "24");

            _logger.info("\tAddDeviceModel request payload: {}", payload.replaceAll("\n", ""));

            response = DeviceModelControllerUtils.addDeviceModelV1(payload);

            _logger.info("\tAddDeviceModel response status code: {}", response.statusCode());

            softAssert.assertEquals(response.statusCode(), HttpStatus.SC_CREATED, String
                    .format("Expected status code is %d. Found %d", HttpStatus.SC_CREATED, response.statusCode()));
        }
        finally
        {
            DeviceModelControllerUtils.deleteDeviceModelV1(modelId);
        }

        softAssert.assertAll();

    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Test to create device model with missing required Attributes in payload", description = "Test to create device model with missing required Attributes in payload and validate the status code as 400 (BAD REQUEST)", preCondition = "System should be stable to post a request")
    public void testDeviceModelWithMissingRequiredAttributesInPayload() // DE45909
    {

        String modelId = "QE-Model-" + System.currentTimeMillis() / 1000;

        String payload = CommonUtils.getResourceAsString("/deviceModel/addDeviceModelMissingRequired.json")
                .replace("$core", "4")
                .replace("$icon",
                        encodeFileToBase64Binary(CommonUtils.getResourceAsInputStream("/deviceModel/icon.png")))
                .replace("$modelid", modelId).replace("$memory", "16").replace("$os", "Windows XP")
                .replace("$photo",
                        encodeFileToBase64Binary(CommonUtils.getResourceAsInputStream("/deviceModel/photo.jpeg")))
                .replace("$processor", "Intel").replace("$storage", "24");
        _logger.info("\tAddDeviceModel request payload: {}", payload.replaceAll("\n", ""));

        Response response = DeviceModelControllerUtils.addDeviceModelV1(payload);

        _logger.info("\tAddDeviceModel response status code: {}", response.statusCode());
        // DE45909 add assertion for missing attributes in the request.
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_BAD_REQUEST, String
                .format("Expected status code is %d. Found %d", HttpStatus.SC_BAD_REQUEST, response.statusCode()));

        softAssert.assertAll();

    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get request to return list of device models images", description = "Get request to return list of device models images and validate the status code as 200(OK)", preCondition = "Device with model id should be added in the system")
    public void testGetDeviceModelImage()
    {
        Response response = DeviceModelControllerUtils.getDeviceModelImageV1("FieldAgent-Mini");
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK,
                String.format("Expected status code is %d. Found %d", HttpStatus.SC_OK, response.statusCode()));
        softAssert.assertNotNull(response.asString(), "getDeviceModelImage returned empty");
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get request to return list of device models image using invalid device model", description = "Get request to return list of device models image using invalid device model and validate the status code as 406(NOT ACCEPTABLE)", preCondition = "Device with model id should be added in the system")
    public void testGetDeviceModelImageForInvalidDeviceModel()
    {

        Response response = DeviceModelControllerUtils.getDeviceModelImageV1("model-donot-exist");
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_NOT_FOUND, String
                .format("Expected status code is %d. Found %d", HttpStatus.SC_NOT_FOUND, response.statusCode()));
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Delete request invalid device model", description = "Delete request invalid device model and validate the status code as 404(NOT FOUND)", preCondition = "Device with model id should be added in the system")
    public void testDeleteDeviceModelForInvalidDeviceModel()
    {

        Response response = DeviceModelControllerUtils.deleteDeviceModelV1("model-donot-exist");
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_NOT_FOUND,
                String.format("Expected status code is %d. Found %d", HttpStatus.SC_NOT_FOUND, response.statusCode()));
        softAssert.assertEquals(response.asString(),
                String.format("{\"code\":404,\"message\":\"model : %s not found\"}", "model-donot-exist"));
        softAssert.assertAll();
    }

    // negative tests
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Test to create device model with invalid BOM id", description = "Test to create device model with invalid BOM id and validate the status code as 400 (BAD REQUEST)", preCondition = "System should be stable to post a request")
    public void testAddDeviceModelWithInvalidBOMid()
            throws IOException
    {

        String modelId = "QE-Model-" + System.currentTimeMillis() / 1000;
        // get bomid for assigning to device model
        Response response;

        String payload = IOUtils.toString(CommonUtils.getResourceAsInputStream("/deviceModel/addDeviceModel.json"))
                .replace("$bomId", "1111111111111111").replace("$core", "4")
                .replace("$description", "QE-Test Device Model")
                .replace("$icon",
                        encodeFileToBase64Binary(CommonUtils.getResourceAsInputStream("/deviceModel/icon.png")))
                .replace("$modelid", modelId).replace("$memory", "16").replace("$os", "Windows XP")
                .replace("$photo",
                        encodeFileToBase64Binary(CommonUtils.getResourceAsInputStream("/deviceModel/photo.jpeg")))
                .replace("$processor", "Intel").replace("$storage", "24");
        response = DeviceModelControllerUtils.addDeviceModelV1(payload);

        _logger.info("\tAddDeviceModel response status code: {}", response.statusCode());
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_BAD_REQUEST, String
                .format("Expected status code is %d. Found %d", HttpStatus.SC_BAD_REQUEST, response.statusCode()));
        softAssert.assertTrue(response.asString().contains(
                "The following errors were encountered when validating the requested model:!deviceModelRequest.autoBomId!"));

        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get request to return device count per model", description = "Get request to return device count per model and validate the status code as 200(OK)", preCondition = "Device with model id should be added in the system")
    public void testGetDeviceCountPerModel()
    {

        String modelId = "QE-Model-" + System.currentTimeMillis() / 1000;
        String deviceId = "qe-device-" + System.currentTimeMillis() / 1000;
        Response response;
        try
        {
            // Step 1: Add device model
            String payload = CommonUtils.getResourceAsString("/deviceModel/addDeviceModel.json")
                    .replace("\"autoBomId\" : \"$bomId\",", "").replace("$core", "4")
                    .replace("$description", "QE-Test Device Model")
                    .replace("$icon",
                            encodeFileToBase64Binary(CommonUtils.getResourceAsInputStream("/deviceModel/icon.png")))
                    .replace("$modelid", modelId).replace("$memory", "16").replace("$os", "Windows XP")
                    .replace("$photo",
                            encodeFileToBase64Binary(CommonUtils.getResourceAsInputStream("/deviceModel/photo.jpeg")))
                    .replace("$processor", "Intel").replace("$storage", "24");
            _logger.info(payload);
            response = DeviceModelControllerUtils.addDeviceModelV1(payload);
            softAssert.assertEquals(response.statusCode(), HttpStatus.SC_CREATED, String
                    .format("Expected status code is %d. Found %d", HttpStatus.SC_CREATED, response.statusCode()));

            // Step 2: getDeviceModels and get list from the response
            response = DeviceModelControllerUtils.getDeviceModelsV1();
            softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK,
                    String.format("Expected status code is %d. Found %d", HttpStatus.SC_OK, response.statusCode()));
            List<String> models = response.jsonPath().getList("findAll {it.modelId}.modelId");
            softAssert.assertTrue(models.contains(modelId));

            // Step 3: get device count for the models and assert the new device model is not returned
            response = DeviceModelControllerUtils.getDeviceCountPerModelV1();
            softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK,
                    String.format("Expected status code is %d. Found %d", HttpStatus.SC_OK, response.statusCode()));
            List<String> modelsFromDeviceCount = response.jsonPath().getList("findAll {it.modelId}.modelId");
            softAssert.assertTrue(!modelsFromDeviceCount.contains(modelId));

            // Step 4: add device using the model added in step 1
            response = DeviceControllerUtils.createDeviceWithDeviceIdAndModeldIdV1(deviceId, modelId);
            softAssert.assertEquals(response.statusCode(), HttpStatus.SC_CREATED, String
                    .format("Expected status code is %d. Found %d", HttpStatus.SC_CREATED, response.statusCode()));

            // Step 5 : get device count for the models and assert the new device model is present and device count is 1
            response = DeviceModelControllerUtils.getDeviceCountPerModelV1();
            softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK,
                    String.format("Expected status code is %d. Found %d", HttpStatus.SC_OK, response.statusCode()));
            modelsFromDeviceCount = response.jsonPath().getList("findAll {it.modelId}.modelId");
            softAssert.assertTrue(modelsFromDeviceCount.contains(modelId));
            List<Map<String, Object>> modelDeviceCount = response.jsonPath().getList("$");
            for (Map<String, Object> deviceCount : modelDeviceCount)
            {
                if ( deviceCount.get("modelId").equals(modelId) )
                {
                    _logger.info("\tAsserting that device count is 1 for {} device model.", modelId);
                    softAssert.assertEquals(deviceCount.get("count"), 1);
                }
            }

            softAssert.assertAll();
        }
        finally
        {
            // delete device
            DeviceControllerUtils.deleteDeviceV1(deviceId);

            // delete device model
            DeviceModelControllerUtils.deleteDeviceModelV1(modelId);

        }
    }

}
