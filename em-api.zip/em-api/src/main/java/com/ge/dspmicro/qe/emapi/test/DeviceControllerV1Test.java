/*
 * Copyright (c) 2019 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.emapi.test;

import static com.ge.dspmicro.qe.tools.utils.CommonUtils.readCSVtoMap;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Type;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ge.dspmicro.qe.device.utils.DeviceGroupControllerUtils;
import com.ge.dspmicro.qe.emapi.pojo.DevicePojo;
import com.ge.dspmicro.qe.emapi.utils.DeviceControllerUtils;
import com.ge.dspmicro.qe.emapi.utils.DeviceOperationControllerUtils;
import com.ge.dspmicro.qe.emapi.utils.EmapiConstants;
import com.ge.dspmicro.qe.emapi.utils.TestUtils;
import com.ge.dspmicro.qe.tools.BaseTest;
import com.ge.dspmicro.qe.tools.QEConstants;
import com.ge.dspmicro.qe.tools.testng.TestListener;
import com.ge.dspmicro.qe.tools.utils.CertEnrolledDeviceInfo;
import com.ge.dspmicro.qe.tools.utils.CommonUtils;
import com.ge.predix.edgemanager.qe.annotations.JiraTestCaseInfo;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;

/**
 * @author 212756555
 */

@SuppressWarnings({"javadoc", "nls", "unused", "unchecked"
})
@Listeners(TestListener.class)
public class DeviceControllerV1Test
        extends BaseTest
{

    private static final Logger     _logger     = LoggerFactory.getLogger(DeviceControllerV1Test.class);

    private static String           patchDevicePayload;
    private static String           patchDevicePayloadToRemove;
    private static String           operationId;

    private static List<String>     devices     = new ArrayList<>();
    private static List<DevicePojo> devicePojos = new ArrayList<>();
    private static String           groupId;
    private static String           groupName;
    private static String           deviceNamePrefix;
    private static String           qeDeviceNameWithSimInfo;
    private static String           qePredixMachineDeviceWithKeysSetup;
    private static final int        RETRY_LIMIT = 10;
    private static String           qeDeviceName;
    private static String           deviceFilter;
    private boolean                 isSupported = true;

    @BeforeClass(alwaysRun = true)
    public void setup()
    {
        patchDevicePayload = CommonUtils.getResourceAsString("/device/patchDevicePayload.json");
        patchDevicePayloadToRemove = CommonUtils
                .getResourceAsString("/device/patchDevicePayloadToRemoveAttributes.json");

        qeDeviceNameWithSimInfo = cfg.getQeDeviceNameWithSim();
        qePredixMachineDeviceWithKeysSetup = cfg.getQePMDeviceName();
        if ( !StringUtils.isEmpty(qeDeviceNameWithSimInfo) )
        {
            _logger.info("QE Device Name: " + qeDeviceNameWithSimInfo);
        }
        qeDeviceName = cfg.getQeEADeviceName();
        if ( !StringUtils.isEmpty(qeDeviceName) )
        {
            _logger.info("QE Device Name: " + qeDeviceName);
        }
        deviceFilter = "deviceId in \"" + qeDeviceName + "\"";
        this.isSupported = TestUtils.envSupportCheck(cfg);
    }

    @DataProvider
    public Object[][] dataProvider1()
            throws IOException
    {
        List<Map<String, String>> data = readCSVtoMap("/device/addDeviceTest.csv");

        Object[][] dataArray = new Object[data.size()][1];

        for (int i = 0; i < data.size(); i++)
        {
            dataArray[i][0] = data.get(i);
        }

        return dataArray;
    }

    @Test(dataProvider = "dataProvider1")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Add device such that Device IDs must have a minimum length of 3 characters and a maximum of 63 characters", description = "Add device such that Device IDs must have a minimum length of 3 characters and a maximum of 63 characters validate the status code as 200(OK)", preCondition = "System should be stable for the device to be created")
    public void testAddDevice(Map<String, String> data)
    {
        String invalidDeviceIdMessage = String.format(
                "{%s=Invalid device ID. Device IDs must have a minimum length of 3 characters and a maximum of 63 characters. Device IDs may contain alphanumeric characters, underscores, and hyphens, but must start with an alphanumeric character.}",
                data.get("deviceId").toLowerCase());
        String invalidNameMessage = String.format(
                "{%s=Invalid device name. Device names must have a minimum length of 3 characters and a maximum of 63 characters. Device names may contain alphanumeric characters, underscores, hyphens, and colons, but must start with an alphanumeric character.}",
                data.get("deviceId").toLowerCase());
        if ( data.get("expectedStatusCode").equals("201") )
        {
            String deviceIdentifier = data.get("deviceId") + System.currentTimeMillis();
            deviceIdentifier = deviceIdentifier.length() > 63
                    ? deviceIdentifier.substring(deviceIdentifier.length() - 63)
                    : deviceIdentifier;
            data.put("deviceId", deviceIdentifier);
            devices.add(deviceIdentifier);
        }
        String payloadString = CommonUtils.getResourceAsString(data.get("payloadFile"));
        String finalPayload = payloadString.replaceAll("\\$deviceId", data.get("deviceId"))
                .replaceAll("\\$name", data.get("name")).replaceAll("\\$modelId", data.get("modelId"))
                .replaceAll("\\$sharedSecret", data.get("sharedSecret"));
        _logger.info("\tAddDevice payload: " + finalPayload);

        Response response = DeviceControllerUtils.createDeviceV1(finalPayload);
        softAssert.assertEquals(response.statusCode() + "", data.get("expectedStatusCode"),
                "Expected code and resonse code do not match");
        if ( !data.get("expectedStatusCode").equals("201") )
        {
            if ( data.get("expectedStatusMessage").equals("invalidDeviceId") )
            {
                softAssert.assertEquals(response.jsonPath().getString("message"), invalidDeviceIdMessage,
                        "Invalid message do not match");
            }
            else if ( data.get("expectedStatusMessage").equals("invalidName") )
            {
                softAssert.assertEquals(response.jsonPath().getString("message"), invalidNameMessage,
                        "Invalid message do not match");
            }
            else
            {
                softAssert.assertEquals(response.jsonPath().getString("message"), data.get("expectedStatusMessage"),
                        "expected Status Message message do not match");
            }
        }
        else
        {
            response = DeviceControllerUtils.getDeviceDetailsV1(data.get("deviceId"));
            JsonPath jsonPath = response.jsonPath();
            // assertions
            softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK, "Respose code do not match");
            softAssert.assertEquals(jsonPath.getString("name"), data.get("name"), "name do not match");
            softAssert.assertEquals(jsonPath.getString("modelId"), data.get("modelId"), "modelId do not match");
            softAssert.assertEquals(jsonPath.getString("deviceId"), data.get("deviceId").toLowerCase(),
                    "deviceId do not match");
            softAssert.assertNotNull(jsonPath.getString("deviceUuid"), "deviceUuid is null");
            softAssert.assertTrue(!jsonPath.getString("deviceUuid").equals(""), "deviceUuid is empty");
            softAssert.assertTrue(jsonPath.getString("deviceUuid").length() == 36,
                    "deviceUuid length is not 36 characters");
            softAssert.assertEquals(jsonPath.getString("status"), "created", "Device status is not created");
        }

        softAssert.assertAll();
    }

    @Test(dependsOnMethods = "testBatchAddDevices")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Update and Get device details after update", description = "Update the device and then get device details validate the status code as 200(OK)", preCondition = "Device should be created and then updated to get device details")
    public void testGetDeviceDetailsAfterUpdate()
            throws InterruptedException
    {

        String deviceId = "qe_test_device_" + CommonUtils.getTimeStamp_HH_mm_ss_SSS_yyyy_MM_dd();
        devices.add(deviceId);
        // add device
        Response response = DeviceControllerUtils.createDeviceWithDeviceIdAndModeldIdV1(deviceId, "FieldAgent");
        response.then().assertThat().statusCode(HttpStatus.SC_CREATED);

        _logger.info("\tGetting Device Details for deviceId " + deviceId);
        response = DeviceControllerUtils.getDeviceDetailsV1(deviceId);

        JsonPath jsonPath = response.jsonPath();
        softAssert.assertTrue(jsonPath.getString("name").equals(deviceId), "device name donot match");
        softAssert.assertTrue(jsonPath.getString("modelId").equals("FieldAgent"), "device name donot match");
        softAssert.assertTrue(jsonPath.getString("groupId").equals("0"), "groupId name donot match");
        softAssert.assertTrue(!jsonPath.getBoolean("dockerEnabled"), "dockerEnabled is not false");
        softAssert.assertTrue(jsonPath.getString("deviceId").equals(deviceId), "deviceId name donot match");
        String deviceUuid = jsonPath.getString("deviceUuid");
        softAssert.assertNotNull(jsonPath.getString("deviceUuid"), "deviceUuid is null");
        softAssert.assertTrue(jsonPath.getInt("upTime") == 0, "uptime is not 0");
        softAssert.assertTrue(jsonPath.getString("status").equals("created"), "Status is not created");

        // Patch Device
        String payload = patchDevicePayload.replaceAll("\\$delete", "")
                .replaceAll("\\$attributes", "{\\\"size\\\":\\\"5x6\\\", \\\"color\\\":\\\"red\\\"}")
                .replaceAll("\\$csn", "abcdefgh").replaceAll("\\$dockerEnabled", "true")
                .replaceAll("\\$description", "description-string").replaceAll("\\$groupId", "0")
                .replaceAll("\\$city", "San Ramon").replaceAll("\\$country", "USA")
                .replaceAll("\\$locationDescription", "San Ramon West").replaceAll("\\$elevation", "10000")
                .replaceAll("\\$latitude", "89.432").replaceAll("\\$longitude", "0.213").replaceAll("\\$photo", "")
                .replaceAll("\\$state", "CA").replaceAll("\\$timezone", "US/Pacific")
                .replaceAll("\\$modelId", "FieldAgent").replaceAll("\\$deviceId", "nameChanged")
                .replaceAll("\\$techId", "luke");

        _logger.info(String.format("\tPatching deviceId %s with payload : %s", deviceId, payload));
        response = DeviceControllerUtils.updateDeviceV1(deviceId, payload);
        response.then().assertThat().statusCode(HttpStatus.SC_NO_CONTENT);

        Thread.sleep(2000);
        _logger.info(String.format("\tGetting Device Details for deviceId %s after patch update", deviceId));
        response = DeviceControllerUtils.getDeviceDetailsWithKeysV1(deviceId, "customAttributes");

        jsonPath = response.jsonPath();
        softAssert.assertTrue(jsonPath.getString("name").equals("nameChanged"), "device name donot match after update");
        softAssert.assertTrue(jsonPath.getString("modelId").equals("FieldAgent"),
                "device name donot match after update");
        softAssert.assertTrue(jsonPath.getString("groupId").equals("0"), "groupId name donot match after update");
        softAssert.assertTrue(jsonPath.getString("technicianId").equals("luke"),
                "technicianId is not luke after update");
        softAssert.assertTrue(jsonPath.getBoolean("dockerEnabled"), "dockerEnabled is not true after update");
        softAssert.assertTrue(jsonPath.getString("description").equals("description-string"),
                "description is not description-string after update");
        // location
        softAssert.assertTrue(jsonPath.getString("location.description").equals("description-string"),
                "location.description is not updated");
        softAssert.assertTrue(jsonPath.getString("location.city").equals("San Ramon"), "location.city is not updated");
        softAssert.assertTrue(jsonPath.getString("location.state").equals("CA"), "location.state is not updated");
        softAssert.assertTrue(jsonPath.getString("location.country").equals("USA"), "location.country is not updated");
        softAssert.assertTrue(jsonPath.getString("location.timezone").equals("US/Pacific"),
                "location.timezone is not updated");
        softAssert.assertTrue(jsonPath.getDouble("location.elevation") == 10000, "location.elevation is not updated");
        softAssert.assertTrue(jsonPath.getDouble("location.latitude") == 89.432, "location.latitude is not updated");
        softAssert.assertTrue(jsonPath.getDouble("location.longitude") == 0.213, "location.longitude is not updated");
        softAssert.assertTrue(jsonPath.getString("deviceId").equals(deviceId),
                "deviceId name donot match after update");
        softAssert.assertTrue(jsonPath.getString("deviceUuid").equals(deviceUuid), "deviceUuid is null after update");
        softAssert.assertTrue(jsonPath.getInt("upTime") == 0, "uptime is not 0 after update");
        softAssert.assertTrue(jsonPath.getString("status").equals("created"), "Status is not created after update");
        softAssert.assertTrue(jsonPath.getString("attributes.size").equals("5x6"), "attributes.size not updated");
        softAssert.assertTrue(jsonPath.getString("attributes.color").equals("red"), "attributes.color not updated");

        // patch again to remove attributes dockerEnabled and location
        payload = patchDevicePayloadToRemove.replaceAll("\\$modelId", "FieldAgent").replaceAll("\\$deviceId", deviceId);
        _logger.info(String.format("\tPatching deviceId %s with payload : %s", deviceId, payload));
        response = DeviceControllerUtils.updateDeviceV1(deviceId, payload);
        response.then().assertThat().statusCode(HttpStatus.SC_NO_CONTENT);
        _logger.info(String.format("\tGetting Device Details for deviceId %s after patch update", deviceId));

        response = DeviceControllerUtils.getDeviceDetailsWithKeysV1(deviceId, "customAttributes");

        jsonPath = response.jsonPath();
        softAssert.assertTrue(jsonPath.getString("name").equals(deviceId), "device name donot match after update");
        softAssert.assertTrue(jsonPath.getString("modelId").equals("FieldAgent"),
                "device name donot match after update");
        softAssert.assertTrue(jsonPath.getString("groupId").equals("0"), "groupId name donot match after update");
        softAssert.assertTrue(jsonPath.getString("technicianId").equals("luke"),
                "technicianId is not luke after update");
        softAssert.assertTrue(jsonPath.getString("deviceId").equals(deviceId),
                "deviceId name donot match after update");
        softAssert.assertTrue(jsonPath.getString("deviceUuid").equals(deviceUuid), "deviceUuid is null after update");
        softAssert.assertTrue(jsonPath.getInt("upTime") == 0, "uptime is not 0 after update");
        softAssert.assertTrue(jsonPath.getString("status").equals("created"), "Status is not created after update");
        softAssert.assertTrue(jsonPath.getString("attributes.size").equals("5x6"), "attributes.size not updated");
        softAssert.assertTrue(jsonPath.getString("attributes.color").equals("red"), "attributes.color not updated");
        softAssert.assertTrue(!jsonPath.getBoolean("dockerEnabled"), "dockerEnabled is not false after update");

        softAssert.assertAll();
    }


    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Add devices in Batch", description = "Add devices in batch and validate the status code as 202(ACCEPTED)", preCondition = "System should be stable to Post a request to create devices in batch")
    public void testBatchAddDevices()
            throws InterruptedException
    {
        // add a group
        groupName = "batch-add-device cloud-qe em-api " + System.currentTimeMillis();
        Response response = DeviceGroupControllerUtils.addGroup(groupName, "0");
        _logger.info("\tAddGroup Location header:" + response.getHeader("Location"));
        String[] tokens = response.getHeader("Location").split("/");
        groupId = tokens[tokens.length - 1];
        _logger.info("\tCreated group \"" + groupName + "\" with groupId: " + groupId);
        // create payload for batchAddDevices
        deviceNamePrefix = "cloud-qe-em-api-" + System.currentTimeMillis();
        devicePojos = new LinkedList<>();
        for (int i = 1; i <= 5; i++)
        {
            String id = String.format(deviceNamePrefix + "batch-add-device-%03d", i);
            devicePojos.add(new DevicePojo(id, groupId));
        }

        Gson gson = new Gson();

        Type type = new TypeToken<List<DevicePojo>>()
        {
            private static final long serialVersionUID = 1L;
        }.getType();

        String payload = gson.toJson(devicePojos, type);
        _logger.info("\tBatchAddDevice payload: " + payload);

        response = DeviceControllerUtils.batchAddDevicesV1(payload);

        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_ACCEPTED,
                "Status code for batchAddDevice do not match");
        tokens = response.getHeader("Location").split("/");
        operationId = tokens[tokens.length - 1];
        softAssert.assertEquals(response.getHeader("Location").replaceAll(operationId, ""),
                EmapiConstants.EM_API_V1_VERSION + EmapiConstants.DEVICE_MANAGEMENT + "/operations/",
                "Location for operationId do not match");

        response = DeviceOperationControllerUtils.getDeviceManagementOperationStatus(operationId);
        JsonPath jsonPath = response.jsonPath();
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK,
                "Status code for getDeviceManagementOperationStatus do not match");
        softAssert.assertEquals(jsonPath.getString("type"), "create", "Type for batchAddDevice do not match");
        boolean isPending = true;

        // wait for operation to complete
        while (isPending)
        {
            response = DeviceOperationControllerUtils.getDeviceManagementOperationStatus(operationId);
            if ( !response.jsonPath().getString("state").equals("pending")
                    && !response.jsonPath().getString("state").equals("running") )
            {
                isPending = false;
            }
            else
            {
                Thread.sleep(1000);
            }
        }
        // assert that devices exist in the system
        for (DevicePojo devicePojo : devicePojos)
        {
            response = DeviceControllerUtils.getDeviceDetailsV1(devicePojo.getDeviceId());
            softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK, "Deleting device failed");
        }
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Add devices in Batch with empty payload", description = "Add devices in batch with empty payload and validate the status code as 400(Bad Request)", preCondition = "System should be stable to Post a request to create devices in batch")
    public void testBatchAddDevicesWithEmptyPayload()
    {
        Response response = DeviceControllerUtils.batchAddDevicesV1("[]");

        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_BAD_REQUEST,
                "Status code for batchAddDevice do not match");
        softAssert.assertAll();

    }

    @DataProvider
    public Object[][] getDevicesDataProvider()
    {

        // filter=filter&
        // groupFilter=groupFilter&
        // limit=10&
        // offset=0&
        // contains=abcd&
        // sort=name&
        // order=desc&
        // keys=keys
        Map<String, Object> set1 = new HashMap<>();
        set1.put("groupFilter", "inGroup eq " + groupId);

        Map<String, Object> set2 = new HashMap<>();
        set2.put("contains", deviceNamePrefix);
        set2.put("limit", "2");
        set2.put("offset", "3");
        set2.put("sort", "name");
        set2.put("order", "asc");

        Map<String, Object> set3 = new HashMap<>();

        Map<String, Object> set4 = new HashMap<>();
        set4.put("filter", "deviceId co \"" + deviceNamePrefix + "\"");

        Map<String, Object> set5 = new HashMap<>();
        set5.put("filter", "\"batch-\"");

        Map<String, Object> set6 = new HashMap<>();
        set6.put("key", "value");
        return new Object[][]
        {
                {
                        "GetDevices with group Filter", set1, devicePojos.size(), devicePojos.size(), HttpStatus.SC_OK
                },
                {
                        "GetDevices with group Filter", set2, 2, devicePojos.size(), HttpStatus.SC_OK
                },
                {
                        "GetDevices with group Filter", set3, 50, 50, HttpStatus.SC_OK
                },
                {
                        "GetDevices with  Filter = \"deviceId co \\\"" + deviceNamePrefix + "\\\"\"", set4, 5, 5,
                        HttpStatus.SC_OK
                },
                {
                        "GetDevices with Invalid Filter = \"" + deviceNamePrefix + "\"", set5, 0, 0,
                        HttpStatus.SC_BAD_REQUEST
                },
                {
                        "GetDevices with invalid key value pair", set6, 50, 50, HttpStatus.SC_OK
                },
        };
    }

    @Test(dependsOnMethods = "testBatchAddDevices", dataProvider = "getDevicesDataProvider")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get device with different scenarios", description = "Get devices using group filters and validate the status code as 200(OK)", preCondition = "System should have devices mapped to groups")
    public void testGetDevices(String scenario, Map<String, Object> params, int expectedNumberOfDevices,
            int expectedTotalCount, int expectedStatusCode)
    {

        _logger.info("\tRunning Scenario: " + scenario);
        Response response = DeviceControllerUtils.getDevicesV1(params);
        softAssert.assertEquals(response.statusCode(), expectedStatusCode,
                "Response code and expected code do not match");
        JsonPath jsonPath = response.jsonPath();
        if ( expectedStatusCode == HttpStatus.SC_OK )
        {
            softAssert.assertEquals(jsonPath.getList("$").size(), expectedNumberOfDevices,
                    "Result count is not maching expected");
            if ( expectedNumberOfDevices != 50 )
            {
                softAssert.assertEquals(response.getHeader("Total-Count"), expectedTotalCount + "",
                        "Result count is not maching expected");
            }
        }
        softAssert.assertAll();
    }

    @DataProvider
    public Object[][] getDeviceAgentTypeFilterData()
    {

        return new Object[][]
        {
                // scenario, filter for agentType, filter out agentType, response_code
                {
                        "Filter for EdgeAgent devices only", QEConstants.EDGE_AGENT, QEConstants.PREDIX_MACHINE,
                        HttpStatus.SC_OK
                },
                {
                        "Filter for PredixMachine devices only", QEConstants.PREDIX_MACHINE, QEConstants.EDGE_AGENT,
                        HttpStatus.SC_OK
                }

        };

    }

    @Test(dependsOnMethods = "testBatchAddDevices", dataProvider = "getDeviceAgentTypeFilterData")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get device using Agent type filter", description = "Get device using Agent type filter and validate the status code as 200(OK)", preCondition = "System should have devices created with mapped Agent type")
    public void testGetDeviceWithAgentTypeFilter(String scenario, String filterForType, String filterOutType,
            int responseCode)
    {
        _logger.info("\tRunning: " + scenario);

        String filter = "agentType eq \"" + filterForType + "\"";
        Response response = DeviceControllerUtils.getDevicesWithFilterAndLimitV1(filter, 200);

        softAssert.assertEquals(response.statusCode(), responseCode, "Response codes do not match.");
        softAssert.assertTrue(!response.body().toString().contains(filterOutType),
                "GET with filter did not filter out all " + filterOutType + " agentType.");

        softAssert.assertAll();
    }

    @DataProvider
    public Object[][] getDeviceLocationFilterData()
    {
        return new Object[][]
        {
                {
                        "Filter for State equals and country not equals",
                        "location.state eq \"CA\" and location.country ne \"INDIA\"", "CA", 200
                },
                {
                        "Filter for City contains and country starts with equals",
                        "location.city co \"Ramon\" and location.country sw \"US\"", "San Ramon", 200
                }

        };

    }

    @Test(dataProvider = "getDeviceLocationFilterData")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get device using device location filter", description = "Get device using device location filter and validate the status code as 200(OK)", preCondition = "System should have devices created with mapped Location")
    public void testGetDeviceWithLocationFilter(String scenario, String filter, String contains, int responseCode)
    {
        _logger.info(String.format("\tRunning: %s", scenario));
        String deviceId = "qe_test_device_" + CommonUtils.getTimeStamp_HH_mm_ss_SSS_yyyy_MM_dd();
        devices.add(deviceId);
        String payload = "{\"modelId\":\"FieldAgent\",\"name\":\"$deviceId\",\"deviceId\":\"$deviceId\",\"sharedSecret\":\"sharedSecret\",\"location\":$location}"
                .replaceAll("\\$deviceId", deviceId).replaceAll("\\$location",
                        "{\\\"city\\\":\\\"San Ramon\\\",\\\"country\\\":\\\"USA\\\",\\\"state\\\":\\\"CA\\\"}");
        _logger.info("\tAddDevicePayload: " + payload);
        Response response = DeviceControllerUtils.createDeviceV1(payload);
        response.then().assertThat().statusCode(HttpStatus.SC_CREATED);
        response = DeviceControllerUtils.getDevicesWithFilterAndLimitV1(filter, 10);
        softAssert.assertEquals(response.statusCode(), responseCode, "Response codes do not match");
        softAssert.assertTrue(!response.body().toString().contains(contains),
                "GET devices with filter for location not filtering as expected:" + filter);
        List<Object> count = response.jsonPath().getList("$");
        softAssert.assertTrue(!count.isEmpty(), "Count of devices after applying filter:" + filter + ": should be > 0");
        softAssert.assertAll();
    }

    @Test(dependsOnMethods = "testBatchAddDevices")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Add device in batch using existing devices", description = "Add device in batch using existing devices and validate the status code as 400(Bad Request)", preCondition = "System should have devices created with mapped Location")
    public void testBatchAddDevicesWhenDevicesExist()
    {
        Gson gson = new Gson();

        Type type = new TypeToken<List<DevicePojo>>()
        {
            private static final long serialVersionUID = 1L;
        }.getType();

        String payload = gson.toJson(devicePojos, type);
        _logger.info("\tBatchAddDevice payload: " + payload);

        Response response = DeviceControllerUtils.batchAddDevicesV1(payload);
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_BAD_REQUEST,
                "Status code for batchAddDevice do not match");
        softAssert.assertAll();
    }

    @Test(dependsOnMethods = "testBatchAddDevices")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Post request to export devices to CSV format for list of devices", description = "Post request to export devices to CSV format for list of devices and validate the status code as 200(OK)", preCondition = "System should have devices")
    public void testExportDevicesToCSVForListOfDevices()
            throws IOException
    {
        List<HashMap<String, String>> deleteDeviceList = new LinkedList<>();
        devicePojos.forEach(it -> {
            HashMap<String, String> deviceMap = new HashMap<>();
            deviceMap.put("deviceId", it.getName());
            deleteDeviceList.add(deviceMap);
        });

        Gson gson = new Gson();

        Type type = new TypeToken<List<String>>()
        {
            private static final long serialVersionUID = 1L;
        }.getType();
        String payload = gson.toJson(deleteDeviceList, type);
        _logger.info("\tExportDevices payload: " + payload);
        Response response = DeviceControllerUtils.exportDevicesToCsvV1(payload, null);
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK, "Response code do not match");
        String csvFileName = System.currentTimeMillis() + ".csv";
        FileUtils.writeStringToFile(new File(csvFileName), response.asString());

        List<String> lines = FileUtils.readLines(new File(csvFileName), "utf-8");

        softAssert.assertEquals(lines.size() - 1, devicePojos.size(),
                "Number of records in CSV don't match number of devices in the group");
        // expected headers
        // upTime,modelID,name,config,did,status

        softAssert.assertTrue(lines.get(0).contains("modelID"), "Response do not contain modelID");
        softAssert.assertTrue(lines.get(0).contains("name"), "Response do not contain name");
        softAssert.assertTrue(lines.get(0).contains("config"), "Response do not contain config");
        softAssert.assertTrue(lines.get(0).contains("did"), "Response do not contain did");
        softAssert.assertTrue(lines.get(0).contains("status"), "Response do not contain status");

        softAssert.assertAll();
    }

    @Test(dependsOnMethods = "testExportDevicesToCSVForListOfDevices")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Post request to export devices to CSV format for list of devices from a Group", description = "Post request to export devices to CSV format for list of devices from a Group and validate the status code as 200(OK)", preCondition = "System should have devices")
    public void testExportDevicesToCSVForAgroup()
            throws IOException
    {
        Response response = DeviceControllerUtils.exportDevicesToCsvV1(null, groupId);
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK, "Response code do not match");

        String csvFileName = System.currentTimeMillis() + ".csv";

        FileUtils.writeStringToFile(new File(csvFileName), response.asString());

        List<String> lines = FileUtils.readLines(new File(csvFileName), "utf-8");

        softAssert.assertEquals(lines.size() - 1, devicePojos.size(),
                "Number of records in CSV don't match number of devices in the group");

        List<String> expectedHeaders = Arrays.asList("upTime", "capability", "syncInterval", "modelID", "name",
                "simInfoValidation", "location", "config", "vpnInfo", "did", "status", "createdBy", "createdOn",
                "certStatus");
        Collections.sort(expectedHeaders);
        List<String> actualHeaders = Arrays.asList(lines.get(0).split(","));
        Collections.sort(actualHeaders);
        softAssert.assertEquals(actualHeaders, expectedHeaders,
                String.format("CSV headers do not match. Actual: %s  Expected: %s", actualHeaders.toString(),
                        expectedHeaders.toString()));

        softAssert.assertAll();
    }

    @Test(dependsOnMethods = "testExportDevicesToCSVForAgroup")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Post request to export devices to CSV format for list of devices from a Group and list", description = "Post request to export devices to CSV format for list of devices from a Group and list and validate the status code as 200(OK)", preCondition = "System should have devices")
    public void testExportDevicesToCSVForAgroupAndList()
            throws IOException
    {
        List<HashMap<String, String>> deleteDeviceList = new LinkedList<>();
        devicePojos.forEach(it -> {
            HashMap<String, String> deviceMap = new HashMap<>();
            deviceMap.put("deviceId", it.getName());
            deleteDeviceList.add(deviceMap);
        });

        Gson gson = new Gson();

        Type type = new TypeToken<List<String>>()
        {
            private static final long serialVersionUID = 1L;
        }.getType();
        String payload = gson.toJson(deleteDeviceList, type);
        _logger.info("\tExportDevices payload: " + payload);
        Response response = DeviceControllerUtils.exportDevicesToCsvV1(payload, groupId);
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK, "Response code do not match");

        String csvFileName = System.currentTimeMillis() + ".csv";
        FileUtils.writeStringToFile(new File(csvFileName), response.asString());

        List<String> lines = FileUtils.readLines(new File(csvFileName), "utf-8");

        softAssert.assertEquals(lines.size() - 1, devicePojos.size(),
                "Number of records in CSV don't match number of devices in the group");
        // assert on expected headers
        List<String> expectedHeaders = Arrays.asList("upTime", "capability", "syncInterval", "modelID", "name",
                "simInfoValidation", "location", "config", "vpnInfo", "did", "status", "createdBy", "createdOn",
                "certStatus");
        Collections.sort(expectedHeaders);
        List<String> actualHeaders = Arrays.asList(lines.get(0).split(","));
        Collections.sort(actualHeaders);
        softAssert.assertEquals(actualHeaders, expectedHeaders,
                String.format("CSV headers do not match. Actual: %s  Expected: %s", actualHeaders.toString(),
                        expectedHeaders.toString()));

        softAssert.assertAll();
    }

    @Test(dependsOnMethods = "testExportDevicesToCSVForAgroupAndList")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Delete request to delete devices in batch", description = "Delete request to delete devices in batch and validate the status code as 202(ACCEPTED)", preCondition = "System should have devices in batch")
    public void testBatchDeleteDevices()
            throws InterruptedException
    {
        List<HashMap<String, String>> deleteDeviceList = new LinkedList<>();
        devicePojos.forEach(it -> {
            HashMap<String, String> deviceMap = new HashMap<>();
            deviceMap.put("deviceId", it.getName());
            deleteDeviceList.add(deviceMap);
        });

        Gson gson = new Gson();

        Type type = new TypeToken<List<String>>()
        {
            private static final long serialVersionUID = 1L;
        }.getType();
        String payload = gson.toJson(deleteDeviceList, type);
        _logger.info("\tBatchDeleteDevice payload: " + payload);
        Response response = DeviceControllerUtils.batchDeleteDevicesV1(payload);
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_ACCEPTED,
                "Status code for batchDeleteDevices do not match");

        String[] tokens = response.getHeader("Location").split("/");
        String packageOperationId = tokens[tokens.length - 1];
        softAssert.assertEquals(response.getHeader("Location").replaceAll(packageOperationId, ""),
                EmapiConstants.EM_API_V1_VERSION + EmapiConstants.DEVICE_MANAGEMENT + "/operations/",
                "Location for operationId do not match");

        response = DeviceOperationControllerUtils.getDeviceManagementOperationStatus(packageOperationId);
        JsonPath jsonPath = response.jsonPath();
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK,
                "Status code for getDeviceManagementOperationStatus do not match");
        softAssert.assertEquals(jsonPath.getString("type"), "delete", "Type for batchDeleteDevices do not match");
        boolean isPending = true;

        // wait for delete operation to complete
        while (isPending)
        {
            response = DeviceOperationControllerUtils.getDeviceManagementOperationStatus(packageOperationId);
            if ( !response.jsonPath().getString("state").equals("pending")
                    && !response.jsonPath().getString("state").equals("running") )
            {
                isPending = false;
            }
            else
            {
                Thread.sleep(1000);
            }
        }

        for (DevicePojo devicePojo : devicePojos)
        {
            response = DeviceControllerUtils.getDeviceDetailsV1(devicePojo.getDeviceId());
            softAssert.assertEquals(response.statusCode(), HttpStatus.SC_NOT_FOUND);
        }
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Add devices in batch with more than 1000 devices in payload", description = "Add devices in batch with more than 1000 devices in payload and validate the status code as 413(Request Too Long)", preCondition = "System should be able to post a request")
    public void testBatchAddDevicesWithMoreThanThousandDevices()
    {
        // create payload for batchAddDevices
        List<DevicePojo> devicePojos1001 = new LinkedList<>();
        for (int i = 1; i <= 1001; i++)
        {
            String id = String.format("batch-add-device-%03d", i);
            devicePojos1001.add(new DevicePojo(id, null));
        }

        Gson gson = new Gson();

        Type type = new TypeToken<List<DevicePojo>>()
        {
            private static final long serialVersionUID = 1L;
        }.getType();

        String payload = gson.toJson(devicePojos1001, type);
        _logger.info("\tBatchAddDevice payload: " + payload);

        Response response = DeviceControllerUtils.batchAddDevicesV1(payload);
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_REQUEST_TOO_LONG,
                "Status code for batchAddDevices do not match when number of devices is greater than 1000");
        softAssert.assertEquals(response.jsonPath().getString("message"),
                "Too many devices in device list. The maximum number of devices that can be added at once is 1000",
                "Error response do not match when number of devices is greater than 1000");
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get device with keys as info.sim,info.capability,info.vpn", description = "Get device with keys as info.sim,info.capability,info.vpn and validate the status code as 200(OK)", preCondition = "System should have devices with keys")
    public void testDeviceFilterWithKeys()

    {
        if ( !this.isSupported )
        {
            throw new SkipException("Skipping as test is supported only for int, sysint, stage environments.");
        }
        Response response = DeviceControllerUtils.getDeviceDetailsWithKeyV1(qeDeviceNameWithSimInfo,
                "info.sim,info.capability,info.vpn");
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK, "Response code do not match");
        Map<String, Object> reportedObject = response.jsonPath().getMap("reportedInfo");
        List<Object> simInfoList = (List<java.lang.Object>) reportedObject.get("simInfo");
        softAssert.assertTrue(simInfoList.size() != 0, "Size of List must be greater than 0");
        softAssert.assertTrue(reportedObject.get("vpnInfo") != null, "vpnInfo should be present and with a value");
        softAssert.assertTrue(reportedObject.get("capability") != null,
                "capability should be present and with a value");

        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get device  details using device name filter with keys as info.sim,info.capability,info.vpn", description = "Get device details using device name filter with keys as info.sim,info.capability,info.vpn and validate the status code as 200(OK)", preCondition = "System should have devices with keys")
    public void testDeviceFilterNameWithKeys()
    {
        if ( !this.isSupported )
        {
            throw new SkipException("Skipping as test is supported only for int, sysint, stage environments.");
        }
        Response response = DeviceControllerUtils.getDeviceDetailsWithNameKeyV1(qeDeviceNameWithSimInfo,
                "info.sim,info.capability,info.vpn");
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK, "Response code do not match");
        List<Map<String, Object>> objects = response.jsonPath().getList("$");
        for (Map<String, Object> responseObj : objects)
        {
            Map<String, Object> reportedObj = (Map<String, java.lang.Object>) responseObj.get("reportedInfo");
            List<Object> simInfoList = (List<java.lang.Object>) reportedObj.get("simInfo");
            softAssert.assertTrue(simInfoList.size() != 0, "Size of List must be greater than 0");
            softAssert.assertTrue(reportedObj.get("vpnInfo") != null, "vpnInfo should be present and with a value");
            softAssert.assertTrue(reportedObj.get("capability") != null,
                    "capability should be present and with a value");
            softAssert.assertAll();
        }

    }

    @Test(dependsOnMethods = "testBatchAddDevices")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Post request to add devices using csv and then delete request to delete devices in batch", description = "Post request to add devices using csv and then delete request to delete devices in batch and validate the status code as 202(ACCEPTED)", preCondition = "Devices should be added using CSV file")
    public void testAddDevicesFromCsvAndBatchDeleteDevices()
            throws JsonSyntaxException
    {
        // cleanup before adding devices
        DeviceControllerUtils.deleteDeviceV1("csv001");
        DeviceControllerUtils.deleteDeviceV1("csv002");
        DeviceControllerUtils.deleteDeviceV1("csv003");

        ClassLoader classLoader = DeviceControllerV1Test.class.getClassLoader();
        File file = new File(classLoader.getResource("device/batchAddDevice.csv").getFile());

        Response response = DeviceControllerUtils.addDevicesFromCsvV1("0", file.getAbsolutePath());
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_ACCEPTED, "Response code do not match");
        devices.addAll(Arrays.asList("csv001", "csv002", "csv003"));
        softAssert.assertAll();
    }

    @Test(dependsOnMethods = "testBatchAddDevices")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get device details with filter as device ID", description = "Get device details with filter as device id and validate the status code as 200(OK)", preCondition = "Devices should be added in the system")
    public void getDevicePathTest()
    {
        String deviceId = devicePojos.get(0).getDeviceId();
        Response response = DeviceControllerUtils.getDevicePathV1(deviceId);
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK, "Response codes do not match.");
        List<Object> paths = response.jsonPath().getList("$");
        softAssert.assertTrue(!paths.isEmpty(), "There must be items in the path");
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get device details with filter as invalid device ID", description = "Get device details with filter as invalid device id and validate the status code is not equal to 200(OK)", preCondition = "Devices should be added in the system")
    public void getDevicePath2()
    {
        String deviceId = "deviceId" + System.currentTimeMillis();
        Response response = DeviceControllerUtils.getDevicePathV1(deviceId);
        softAssert.assertTrue(response.statusCode() != HttpStatus.SC_OK, "Response code do not match");
        softAssert.assertTrue(response.asString().contains("Invalid"), "Response must contain Invalid");
        softAssert.assertAll();
    }

    @DataProvider
    public Object[][] HeadDeviceAgentTypeFilterData()
    {

        return new Object[][]
        {
                // scenario, filter for agentType, filter out agentType, response_code
                {
                        "Filter for EdgeAgent devices only", QEConstants.EDGE_AGENT, QEConstants.PREDIX_MACHINE,
                        HttpStatus.SC_NO_CONTENT
                },
                {
                        "Filter for PredixMachine devices only", QEConstants.PREDIX_MACHINE, QEConstants.EDGE_AGENT,
                        HttpStatus.SC_NO_CONTENT
                }

        };

    }

    @Test(dataProvider = "HeadDeviceAgentTypeFilterData")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get device details with filter as Agent Type", description = "Get device details with filter as Agent Type(Edge Agent and Predix Machine) and validate the status code as 204(NO CONTENT)", preCondition = "Devices should be added in the system")
    public void testGetDeviceHead(String scenario, String filterForType, String filterOutType, int responseCode)
    {
        _logger.info("\tRunning: " + scenario);

        String filter = "agentType eq \"" + filterForType + "\"";
        Response response = DeviceControllerUtils.getDevicesCountWithFilterV1(filter);

        softAssert.assertEquals(response.statusCode(), responseCode, "Response codes do not match.");
        softAssert.assertTrue(!response.body().toString().contains(filterOutType),
                "GET with filter did not filter out all " + filterOutType + " agentType.");

        softAssert.assertAll();
    }

    /* Test case for checking attribute for devices */
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get request for checking attributes for devices", description = "Get request for checking attributes(device id,city,state,country) for devices and validate the status code as 200(OK)", preCondition = "Devices should be added in the system")
    public void getDeviceAttributesTest()

    {
        Response response = DeviceControllerUtils.getDeviceAttributesV1();
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK, "Response codes do not match.");
        softAssert.assertTrue(response.asString().contains("device_id"), "Response must contain deviceId");
        softAssert.assertTrue(response.asString().contains("location.city"), "Response must contain location.city");
        softAssert.assertTrue(response.asString().contains("location.state"), "Response must contain location.state");
        softAssert.assertTrue(response.asString().contains("location.country"),
                "Response must contain location.country");
        softAssert.assertAll();
    }

    /**
     * Test case for checking Operation status for a single operation
     */
    @Test(dependsOnMethods = "testBatchAddDevices")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get request for checking Operation status for a single operation", description = "Get request for checking Operation status for a single operation and validate the status code as 200(OK)", preCondition = "Devices should be added in the system")
    public void getDeviceOperation()
    {
        Response response = DeviceOperationControllerUtils.getDeviceManagementOperationStatus(operationId);
        JsonPath jsonPath = response.jsonPath();
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK,
                "Status code for getDeviceManagementOperationStatus do not match");
        softAssert.assertEquals(jsonPath.getString("type"), "create", "Type for batchAddDevice do not match");
        softAssert.assertAll();
    }

    /**
     * Test case for checking capabilities for device
     *
     */
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get request for checking capabilities for device", description = "Get request for checking capabilities for device and validate the status code as 200(OK)", preCondition = "Devices should be added in the system")
    public void getDeviceCapabilitiesTest()
    {
        if ( qeDeviceName == null )
        {
            throw new SkipException("Skipping as QE device is not configured for this environment.");
        }

        Response response = DeviceControllerUtils.getDeviceCapabilitiesV1(qeDeviceName);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK, "Response code do not match");
        softAssert.assertTrue(response.jsonPath().getList("$").size() > 0, "Capabilities should be more than 0");
        softAssert.assertAll();
    }

    @Test(dependsOnMethods = "getDeviceCapabilitiesTest")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get request for checking capabilities status for device", description = "Get request for checking capabilities status for device and validate the status code as 200(OK)", preCondition = "Devices should be added in the system")
    private void getCapabilityStatusTest()
    {
        Set<String> capabilitiesWithNoStatus = new HashSet<>();
        capabilitiesWithNoStatus.add("predix.edge.eventlog");

        if ( qeDeviceName == null )
        {
            throw new SkipException("Skipping as QE device is not configured for this environment.");
        }

        Response response = DeviceControllerUtils.getDeviceCapabilitiesV1(qeDeviceName);
        JsonPath jsonPath = response.jsonPath();
        List<Map<String, Object>> deviceCapabilities = jsonPath.getList("$");
        softAssert.assertTrue(!deviceCapabilities.isEmpty(), "Device capabilities should be more than 0");
        if ( !deviceCapabilities.isEmpty() )
        {
            Map<String, Object> deviceCapabilityWithStatus = deviceCapabilities.stream()
                    .filter(deviceCapability -> capabilitiesWithNoStatus.stream()
                            .noneMatch(capabilityWithNoStatus -> deviceCapability.get("capabilityId").toString()
                                    .equals(capabilityWithNoStatus)))
                    .collect(Collectors.toList()).get(0);
            response = DeviceControllerUtils.getDeviceCapabilityStatusV1(qeDeviceName,
                    deviceCapabilityWithStatus.get("capabilityId").toString(),
                    deviceCapabilityWithStatus.get("version").toString(),
                    deviceCapabilityWithStatus.get("handler").toString());
            softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK, "Response code do not match");
            softAssert.assertTrue(!response.body().toString().contains("capabilityVersion"),
                    "The response payload must contain capabilityVersion");
        }
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get request with device filter as keys as model,groupPath,customAttributes", description = "Get request with device filter as keys as model,groupPath,customAttributes and validate the status code as 200(OK)", preCondition = "Devices should be added in the system")
    public void testDeviceFilterWithKeysModelGroupPathCustAttr()
            throws Exception
    {
        boolean isSupported = TestUtils.envSupportCheck(cfg);
        if ( !isSupported )
        {
            throw new SkipException("Skipping as test is supported only for int, sysint, stage environments.");
        }

        Response response = DeviceControllerUtils.getDeviceDetailsWithKeyV1(qePredixMachineDeviceWithKeysSetup,
                "model,groupPath,customAttributes");
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK,
                "status code is not matching for model,groupPath,customAttributes keys");

        Map<String, Object> deviceModel = response.jsonPath().getMap("deviceModel");
        softAssert.assertEquals(deviceModel.get("modelId"), "FieldAgent",
                "modelId value is not as expected for model,groupPath,customAttributes keys");
        softAssert.assertEquals(deviceModel.get("capability"), "pm",
                "capability value is not as expected for model,groupPath,customAttributes keys");

        List<Map<String, Object>> grpPathList = response.jsonPath().getList("groupPath");
        if ( grpPathList.size() > 0 )
        {
            Map<String, Object> groupPath = grpPathList.get(0);
            softAssert.assertNotNull(groupPath.get("name"), "Name attribute of GroupPath is Null");
            softAssert.assertNotNull(groupPath.get("isOpenable"), "isOpenable attribute of GroupPath is Null");
        }
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get request with device filter as keys as Info,Status,Capabilities", description = "Get request with device filter as keys as Info,Status,Capabilities and validate the status code as 200(OK)", preCondition = "Devices should be added in the system")
    public void testDeviceFilterWithKeysInfoStatusCapabilities()
            throws Exception
    {
        boolean isSupported = TestUtils.envSupportCheck(cfg);
        if ( !isSupported )
        {
            throw new SkipException("Skipping as test is supported only for int, sysint, stage environments.");
        }

        Response response = DeviceControllerUtils.getDeviceDetailsWithKeyV1(qePredixMachineDeviceWithKeysSetup,
                "info,status,capabilities");
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK,
                "status code is not matching for info,status,capabilities keys");

        Map<String, Object> reportedInfo = response.jsonPath().getMap("reportedInfo");
        /*
         * in below test cases for keys, i have commeneted few lines as those keys data are not displaying, looks like hardware info is not configured with device so
         * data are not displaying,
         */
        // List<Map<String, Object>> hardwareInfos = (List<Map<String, Object>>) reportedInfo.get("hardwareInfo");
        List<Map<String, Object>> simInfos = (List<Map<String, Object>>) reportedInfo.get("simInfo");
        Map<String, Object> capabilityInfos = (Map<String, Object>) reportedInfo.get("capability");
        Map<String, Object> machineInfos = (Map<String, Object>) reportedInfo.get("machineInfo");
        Map<String, Object> agentInfos = (Map<String, Object>) reportedInfo.get("agentInfo");

        softAssert.assertNotNull(reportedInfo, "ReportedInfo is Null");

        if ( reportedInfo.size() > 0 )
        {
            softAssert.assertNotNull(simInfos, "SimInfo attribute of ReportedInfo is Null");
            softAssert.assertNotNull(capabilityInfos, "capabilityInfos attribute of ReportedInfo is Null");

            softAssert.assertNotNull(machineInfos, "machineInfos attribute of ReportedInfo is Null");
            softAssert.assertNotNull(agentInfos, "agentInfos attribute of ReportedInfo is Null");

            /*
             * in below test cases for keys, i have commeneted few lines as those keys data are not displaying, looks like hardware info is not configured with device so
             * data are not displaying,
             */
            // Map<String, Object> hwInfo = hardwareInfos.get(0);
            // softAssert.assertEquals(hwInfo.get("category"),"device");

            softAssert.assertNotNull(agentInfos.get("agentType"), "agentType attribute of agentInfos is Null");
            softAssert.assertNotNull(capabilityInfos.get("COMMAND"), "COMMAND attribute of capabilityInfos is Null");

        }
        Map<String, Object> reportedStatus = response.jsonPath().getMap("reportedStatus");
        if ( reportedStatus.size() > 0 )
        {

            List<Map<String, Object>> powerSupplyStatus = (List<Map<String, Object>>) reportedStatus
                    .get("powerSupplyStatus");
            softAssert.assertTrue(powerSupplyStatus.size() > 0, "powerSupplyStatus size is zero");

            Map<String, Object> dynamicStatus = (Map<String, Object>) reportedStatus.get("dynamicStatus");
            softAssert.assertTrue(dynamicStatus.size() > 0, "dynamicStatus size is zero");

            List<Map<String, Object>> cellularStatus = (List<Map<String, Object>>) reportedStatus.get("cellularStatus");
            softAssert.assertTrue(cellularStatus.size() > 0, "cellularStatus size is zero");
        }

        softAssert.assertAll();

    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get request with device filter as keys as info.machine,info.hardware,info.deviceProperties", description = "Get request with device filter as keys as info.machine,info.hardware,info.deviceProperties and validate the status code as 200(OK)", preCondition = "Devices should be added in the system")
    public void testDeviceFilterWithKeysMachineHardwareDevicePro()
            throws Exception
    {
        boolean isSupported = TestUtils.envSupportCheck(cfg);
        if ( !isSupported )
        {
            throw new SkipException("Skipping as test is supported only for int, sysint, stage environments.");
        }

        Response response = DeviceControllerUtils.getDeviceDetailsWithKeyV1(qePredixMachineDeviceWithKeysSetup,
                "info.machine,info.hardware,info.deviceProperties");
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK,
                "status code is not matching for info.machine,info.hardware,info.deviceProperties keys");

        Map<String, Object> reportedInfo = response.jsonPath().getMap("reportedInfo");

        /*
         * in below test cases for keys, i have commeneted few lines as those keys data are not displaying, looks like hardware info is not configured with device so
         * data are not displaying,
         */

        // List<Map<String, Object>> hardwareInfos = (List<Map<String, Object>>) reportedInfo.get("hardwareInfo");
        Map<String, Object> machineInfos = (Map<String, Object>) reportedInfo.get("machineInfo");

        softAssert.assertNotNull(reportedInfo, "reportedInfo is Null");
        softAssert.assertTrue(reportedInfo.size() > 0, "reportinfo size is zero");

        /*
         * in below test cases for keys, i have commeneted few lines as those keys data are not displaying, looks like hardware info is not configured with device so
         * data are not displaying,
         */

        // softAssert.assertNotNull(hardwareInfos,"hardwareInfos attribute of reportedInfo is Null");
        // softAssert.assertTrue(hardwareInfos != null,"hardwareInfos attribute of reportedInfo is Null");
        // softAssert.assertTrue(hardwareInfos.size() != 0,"hardwareInfos attribute of reportedInfo size is zero");

        softAssert.assertNotNull(machineInfos, "machineInfos attribute of reportedInfo is Null");
        softAssert.assertTrue(machineInfos.size() > 0, "machineInfos attribute of reportedInfo size is zero");

        /*
         * in below test cases for keys, i have commeneted few lines as those keys data are not displaying, looks like hardware info is not configured with device so
         * data are not displaying,
         */

        // Map<String, Object> hwInfo = hardwareInfos.get(0);
        // softAssert.assertEquals(hwInfo.get("category"),"device");

        // Map<String, Object> hw_PropertiesInfo = (Map<String, Object>) hwInfo.get("properties");
        // softAssert.assertTrue(hw_PropertiesInfo.size() != 0,"hardwareInfos attribute of reportedInfo size is Null");

        // Map<String, Object> hw_AttributesInfo = (Map<String, Object>) hwInfo.get("attributes");
        // Map<String, Object> hw_SeriolNoInfo = (Map<String, Object>) hw_AttributesInfo.get("serialNumber");
        // softAssert.assertEquals(hw_SeriolNoInfo.get("value"),"2102351HND10H6000126");
        // Map<String, Object> hw_bootTimeInfo = (Map<String, Object>) hw_AttributesInfo.get("bootTime");
        // Map<String, Object> hw_bootMethodInfo = (Map<String, Object>) hw_AttributesInfo.get("bootMethod");

        // softAssert.assertNotNull(hw_bootTimeInfo,"hw_bootTimeInfo attribute value is Null");
        // softAssert.assertTrue(hw_bootTimeInfo != null,"hw_bootTimeInfo attribute value is Null");
        // softAssert.assertTrue(hw_bootTimeInfo.size() != 0,"hw_bootTimeInfo attribute size is zero");

        // softAssert.assertNotNull(hw_bootMethodInfo,"hw_bootMethodInfo attribute value is Null");
        // softAssert.assertTrue(hw_bootMethodInfo != null,"hw_bootMethodInfo attribute value is Null");
        // softAssert.assertTrue(hw_bootMethodInfo.size() != 0,"hw_bootMethodInfo attribute size is Null");

        List<Map<String, Object>> bundleInfos = (List<Map<String, Object>>) machineInfos.get("bundle");
        Map<String, Object> osInfos = (Map<String, Object>) machineInfos.get("osInfo");

        softAssert.assertNotNull(bundleInfos, "bundleInfos attribute size is Null");
        softAssert.assertTrue(bundleInfos.size() > 0, "bundleInfos attribute size is zero");

        softAssert.assertNotNull(osInfos, "osInfos attribute size is Null");
        softAssert.assertTrue(osInfos.size() > 0, "osInfos attribute size is zero");

        softAssert.assertNotNull(machineInfos.get("javaVersion"), "javaVersion attribute value is Null");
        softAssert.assertNotNull(osInfos.get("osName"), "osName attribute value is Null");

        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get request with device filter as keys as info.properties,info.agent,status.powerSupply", description = "Get request with device filter as keys as info.properties,info.agent,status.powerSupply and validate the status code as 200(OK)", preCondition = "Devices should be added in the system")
    public void testDeviceFilterWithKeysPropertiesAgentPowerSupply()
            throws Exception
    {
        boolean isSupported = TestUtils.envSupportCheck(cfg);
        if ( !isSupported )
        {
            throw new SkipException("Skipping as test is supported only for int, sysint, stage environments.");
        }

        Response response = DeviceControllerUtils.getDeviceDetailsWithKeyV1(qePredixMachineDeviceWithKeysSetup,
                "info.properties,info.agent,status.powerSupply");
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK,
                "status code is not matching for info.properties,info.agent,status.powerSupply keys");

        Map<String, Object> reportedInfo = response.jsonPath().getMap("reportedInfo");

        Map<String, Object> AgentInfoInfos = (Map<String, Object>) reportedInfo.get("agentInfo");

        softAssert.assertTrue(reportedInfo != null, "reportedInfo attribute value is Null");
        softAssert.assertTrue(reportedInfo.size() > 0, "reportedInfo attribute size is zero");

        softAssert.assertNotNull(AgentInfoInfos.get("agentType"), "agentType attribute value is Null");

        Map<String, Object> reportedStatusInfo = response.jsonPath().getMap("reportedStatus");

        List<Map<String, Object>> powersupplyInfos = (List<Map<String, Object>>) reportedStatusInfo
                .get("powerSupplyStatus");

        softAssert.assertNotNull(powersupplyInfos, "powersupplyInfos attribute value is Null");
        softAssert.assertTrue(powersupplyInfos.size() > 0, "powersupplyInfos attribute size is Null");

        Map<String, Object> typeInfos = (Map<String, Object>) powersupplyInfos.get(0);

        softAssert.assertNotNull(typeInfos.get("type"), "type attribute value is Null");
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get request with device filter as keys as status.dynamic,status.bluetooth,status.wifi", description = "Get request with device filter as keys as status.dynamic,status.bluetooth,status.wifi and validate the status code as 200(OK)", preCondition = "Devices should be added in the system")
    public void testDeviceFilterWithKeysDynamicBluetoothWifi()
            throws Exception
    {
        boolean isSupported = TestUtils.envSupportCheck(cfg);
        if ( !isSupported )
        {
            throw new SkipException("Skipping as test is supported only for int, sysint, stage environments.");
        }

        Response response = DeviceControllerUtils.getDeviceDetailsWithKeyV1(qePredixMachineDeviceWithKeysSetup,
                "status.dynamic,status.bluetooth,status.wifi");
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK,
                "status code is not matching for status.dynamic,status.bluetooth,status.wifi keys");

        Map<String, Object> reportedInfo = response.jsonPath().getMap("reportedStatus");

        Map<String, Object> dynamicStatusInfos = (Map<String, Object>) reportedInfo.get("dynamicStatus");

        Map<String, Object> cpuStatusInfos = (Map<String, Object>) dynamicStatusInfos.get("cpuStatus");

        Map<String, Object> memoryStatusInfos = (Map<String, Object>) dynamicStatusInfos.get("memoryStatus");

        List<Map<String, Object>> diskStatusInfos = (List<Map<String, Object>>) dynamicStatusInfos.get("diskStatus");

        List<Map<String, Object>> networkStatusInfos = (List<Map<String, Object>>) dynamicStatusInfos
                .get("networkStatus");

        softAssert.assertNotNull(reportedInfo, "reportedInfo attribute value is Null");
        softAssert.assertTrue(reportedInfo.size() > 0, "reportedInfo attribute size is Null");

        softAssert.assertNotNull(dynamicStatusInfos, "dynamicStatusInfos attribute value is Null");
        softAssert.assertTrue(dynamicStatusInfos.size() > 0, "dynamicStatusInfos attribute size is Null");

        softAssert.assertNotNull(cpuStatusInfos, "cpuStatusInfos attribute value is Null");
        softAssert.assertTrue(cpuStatusInfos.size() > 0, "cpuStatusInfos attribute size is Null");

        softAssert.assertNotNull(memoryStatusInfos, "memoryStatusInfos attribute value is Null");
        softAssert.assertTrue(memoryStatusInfos.size() > 0, "memoryStatusInfos attribute size is Null");

        softAssert.assertNotNull(diskStatusInfos, "diskStatusInfos attribute value is Null");
        softAssert.assertTrue(diskStatusInfos.size() > 0, "diskStatusInfos attribute size is Null");

        softAssert.assertNotNull(networkStatusInfos, "networkStatusInfos attribute value is Null");
        softAssert.assertTrue(networkStatusInfos.size() > 0, "networkStatusInfos attribute size is Null");

        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get request with device filter as keys as status.cellular,info.machine.bundle,info.machine.service", description = "Get request with device filter as keys as status.cellular,info.machine.bundle,info.machine.service and validate the status code as 200(OK)", preCondition = "Devices should be added in the system")
    public void testDeviceFilterWithKeysCellularBundleService()
            throws Exception
    {
        boolean isSupported = TestUtils.envSupportCheck(cfg);
        if ( !isSupported )
        {
            throw new SkipException("Skipping as test is supported only for int, sysint, stage environments.");
        }

        Response response = DeviceControllerUtils.getDeviceDetailsWithKeyV1(qePredixMachineDeviceWithKeysSetup,
                "status.cellular,info.machine.bundle,info.machine.service");
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK,
                "status code is not matching for status.cellular,info.machine.bundle,info.machine.service keys");

        Map<String, Object> reportedInfo = response.jsonPath().getMap("reportedInfo");

        Map<String, Object> machineInfos = (Map<String, Object>) reportedInfo.get("machineInfo");
        softAssert.assertEquals(machineInfos.get("javaVendor"), "Oracle Corporation");

        List<Map<String, Object>> bundleInfos = (List<Map<String, Object>>) machineInfos.get("bundle");

        softAssert.assertNotNull(reportedInfo, "reportedInfo attribute value is Null");
        softAssert.assertTrue(reportedInfo.size() > 0, "reportedInfo attribute size is Null");

        softAssert.assertNotNull(machineInfos, "machineInfos attribute value is Null");
        softAssert.assertTrue(machineInfos.size() > 0, "machineInfos attribute size is Null");

        softAssert.assertNotNull(bundleInfos, "bundleInfos attribute value is Null");
        softAssert.assertTrue(bundleInfos.size() > 0, "bundleInfos attribute size is Null");

        Map<String, Object> reportedStatusInfo = response.jsonPath().getMap("reportedStatus");
        softAssert.assertNotNull(reportedStatusInfo, "reportedStatusInfo attribute value is Null");
        softAssert.assertTrue(reportedStatusInfo.size() > 0, "reportedStatusInfo attribute size is Null");
        List<Map<String, Object>> cellularInfos = (List<Map<String, Object>>) reportedStatusInfo.get("cellularStatus");
        Map<String, Object> cellularInfos1 = cellularInfos.get(0);
        softAssert.assertNotNull(cellularInfos1, "cellularInfos attribute value is Null");
        softAssert.assertTrue(cellularInfos1.size() > 0, "cellularInfos attribute size is Null");
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get request with device filter as keys as info.machine.os,status.dynamic.cpu,status.dynamic.memory", description = "Get request with device filter as keys as info.machine.os,status.dynamic.cpu,status.dynamic.memory and validate the status code as 200(OK)", preCondition = "Devices should be added in the system")
    public void testDeviceFilterWithKeysOSCPUMemory()
            throws Exception
    {
        boolean isSupported = TestUtils.envSupportCheck(cfg);
        if ( !isSupported )
        {
            throw new SkipException("Skipping as test is supported only for int, sysint, stage environments.");
        }

        Response response = DeviceControllerUtils.getDeviceDetailsWithKeyV1(qePredixMachineDeviceWithKeysSetup,
                "info.machine.os,status.dynamic.cpu,status.dynamic.memory");
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK,
                "status code is not matching for info.machine.os,status.dynamic.cpu,status.dynamic.memory keys");

        Map<String, Object> reportedInfo = response.jsonPath().getMap("reportedInfo");

        Map<String, Object> machineInfos = (Map<String, Object>) reportedInfo.get("machineInfo");

        Map<String, Object> osInfos = (Map<String, Object>) machineInfos.get("osInfo");

        softAssert.assertNotNull(osInfos.get("osName"), "osName attribute value is Null");

        softAssert.assertNotNull(reportedInfo, "reportedInfo attribute value is Null");
        softAssert.assertTrue(reportedInfo.size() > 0, "reportedInfo attribute size is Null");

        softAssert.assertNotNull(machineInfos, "machineInfos attribute value is Null");
        softAssert.assertTrue(machineInfos.size() > 0, "machineInfos attribute size is Null");

        softAssert.assertNotNull(osInfos, "osInfos attribute value is Null");
        softAssert.assertTrue(osInfos.size() > 0, "osInfos attribute size is Null");

        Map<String, Object> reportedStatusInfo = response.jsonPath().getMap("reportedStatus");
        softAssert.assertNotNull(reportedStatusInfo, "reportedStatusInfo attribute value is Null");
        softAssert.assertTrue(reportedStatusInfo.size() > 0, "reportedStatusInfo attribute size is Null");
        Map<String, Object> dynamicStatusInfo = (Map<String, Object>) reportedStatusInfo.get("dynamicStatus");
        Map<String, Object> cpuStatusInfo = (Map<String, Object>) dynamicStatusInfo.get("cpuStatus");
        Map<String, Object> memoryStatusInfo = (Map<String, Object>) dynamicStatusInfo.get("memoryStatus");

        softAssert.assertNotNull(dynamicStatusInfo, "dynamicStatusInfo attribute value is Null");
        softAssert.assertTrue(dynamicStatusInfo.size() > 0, "dynamicStatusInfo attribute size is Null");

        softAssert.assertNotNull(cpuStatusInfo, "cpuStatusInfo attribute value is Null");
        softAssert.assertTrue(cpuStatusInfo.size() > 0, "cpuStatusInfo attribute size is Null");

        softAssert.assertNotNull(memoryStatusInfo, "memoryStatusInfo attribute value is Null");
        softAssert.assertTrue(memoryStatusInfo.size() > 0, "memoryStatusInfo attribute size is Null");
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get request with device filter as keys as status.dynamic.disk,status.dynamic.network", description = "Get request with device filter as keys as status.dynamic.disk,status.dynamic.network and validate the status code as 200(OK)", preCondition = "Devices should be added in the system")
    public void testDeviceFilterWithKeysDiskNetwork()

            throws Exception
    {
        boolean isSupported = TestUtils.envSupportCheck(cfg);
        if ( !isSupported )
        {
            throw new SkipException("Skipping as test is supported only for int, sysint, stage environments.");
        }

        Response response = DeviceControllerUtils.getDeviceDetailsWithKeyV1(qePredixMachineDeviceWithKeysSetup,
                "status.dynamic.disk,status.dynamic.network");

        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK,
                "status code is not matching for status.dynamic.disk,status.dynamic.network keys");

        Map<String, Object> reportedStatusInfo = response.jsonPath().getMap("reportedStatus");
        softAssert.assertNotNull(reportedStatusInfo, "reportedStatusInfo attribute value is Null");
        softAssert.assertTrue(reportedStatusInfo.size() > 0, "reportedStatusInfo attribute size is Null");
        Map<String, Object> dynamicStatusInfo = (Map<String, Object>) reportedStatusInfo.get("dynamicStatus");
        List<Map<String, Object>> diskstatusInfos = (List<Map<String, Object>>) dynamicStatusInfo.get("diskStatus");
        List<Map<String, Object>> networktatusInfos = (List<Map<String, Object>>) dynamicStatusInfo
                .get("networkStatus");

        softAssert.assertNotNull(dynamicStatusInfo, "dynamicStatusInfo attribute value is Null");
        softAssert.assertTrue(dynamicStatusInfo.size() > 0, "dynamicStatusInfo attribute size is Null");

        softAssert.assertNotNull(diskstatusInfos, "diskstatusInfos attribute value is Null");
        softAssert.assertTrue(diskstatusInfos.size() > 0, "diskstatusInfos attribute size is Null");

        softAssert.assertNotNull(networktatusInfos, "networktatusInfos attribute value is Null");
        softAssert.assertTrue(networktatusInfos.size() > 0, "networktatusInfos attribute size is Null");

        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get request to derive certificate status and certificate expiry date of a device", description = "Get request to derive certificate status and certificate expiry date of a device and validate the status code as 200(OK)", preCondition = "Devices should be added in the system and should be enrolled")
    public void testGetDeviceCertDetailsAfterEnrollment()
            throws Exception
    {
        String deviceId = "cert-expiry-device" + CommonUtils.getTimeStamp_HH_mm_ss_SSS_yyyy_MM_dd();
        devices.add(deviceId);
        // Add and enroll device
        CertEnrolledDeviceInfo deviceInfo = DeviceControllerUtils.addAndEnrollDevice(deviceId);
        softAssert.assertNotNull(deviceInfo);
        softAssert.assertNotNull(deviceInfo.getDeviceId());
        softAssert.assertEquals(deviceInfo.getDeviceId(), deviceId);

        // Get device details
        Response response = DeviceControllerUtils.getDeviceDetailsV1(deviceId);
        softAssert.assertNotNull(response);
        JsonPath jsonPath = response.jsonPath();
        softAssert.assertEquals(jsonPath.get("deviceId"), deviceId);
        softAssert.assertNotNull(jsonPath.get("certExpiry"));
        softAssert.assertNotNull(jsonPath.get("certStatus"));
        softAssert.assertTrue((Long) jsonPath.get("certExpiry") > Instant.now().toEpochMilli());
        softAssert.assertTrue(jsonPath.get("certStatus").toString().equalsIgnoreCase("Valid"));

        softAssert.assertAll();
    }

    @DataProvider
    public Object[][] getDeviceCertExpiryFilterData()
    {
        return new Object[][]
        {
                {
                        "Filter for CertificateExpirationDue greater than", "certificateExpirationDue gt \"10\"", 200
                }
        };
    }

    @Test(dataProvider = "getDeviceCertExpiryFilterData")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get request to derive devices using certificate expiration filters(Certificate Expiration Due and certificate expired)", description = "Get request to derive devices using certificate expiration filters(Certificate Expiration Due and certificate expired) and validate the status code as 200(OK)", preCondition = "Devices should be added in the system and should be enrolled")
    public void testGetDeviceWithCertExpirationFilter(String scenario, String filter, int responseCode)
    {
        _logger.info(String.format("\tRunning: %s", scenario));

        String deviceId = "cert-expiry-device" + CommonUtils.getTimeStamp_HH_mm_ss_SSS_yyyy_MM_dd();

        _logger.info(String.format("\t Device Id is: %s", deviceId));
        devices.add(deviceId);
        // Add and enroll device
        CertEnrolledDeviceInfo deviceInfo = DeviceControllerUtils.addAndEnrollDevice(deviceId);
        softAssert.assertNotNull(deviceInfo);
        softAssert.assertEquals(deviceInfo.getDeviceId(), deviceId);

        // Get Device Details
        Response response = DeviceControllerUtils
                .getDevicesWithFilterAndLimitV1(filter + "and device_id eq \"" + deviceId + "\"", 10);
        softAssert.assertEquals(response.statusCode(), responseCode, "Response codes do not match");
        List<Object> count = response.jsonPath().getList("$");
        softAssert.assertTrue(!count.isEmpty(), "Count of devices after applying filter:" + filter + ": should be > 0");
        softAssert.assertAll();
    }

    @AfterClass(alwaysRun = true)
    public static void cleanup()
    {
        devices.forEach(device -> DeviceControllerUtils.deleteDeviceV1(device));
        devicePojos.forEach(it -> DeviceControllerUtils.deleteDeviceV1(it.getName()));
        DeviceGroupControllerUtils.deleteGroup(groupId);

    }
}
