/*
 * Copyright (c) 2012 - 2018 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.emapi.utils;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.dspmicro.qe.tools.environment.Configuration;
import com.ge.dspmicro.qe.tools.utils.RestClient;
import com.ge.dspmicro.qe.tools.utils.Token;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.jayway.restassured.response.Response;

/**
 *
 * @author 212547153
 */
@SuppressWarnings(
{
        "nls", "javadoc"
})
public class CommandManagementControllerUtils
{
    static Configuration cfg                    = Configuration.getConfig();
    private static Token token                  = cfg.getAdminUAAToken();
    private static final Logger _logger         = LoggerFactory.getLogger(CommandManagementControllerUtils.class);

    public static String BASE_URI_COMMAND       = EmapiConstants.EM_API + EmapiConstants.EM_API_BETA_VERSION
            + "/command-management/commands";
    public static String BASE_URI_OPERATIONS    = EmapiConstants.EM_API + EmapiConstants.EM_API_BETA_VERSION
            + "/command-management/operations";
    public static String BASE_URI_TASKS         = EmapiConstants.EM_API + EmapiConstants.EM_API_BETA_VERSION
            + "/command-management/tasks";
    public static String BASE_URI_COMMAND_V1    = EmapiConstants.EM_API + EmapiConstants.EM_API_V1_VERSION
            + "/command-management/commands";
    public static String BASE_URI_OPERATIONS_V1 = EmapiConstants.EM_API + EmapiConstants.EM_API_V1_VERSION
            + "/command-management/operations";
    public static String BASE_URI_TASKS_V1      = EmapiConstants.EM_API + EmapiConstants.EM_API_V1_VERSION
            + "/command-management/tasks";

    // GET /emapi/v1/command-management/commands Get commands
    public static Response getCommandsV1()
    {
        Map<String, Object> params = new HashMap<>();
        params.put("limit", 200);
        params.put("offset", 0);
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_COMMAND_V1, params, token);
    }

    // GET /emapi/v1/command-management/commands Get commands
    public static Response getCommandWithDisplayNameV1(String displayName)
    {
        Map<String, Object> params = new HashMap<>();
        params.put("filter", "commandDisplayName eq \"" + displayName + "\"");
        params.put("limit", 200);
        params.put("offset", 0);
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_COMMAND_V1, params, token);
    }

    // GET /emapi/v1/command-management/commands Get commands with query parameters
    public static Response getCommandsV1(Map queryParams)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_COMMAND_V1, queryParams, token);
    }

    // POST /emapi/v1/command-management/commands Add a command
    public static Response addCommandV1(String payload)
    {
        return RestClient.post(cfg.getEdgeManagerUrl(), BASE_URI_COMMAND_V1, payload, token);
    }

    // POST /emapi/v1/command-management/commands/devices Send a command to a set of devices
    public static Response sendCommandV1(String commandId, String payload)
    {
        return RestClient.post(cfg.getEdgeManagerUrl(), BASE_URI_COMMAND_V1 + "/" + commandId + "/start", payload,
                token);
    }

    // GET /emapi/v1/command-management/commands/history/devices/{deviceId} Retrieve the command history
    public static Response getDeviceCommandHistoryV1(String deviceId)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_COMMAND_V1 + "/history/devices/" + deviceId, null,
                token);
    }

    // PATCH /emapi/v1/command-management/commands/{commandId} Modify a command by Id, currently only modify description
    public static Response modifyCommandByIdV1(String id, String payload)
    {
        return RestClient.patch(cfg.getEdgeManagerUrl(), BASE_URI_COMMAND_V1 + "/" + id, payload, token);
    }

    // DELETE /emapi/v1/command-management/commands/{commandId} Delete a command
    public static Response deleteCommandV1(String commandId)
    {
        return RestClient.delete(cfg.getEdgeManagerUrl(), BASE_URI_COMMAND_V1 + "/" + commandId, token);
    }

    // GET /emapi/v1/command-management/commands/{commandId} Retrieve a command by ID
    public static Response getCommandDetailByIdV1(String commandId)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_COMMAND_V1 + "/" + commandId, null, token);
    }

    // GET /emapi/v1/command-management/operations Get all command operation history
    public static Response getCommandOperationHistoryV1(String limit, String offset)
    {
        Map<String, Object> params = new HashMap<>();
        params.put("limit", limit);
        params.put("offset", offset);
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_OPERATIONS_V1, params, token);
    }

    // GET /emapi/v1/command-management/operations/{operationId} Get all command operation statuses
    public static Response getCommandOperationDetailV1(String operationId) throws InterruptedException
    {
        Response response= getOperationResponse(operationId);
        if(isBackoffRequired(response)){
            int numberOfBackoffAttemps=3;
            int currentAttempt=1;
            long backoffWaitDuration=5000;
            while(currentAttempt<=numberOfBackoffAttemps){
                _logger.info("Could not get any task from getCommandOperationDetail for operation id : {}, will be retrying in {} seconds", operationId,(backoffWaitDuration/1000));
                Thread.sleep(backoffWaitDuration);
                response = getOperationResponse(operationId);
                if(!isBackoffRequired(response)){
                    break;
                }else{
                    currentAttempt++;
                    backoffWaitDuration=backoffWaitDuration*4;
                }
            }
        }
        return response;
    }
    public static Response getOperationResponse(String operationId)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_OPERATIONS_V1 + "/" + operationId, null, token);
    }
    public static boolean isBackoffRequired(Response response)
    {
        if ( response.getStatusCode() == 200 && "[]".equals(response.jsonPath().getString("tasks")) )
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    // PATCH /emapi/v1/command-management/tasks Cancel command tasks that have not yet been executed on individual devices
    public static Response cancelTasksV1(String payload)
    {
        return RestClient.patch(cfg.getEdgeManagerUrl(), BASE_URI_TASKS_V1, payload, token);
    }

    // DELETE /emapi/v1/command-management/tasks/{taskId} Delete a command task by task ID
    public static Response deleteCommandTaskV1(String taskId)
    {
        return RestClient.delete(cfg.getEdgeManagerUrl(), BASE_URI_TASKS_V1 + "/" + taskId, token);
    }

    // GET /emapi/v1/command-management/tasks/{taskId} Get a command task by task ID
    public static Response getCommandTaskV1(String taskId)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_TASKS_V1 + "/" + taskId, null, token);
    }

    // GET /emapi/v1/command-management/tasks/{taskId}/output Get the output produced from the command task
    public static Response getCommandTaskOutputV1(String taskId)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_TASKS_V1 + "/" + taskId + "/output", null, token);
    }

    // PUT /emapi/v1/command-management/tasks/{taskId}/output Upload output files produced from the command
    public static Response uploadCommandOutputV1(String taskId, String fileName, String fileToUpload)
    {

        Map<String, Object> formParams = new HashMap<>();
        formParams.put("name", fileName);
        formParams.put("file", fileToUpload);
        return RestClient.putWithMultiPart(cfg.getEdgeManagerUrl(), BASE_URI_TASKS_V1 + "/" + taskId + "/output",
                fileName, token);

    }

    public static Map<String, Integer> getCommandIdMapV1()
    {
        Map<String, Integer> commandIdMap = new HashMap<>();
        Response response = getCommandsV1();
        List<HashMap<String, Object>> commandList = response.jsonPath().getList("$");

        for (HashMap<String, Object> command : commandList)
        {
            commandIdMap.put(command.get("command").toString(), Integer.parseInt((String) command.get("commandId")));
        }
        return commandIdMap;
    }

    public static Map<String, Integer> getCommandIdMap(String getCommandResponse)
    {
        Map<String, Integer> commandIdMap = new HashMap<>();
        Gson gson = new GsonBuilder().create();
        List<HashMap<String, Object>> commandList;
        Type type = new TypeToken<ArrayList<HashMap<String, Object>>>()
        {
            // empty block
        }.getType();
        commandList = gson.fromJson(getCommandResponse, type);

        for (HashMap<String, Object> command : commandList)
        {
            if ( command.containsKey("commandDisplayName") )
            {
                commandIdMap.put(command.get("commandDisplayName").toString(),
                        Integer.parseInt((String) command.get("commandId")));
            }
            else if ( command.containsKey("displayName") )
            {
                commandIdMap.put(command.get("displayName").toString(),
                        Integer.parseInt((String) command.get("commandId")));
            }
        }
        return commandIdMap;
    }

    public void setToken(Token token)
    {
        CommandManagementControllerUtils.token = token;
    }

    public Token getToken()
    {
        return CommandManagementControllerUtils.token;
    }
}
