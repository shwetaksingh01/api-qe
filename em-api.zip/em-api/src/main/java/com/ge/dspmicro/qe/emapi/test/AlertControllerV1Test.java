/*
 * Copyright (c) 2019 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.emapi.test;

import com.ge.dspmicro.qe.emapi.utils.AlertManagementControllerUtils;
import com.ge.dspmicro.qe.emapi.utils.TestUtils;
import com.ge.dspmicro.qe.tools.BaseTest;
import com.ge.dspmicro.qe.tools.testng.TestListener;
import com.ge.predix.edgemanager.qe.annotations.JiraTestCaseInfo;
import com.jayway.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.assertj.core.api.SoftAssertions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.SkipException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.ge.dspmicro.qe.emapi.utils.AlertManagementControllerUtils.*;
import static com.ge.dspmicro.qe.emapi.utils.AlertThresholdControllerUtils.*;

/**
 *
 * @author 212547153
 */
@SuppressWarnings(
{
        "javadoc", "nls"
})
@Listeners(TestListener.class)
public class AlertControllerV1Test extends BaseTest
{

    private static final Logger _logger                 = LoggerFactory.getLogger(AlertControllerV1Test.class);
    private static String       testDevice;
    private static String       testDeviceFilterDevice;

    private static final String THRESHOLD_NAME          = "qe-" + System.currentTimeMillis();
    private static final String THRESHOLD_DESCRIPTION   = "qe validation";
    private static final String THRESHOLD_SEVERITY      = "info";
    private static final String THRESHOLD_TIMEINSECONDS = "315";
    private static final String THRESHOLD_DISPLAYUNIT   = "days";

    @BeforeClass
    public void setup()
    {
        testDevice = cfg.getQeHTCDeviceName();
        testDeviceFilterDevice = cfg.getQePMDeviceName();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get Alerts without applying any Alert Filter", description = "User can view the list of alerts without applying any filter on Alerts page", preCondition = "System should have some pre-existing Alerts")
    public void testGetAlertsWithNoFilter()
    {
        SoftAssertions softly = new SoftAssertions();
        Map<String, Object> qMap = new HashMap<>();
        qMap.put("limit", 1);
        qMap.put("offset", 0);
        Response response = getAlertsV1(qMap);
        softly.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_OK);
        List<Map<String, Object>> alerts = response.jsonPath().getList("$");
        softly.assertThat(alerts.size()).isEqualTo(1);
        if (alerts.size() > 0)
        {
            alerts.forEach((n) -> System.out.println(alerts));
            softly.assertThat(alerts.get(0).get("alertId")).isNotNull();
            softly.assertThat(alerts.get(0).get("deviceId")).isNotNull();
            softly.assertThat(alerts.get(0).get("alertType")).isNotNull();
            softly.assertThat(alerts.get(0).get("sourceType")).isNotNull();
            softly.assertThat(alerts.get(0).get("source")).isNotNull();

            softly.assertThat(alerts.get(0).get("severity")).isNotNull();
            softly.assertThat(alerts.get(0).get("triggered")).isNotNull();
            softly.assertThat(alerts.get(0).get("status")).isNotNull();
            softly.assertThat(alerts.get(0).get("lastUpdated")).isNotNull();
            softly.assertThat(alerts.get(0).get("lastUpdatedBy")).isNotNull();
            if ( alerts.get(0).get("sourceType") != null && alerts.get(0).get("sourceType").equals("openvpn") )
            {
                // openvpn alerts do not have a description
            }
            else
            {
                softly.assertThat(alerts.get(0).get("description")).isNotNull();
            }
        }
        softly.assertAll();

    }

    @DataProvider
    public Object[][] alertFilterDataProvider()
    {
        return new Object[][]
        {
                // scenario, limit, offset, filter, contain, sortBy, sortOrder,deviceFilter, expectedStatusCode, expectedSourceType,
                // expectedServerity,expectedAlertStatus, expectedAlertType, envSpecificZeroOrMoreAlerts
                {
                        "GetAlerts with Filter sourceType eq \"device\" and severity eq \"critical\"", 1, 0,
                        "sourceType eq \"device\" and severity eq \"critical\"", testDeviceFilterDevice, "", "", "",
                        HttpStatus.SC_OK, "device", "critical", "", "", false
                },
                {
                        "GetAlerts with Filter sourceType eq \"device\" and severity eq \"error\"", 1, 0,
                        "sourceType eq \"device\" and severity eq \"error\"", "", "", "", "", HttpStatus.SC_OK,
                        "device", "error", "", "", true
                },
                {
                        "GetAlerts with Filter sourceType eq \"device\" and severity eq \"warning\"", 1, 0,
                        "sourceType eq \"device\" and severity eq \"warning\"", "", "", "", "", HttpStatus.SC_OK,
                        "device", "warning", "", "", false
                },
                {
                        "GetAlerts with Filter sourceType eq \"device\" and severity eq \"info\"", 1, 0,
                        "sourceType eq \"device\" and severity eq \"info\"", "", "", "", "", HttpStatus.SC_OK,
                        "device", "info", "", "", true
                },
                {
                        "GetAlerts with Device Filter status eq \"open\" and deviceFilter: model_id eq \"FieldAgent\"",
                        5, 0, "status eq \"open\"", "", "triggered", "desc", "model_id eq \"FieldAgent\"",
                        HttpStatus.SC_OK, "", "", "open", "", false
                },
                {
                        "GetAlerts with invalid sort order", 5, 0, "status eq \"open\"", "", "triggered_timestamp",
                        "desc", "model_id eq \"FieldAgent\"", HttpStatus.SC_BAD_REQUEST, "", "", "", "", false
                },
                {
                        "GetAlerts with Filter status eq \"acknowledged\" and alert_type eq \"device-online-offline\"",
                        1, 0, "status eq \"acknowledged\" and alert_type eq \"device-online-offline\"", "", "", "", "",
                        HttpStatus.SC_OK, "", "", "acknowledged", "device-online-offline", true
                },
                {
                        "GetAlerts with Filter status eq \"closed\" and alert_type eq \"device-online-offline\"", 1, 0,
                        "status eq \"closed\" and alert_type eq \"device-online-offline\"", "", "", "", "",
                        HttpStatus.SC_OK, "", "", "closed", "device-online-offline", false
                },
                {
                        "GetAlerts with Filter sourceType eq \"device\" and alertType eq \"device-online-offline\"", 1,
                        0, "sourceType eq \"device\" and alertType eq \"device-online-offline\"", "", "", "", "",
                        HttpStatus.SC_OK, "device", "", "", "device-online-offline", false
                }
        };

    }

    @Test(dataProvider = "alertFilterDataProvider")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get Alerts without applying any Alert Filter", description = "User can view the list of alerts without applying any filter on Alerts page", preCondition = "System should have some pre-existing Alerts")
    public void testGetAlertsScenarios(String scenario, int limit, int offset, String filter, String contain,
            String sortBy, String sortOrder, String deviceFilter, int expectedStatusCode, String expectedSourceType,
            String expectedServerity, String expectedAlertStatus, String expectedAlertType,
            boolean envSpecificZeroOrMoreAlerts)
    {
        _logger.info(String.format("\tRunning: %s", scenario));
        SoftAssertions softly = new SoftAssertions();
        Map<String, Object> qMap = new HashMap<>();
        qMap.put("limit", limit);
        qMap.put("offset", offset);
        if ( !filter.equals("") )
        {
            qMap.put("filter", filter);
        }
        if ( !contain.equals("") )
        {
            qMap.put("contains", contain);
        }
        if ( !sortBy.equals("") )
        {
            qMap.put("sort", sortBy);
        }
        if ( !sortOrder.equals("") )
        {
            qMap.put("order", sortOrder);
        }
        if ( !deviceFilter.equals("") )
        {
            qMap.put("deviceFilter", deviceFilter);
        }

        Response response = getAlertsV1(qMap);
        softly.assertThat(response.getStatusCode()).isEqualTo(expectedStatusCode);
        if ( response.getStatusCode() == HttpStatus.SC_OK )
        {
            List<Map<String, Object>> alerts = response.jsonPath().getList("$");
            if (envSpecificZeroOrMoreAlerts)
            {
                softly.assertThat(alerts.size()).isLessThanOrEqualTo(limit);
            }
            else
            {
                softly.assertThat(alerts.size()).isEqualTo(limit);
                softly.assertThat(alerts.get(0).get("alertId")).isNotNull();
                softly.assertThat(alerts.get(0).get("source")).isNotNull();
                if ( alerts.get(0).get("sourceType") != null && alerts.get(0).get("sourceType").equals("openvpn") )
                {
                    // openvpn alerts do not have a description
                }
                else
                {
                    softly.assertThat(alerts.get(0).get("description")).isNotNull();
                }
                softly.assertThat(alerts.get(0).get("deviceId")).isNotNull();
                softly.assertThat(alerts.get(0).get("triggered")).isNotNull();
                softly.assertThat(alerts.get(0).get("lastUpdated")).isNotNull();
                softly.assertThat(alerts.get(0).get("lastUpdatedBy")).isNotNull();
                if ( !expectedSourceType.equals("") )
                {
                    softly.assertThat(alerts.get(0).get("sourceType")).isEqualTo(expectedSourceType);
                }
                if ( !expectedServerity.equals("") )
                {
                    softly.assertThat(alerts.get(0).get("severity")).isEqualTo(expectedServerity);
                }

                if ( !expectedAlertStatus.equals("") )
                {
                    softly.assertThat(alerts.get(0).get("status")).isEqualTo(expectedAlertStatus);
                }
                if ( !expectedAlertType.equals("") )
                {
                    softly.assertThat(alerts.get(0).get("alertType")).isEqualTo(expectedAlertType);
                }
            }
        }
        softly.assertAll();

    }

    @DataProvider
    public Object[][] updateAlertsDataProvider()
    {
        // scenario, payload, expectedStatusCode
        return new Object[][]
        {

                {
                        "Update alert test with action=ACKNOWLEDGE and id=577200 should return a 200 even if alert id does not exist",
                        "[{\"action\": \"ACKNOWLEDGE\",\"alertId\": 577200}]", HttpStatus.SC_OK
                },
                {
                        "Update alert with a single entry should fail to parse JSON",
                        "{\"action\": \"ACKNOWLEDGE\",\"id\": 413}", HttpStatus.SC_BAD_REQUEST
                },
                {
                        "Update alert with invalid payload shoul dfail to parse JSON", "skldfjlskjdf",
                        HttpStatus.SC_BAD_REQUEST
                },

        };

    }


    @Test(dataProvider = "updateAlertsDataProvider")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Update the Alert filter", description = "User should be able to update the Alert and get the updated list of Alerts", preCondition = "System should have some pre-existing Alerts")
    public void testUpdateAlertsScenarios(String scenarios, String payload, int expectedStatusCode)
    {
        _logger.info("\tRunning scenario: " + scenarios);
        SoftAssertions softly = new SoftAssertions();
        Response response = updateAlertsV1(payload);
        softly.assertThat(response.getStatusCode()).isEqualTo(expectedStatusCode);
        softly.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get Alert Count", description = "User should be able to validate the number of Alerts", preCondition = "System should have some pre-existing Alerts")
    public void testGetNumberOfAlerts()

   {
        SoftAssertions softly = new SoftAssertions();
        Map<String, Object> qMap = new HashMap<>();
        qMap.put("limit", 1000);
        qMap.put("offset", 0);

        qMap.put("filter", "sourceType eq \"device\" and severity eq \"critical\"");

        Response response = getNumberOfAlertsV1(qMap);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_NO_CONTENT);
        softly.assertThat(Integer.parseInt(response.getHeaders().getValue("Total-Count"))).isGreaterThan(0);
        softly.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get 400 response code if the device id is invalid and severity as invalid", description = "User should be able to get 400 response code if the device id is invalid and severity as invalid", preCondition = "System should have some pre-existing Alerts")
    public void testGetNumberOfAlerts_400Error()

    {
        SoftAssertions softly = new SoftAssertions();
        Map<String, Object> qMap = new HashMap<>();
        qMap.put("limit", 1000);
        qMap.put("offset", 0);

        qMap.put("filter", "sourceType eq \"device_invalid\" and severity eq \"critical_invalid\"");

        Response response = getNumberOfAlertsV1(qMap);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_BAD_REQUEST);
        softly.assertAll();
    }


    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get the existing created Thresholds", description = "User should be able to get existing created Thresholds", preCondition = "System should have some pre-existing Alerts")
    public void verifyExistingCreatedThresholds()

    {
        boolean isSupported = TestUtils.envSupportCheck(cfg);
        if ( !isSupported )
        {
            throw new SkipException("Skipping as test is supported only for int, sysint, stage environments.");
        }
        SoftAssertions softly = new SoftAssertions();
        Response response = getThresholds();
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_OK);
        List<Map<String, Object>> alerts = response.jsonPath().getList("$");
        softly.assertThat(alerts.get(0).get("name")).isNotNull();
        softly.assertThat(alerts.get(0).get("rule")).isNotNull();
        softly.assertThat(alerts.get(0).get("deviceCount")).isNotNull();
        softly.assertAll();

    }

    // this will assign threshold to device, unassign and again assign #TC-2
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Assign threshold to device, unassign and again assign", description = "User should be able to assign threshold to device, unassign and again assign", preCondition = "System should have some pre-existing Alerts")
    public void assignThresholds_UnassignThreshold()
    {
        boolean isSupported = TestUtils.envSupportCheck(cfg);
        if ( !isSupported )
        {
            throw new SkipException("Skipping as test is supported only for int, sysint, stage environments.");
        }
        SoftAssertions softly = new SoftAssertions();
        createAlertThresholds(THRESHOLD_NAME);
        String payload = "{\"type\": \"device-online-offline\",\"deviceFilter\": \"deviceId in \\\"deviceidname\\\"\"}";
        payload = payload.replace("deviceidname", testDevice);

        // assign
        Response response = assignThresholdToDevices(THRESHOLD_NAME, payload);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_ACCEPTED);

        // unassign
        response = unassignThresholdForDevice(payload);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_ACCEPTED);

        // assign
        response = assignThresholdToDevices(THRESHOLD_NAME, payload);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_ACCEPTED);

        response = deleteThreshold(THRESHOLD_NAME);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_NO_CONTENT);

        softly.assertAll();
    }

    // this will assign threshold to device - 400 & 404 status code,#TC-3
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Assign threshold to device,reassign with errored out payload to get 400 ,and assign with invalid payload to get 404", description = "User should be able different status codes while assigning thresholds to device", preCondition = "System should have some pre-existing Alerts")
    public void assignThresholds_400_404()
    {
        boolean isSupported = TestUtils.envSupportCheck(cfg);
        if ( !isSupported )
        {
            throw new SkipException("Skipping as test is supported only for int, sysint, stage environments.");
        }
        SoftAssertions softly = new SoftAssertions();
        createAlertThresholds(THRESHOLD_NAME);
        String payload = "{\"type\": \"device-online-offline\",\"deviceFilter\": \"deviceId in \\\"deviceidname\\\"\"}";
        String payload_400 = "{\"type\":: \"device-online-offline\",\"deviceFilter\": \"deviceId in \\\"deviceidname\\\"\"}";
        payload = payload.replace("deviceidname", testDevice);

        // assign
        Response response = assignThresholdToDevices(THRESHOLD_NAME, payload);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_ACCEPTED);
        // assign --400

        response = assignThresholdToDevices(THRESHOLD_NAME, payload_400);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_BAD_REQUEST);
        // assign --404

        response = assignThresholdToDevices(THRESHOLD_NAME + "invalid", payload);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_NOT_FOUND);

        response = deleteThreshold(THRESHOLD_NAME);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_NO_CONTENT);

        softly.assertAll();
    }

    // this will assign threshold to device, unassign and again assign - 400 and 404 #TC-4

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Assign threshold to device,unassign with valid payload to get 200,and Unassign with invalid payload to get 404", description = "User should be able different status codes while assigning thresholds to device", preCondition = "System should have some pre-existing Alerts")
    public void assignThresholds_UnassignThreshold_400And404()
    {
        boolean isSupported = TestUtils.envSupportCheck(cfg);
        if ( !isSupported )
        {
            throw new SkipException("Skipping as test is supported only for int, sysint, stage environments.");
        }
        SoftAssertions softly = new SoftAssertions();
        createAlertThresholds(THRESHOLD_NAME);
        String payload = "{\"type\": \"device-online-offline\",\"deviceFilter\": \"deviceId in \\\"deviceidname\\\"\"}";
        String payload_400 = "{\"type\":: \"device-online-offline\",\"deviceFilter\": \"deviceId in \\\"deviceidname\\\"\"}";
        payload = payload.replace("deviceidname", testDevice);

        // assign
        Response response = assignThresholdToDevices(THRESHOLD_NAME, payload);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_ACCEPTED);

        // unassign
        response = unassignThresholdForDevice(payload);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_ACCEPTED);

        // assign
        response = assignThresholdToDevices(THRESHOLD_NAME, payload);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_ACCEPTED);

        // unassign - 400

        response = unassignThresholdForDevice(payload_400);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_BAD_REQUEST);

        response = deleteThreshold(THRESHOLD_NAME);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_NO_CONTENT);

        softly.assertAll();

    }

    // this will retrieve all threshold of a device #TC-5
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Assign threshold to device,get all thresholds of the device", description = "User should able to assign thresholds for the device and get all thresholds of the device", preCondition = "System should have some pre-existing Alerts")
    public void retrieveThresholdsForDevice()
    {
        boolean isSupported = TestUtils.envSupportCheck(cfg);
        if ( !isSupported )
        {
            throw new SkipException("Skipping as test is supported only for int, sysint, stage environments.");
        }
        SoftAssertions softly = new SoftAssertions();
        createAlertThresholds(THRESHOLD_NAME);
        String payload = "{\"type\": \"device-online-offline\",\"deviceFilter\": \"deviceId in \\\"deviceidName\\\"\"}";
        payload = payload.replace("deviceidName", testDevice);

        Response response = assignThresholdToDevices(THRESHOLD_NAME, payload);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_ACCEPTED);

        response = getThresholdForDevice(testDevice);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_OK);

        response = deleteThreshold(THRESHOLD_NAME);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_NO_CONTENT);

        softly.assertAll();
    }

    // this will retrieve all threshold of a invalid device #TC-6
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Retrieve thresholds for invalid device and validate the statuscode", description = "User should able to Retrieve thresholds for invalid device and validate the status code as 404(SC_NOT_FOUND),", preCondition = "System should have some pre-existing Devices")
    public void retrieveThresholdsForInvalidDevice()
    {
        boolean isSupported = TestUtils.envSupportCheck(cfg);
        if ( !isSupported )
        {
            throw new SkipException("Skipping as test is supported only for int, sysint, stage environments.");
        }
        SoftAssertions softly = new SoftAssertions();
        createAlertThresholds(THRESHOLD_NAME);
        String payload = "{\"type\": \"device-online-offline\",\"deviceFilter\": \"deviceId in \\\"deviceidName\\\"\"}";
        payload = payload.replace("deviceidName", testDevice);

        Response response = assignThresholdToDevices(THRESHOLD_NAME, payload);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_ACCEPTED);

        response = getThresholdForDevice(testDevice + "test");
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_NOT_FOUND);

        response = deleteThreshold(THRESHOLD_NAME);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_NO_CONTENT);

        softly.assertAll();
    }

    // this will create a threshold and will delete it #TC-7
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Validate creation and deletion of threshold", description = "User should able to create and delete a threshold", preCondition = "System should have some pre-existing Device")
    public void deleteThresholds()
    {
        boolean isSupported = TestUtils.envSupportCheck(cfg);
        if ( !isSupported )
        {
            throw new SkipException("Skipping as test is supported only for int, sysint, stage environments.");
        }
        SoftAssertions softly = new SoftAssertions();
        createAlertThresholds(THRESHOLD_NAME);
        Response response = deleteThreshold(THRESHOLD_NAME);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_NO_CONTENT);
        softly.assertAll();
    }

    // this will create a threshold and will delete it with invalid threshold name #TC-8
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Validate deletion of threshold with invalid name", description = "User should able to create and delete a threshold", preCondition = "System should have some pre-existing Device")
    public void deleteThresholdsWithInvalidName()
    {
        boolean isSupported = TestUtils.envSupportCheck(cfg);
        if ( !isSupported )
        {
            throw new SkipException("Skipping as test is supported only for int, sysint, stage environments.");
        }
        SoftAssertions softly = new SoftAssertions();
        createAlertThresholds(THRESHOLD_NAME);
        Response response = deleteThreshold(THRESHOLD_NAME + "invalid");
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_NOT_FOUND);

        response = deleteThreshold(THRESHOLD_NAME);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_NO_CONTENT);
        softly.assertAll();
    }

    // this will create a threshold and can be reused in another test case #TC-9
    private String createAlertThresholds(String tName)
    {
        SoftAssertions softly = new SoftAssertions();
        String payload = "{\"name\":\"" + tName + "\",\"description\":\"" + THRESHOLD_DESCRIPTION
                + "\",\"rule\":[{\"severity\":\"" + THRESHOLD_SEVERITY + "\",\"timeInSeconds\":"
                + THRESHOLD_TIMEINSECONDS + ",\"displayUnit\":\"" + THRESHOLD_DISPLAYUNIT + "\"}]}";

        // create threshold
        Response response = createThresholds(payload);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_OK);
        softly.assertAll();
        if ( response.getStatusCode() == HttpStatus.SC_OK )
        {
            return THRESHOLD_NAME;
        }
        else
        {
            return "Threshold not created";
        }
    }

    // this will create a threshold #TC-10
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Create Alert threshold", description = "User should able to create alert threshold", preCondition = "System should have some pre-existing Alerts")
    public void createAlertThresholds()
    {
        SoftAssertions softly = new SoftAssertions();
        boolean isSupported = TestUtils.envSupportCheck(cfg);
        if ( !isSupported )
        {
            throw new SkipException("Skipping as test is supported only for int, sysint, stage environments.");
        }
        String thresoldName = createAlertThresholds(THRESHOLD_NAME);
        if ( thresoldName.equalsIgnoreCase(THRESHOLD_NAME) )
        {
            Response response = deleteThreshold(THRESHOLD_NAME);
            softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_NO_CONTENT);
        }
        else
        {
            softly.fail("Threshold is not created");
        }
        deleteThreshold(THRESHOLD_NAME);
        softly.assertAll();
    }

    // this will create a threshold with exising thrsold name #TC-11
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Create Alert threshold with existing name", description = "User should not be able to create alert threshold with existing name,", preCondition = "System should have some pre-existing Alerts")
    public void createAlertThresholdsWithExistingThresoldName()
    {
        boolean isSupported = TestUtils.envSupportCheck(cfg);
        if ( !isSupported )
        {
            throw new SkipException("Skipping as test is supported only for int, sysint, stage environments.");
        }
        SoftAssertions softly = new SoftAssertions();
        String payload = "{\"name\":\"" + THRESHOLD_NAME + "\",\"description\":\"" + THRESHOLD_DESCRIPTION
                + "\",\"rule\":[{\"severity\":\"" + THRESHOLD_SEVERITY + "\",\"timeInSeconds\":"
                + THRESHOLD_TIMEINSECONDS + ",\"displayUnit\":\"" + THRESHOLD_DISPLAYUNIT + "\"}]}";

        // create threshold
        Response response = createThresholds(payload);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_OK);

        response = createThresholds(payload);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_CONFLICT);

        response = deleteThreshold(THRESHOLD_NAME);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_NO_CONTENT);
        softly.assertAll();
    }

    // this will create a threshold #TC-12
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Validate that creation of invalid alert threshold shows status code as 400 ", description = "Validate that creation of invalid alert threshold shows status code as 400(SC_BAD_REQUEST)", preCondition = "System should have some pre-existing Alerts")
    public void createInvalidAlertThresholds()
    {
        boolean isSupported = TestUtils.envSupportCheck(cfg);
        if ( !isSupported )
        {
            throw new SkipException("Skipping as test is supported only for int, sysint, stage environments.");
        }
        SoftAssertions softly = new SoftAssertions();
        String payload = "{\"name_invalid\":\"" + THRESHOLD_NAME + "\",\"description\":\"" + THRESHOLD_DESCRIPTION
                + "\",\"rule\":[{\"severity\":\"" + THRESHOLD_SEVERITY + "\",\"timeInSeconds\":"
                + THRESHOLD_TIMEINSECONDS + ",\"displayUnit\":\"" + THRESHOLD_DISPLAYUNIT + "\"}]}";

        // create threshold
        Response response = createThresholds(payload);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_BAD_REQUEST);
        softly.assertAll();
    }

    // this will create a threshold and will update it threshold #TC-13
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Create a threshold and then update threshold", description = "Validate that user can create a threshold and then update it", preCondition = "System should have some pre-existing Alerts")
    public void updateAlertThresholds()
    {
        boolean isSupported = TestUtils.envSupportCheck(cfg);
        if ( !isSupported )
        {
            throw new SkipException("Skipping as test is supported only for int, sysint, stage environments.");
        }
        SoftAssertions softly = new SoftAssertions();
        createAlertThresholds(THRESHOLD_NAME);

        String payload = "{\"name\":\"" + THRESHOLD_NAME + "\",\"description\":\"" + THRESHOLD_DESCRIPTION
                + "_Updated\",\"rule\":[{\"severity\":\"" + THRESHOLD_SEVERITY + "\",\"timeInSeconds\":"
                + THRESHOLD_TIMEINSECONDS + ",\"displayUnit\":\"" + THRESHOLD_DISPLAYUNIT + "\"}]}";

        // create threshold
        Response response = updateThresholds(THRESHOLD_NAME, payload);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_NO_CONTENT);

        response = deleteThreshold(THRESHOLD_NAME);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_NO_CONTENT);
        softly.assertAll();
    }

    // this will create a threshold and will update it with invalid threshold #TC-14
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Create a threshold and then update it with invalid Threshold ", description = "Validate that user can create a threshold and then on updating it with inavlid threshold user gets status code as 404(SC_NOT_FOUND)", preCondition = "System should have some pre-existing Alerts")
    public void updateAlertWithInvalidThresholds()
    {
        boolean isSupported = TestUtils.envSupportCheck(cfg);
        if ( !isSupported )
        {
            throw new SkipException("Skipping as test is supported only for int, sysint, stage environments.");
        }
        SoftAssertions softly = new SoftAssertions();
        createAlertThresholds(THRESHOLD_NAME);

        String payload = "{\"name\":\"" + THRESHOLD_NAME + "\",\"description\":\"" + THRESHOLD_DESCRIPTION
                + "_Updated\",\"rule\":[{\"severity\":\"" + THRESHOLD_SEVERITY + "\",\"timeInSeconds\":"
                + THRESHOLD_TIMEINSECONDS + ",\"displayUnit\":\"" + THRESHOLD_DISPLAYUNIT + "\"}]}";

        // create threshold
        Response response = updateThresholds(THRESHOLD_NAME + "invalid", payload);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_NOT_FOUND);

        response = deleteThreshold(THRESHOLD_NAME);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_NO_CONTENT);
        softly.assertAll();
    }

    @DataProvider
    public Object[][] thresholdSeverity()
    {
        // scenario, payload, expectedStatusCode
        return new Object[][]
        {
                // severity, statusCodd

                {
                        "info", HttpStatus.SC_OK
                },
                {
                        "error", HttpStatus.SC_OK
                },
                {
                        "critical", HttpStatus.SC_OK
                },
                {
                        "warning", HttpStatus.SC_OK
                }
        };

    }

    @Test(dataProvider = "thresholdSeverity")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Verify  Threshold creation with different severity", description = "Verify  Threshold creation with different severity", preCondition = "System should have some pre-existing Alerts")
    public void verifyCreateThresholdWithDifferentSeverity(String severityName, int statusCode)
    {
        SoftAssertions softly = new SoftAssertions();
        String payload = "{\"name\":\"" + THRESHOLD_NAME + "\",\"description\":\"" + THRESHOLD_DESCRIPTION
                + "\",\"rule\":[{\"severity\":\"" + severityName + "\",\"timeInSeconds\":" + THRESHOLD_TIMEINSECONDS
                + ",\"displayUnit\":\"" + THRESHOLD_DISPLAYUNIT + "\"}]}";

        // create threshold
        Response response = createThresholds(payload);
        softly.assertThat(response.getStatusCode()).isEqualTo(statusCode);
        response = deleteThreshold(THRESHOLD_NAME);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_NO_CONTENT);
        softly.assertAll();
    }

    //Defect id - DE109309 (contains is not working for AlertType parameter)
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get alerts for different alery type in the filter", description = "Validate that user can get the alerts for differnt alert types", preCondition = "System should have some pre-existing Alerts")
    public void testGetAlertsScenariosWithAlertType()
    {
        boolean isSupported = TestUtils.envSupportCheck(cfg);
        if ( !isSupported )
        {
            throw new SkipException("Skipping as test is supported only for int, sysint, stage environments.");
        }
        _logger.info(String.format("\tRunning: %s", "Testing filter with contains for AlertType parameter"));
        SoftAssertions softly = new SoftAssertions();
        Map<String, Object> qMap = new HashMap<>();
        qMap.put("contains", AlertManagementControllerUtils.DEVICE_ONLINE_OFFLINE_ALERT_TYPE);
        Response response = getAlertsV1(qMap);
        softly.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SC_OK);
        if ( response.getStatusCode() == HttpStatus.SC_OK )
        {
            List<Map<String, Object>> alerts = response.jsonPath().getList("$");
            softly.assertThat(alerts.size()).isGreaterThanOrEqualTo(0);
            if (alerts.size() > 0)
            {
                softly.assertThat(alerts.get(0).get("alertId")).isNotNull();
                softly.assertThat(alerts.get(0).get("source")).isNotNull();
                softly.assertThat(alerts.get(0).get("deviceId")).isNotNull();
                softly.assertThat(alerts.get(0).get("triggered")).isNotNull();
                softly.assertThat(alerts.get(0).get("lastUpdated")).isNotNull();
                softly.assertThat(alerts.get(0).get("lastUpdatedBy")).isNotNull();
                softly.assertThat(alerts.get(0).get("alertType")).isEqualTo(AlertManagementControllerUtils.DEVICE_ONLINE_OFFLINE_ALERT_TYPE);
            }
        }
        softly.assertAll();
    }
}
