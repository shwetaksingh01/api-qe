/*
 * Copyright (c) 2012 - 2018 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.emapi.utils;

import java.util.HashMap;
import java.util.Map;

import com.ge.dspmicro.qe.tools.environment.Configuration;
import com.ge.dspmicro.qe.tools.utils.RestClient;
import com.ge.dspmicro.qe.tools.utils.Token;
import com.jayway.restassured.response.Response;

/**
 * 
 * @author 212547153
 */
@SuppressWarnings(value =
{
        "javadoc", "nls"
})
public class BomControllerUtils
{
    public static String BASE_URI_BETA              = EmapiConstants.EM_API_BETA_BASE + EmapiConstants.BOM_MANAGEMENT;
    public static String BASE_URI_V1                = EmapiConstants.EM_API_BASE + EmapiConstants.BOM_MANAGEMENT;

    public static String BASE_URI_BOMS_BETA         = BASE_URI_BETA + "/boms";
    public static String BASE_URI_BOMS_DEVICES_BETA = BASE_URI_BETA + "/devices";

    public static String BASE_URI_BOMS_V1           = BASE_URI_V1 + "/boms";
    public static String BASE_URI_BOMS_DEVICES_V1   = BASE_URI_V1 + "/devices";

    static Configuration cfg                        = Configuration.getConfig();
    private static Token token                      = cfg.getAdminUAAToken();

    // methods for v1

    // GET /emapi/v1/package-management/boms Retrieve a list of BOM description
    public static Response getBomsV1(Map<String, Object> params)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_BOMS_V1, params, token);
    }

    // GET /emapi/v1/package-management/boms Retrieve a list of BOM description
    public static Response getFilteredBOMsV1(int limit, int offset, String filter)
    {
        Map<String, Object> qMap = new HashMap<>();
        qMap.put("limit", limit);
        qMap.put("offset", offset);
        qMap.put("filter", filter);
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_BOMS_V1, qMap, token);
    }

    // GET /emapi/v1/package-management/boms Retrieve a list of BOM description
    public static Response getBomByBomIdV1(String bomId)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_BOMS_V1 + "/" + bomId, null, token);
    }

    // POST /emapi/v1/package-management/boms Create a BOM
    public static Response createBomV1(String bomJsonFile)
    {
        return RestClient.postWithMultiPart(cfg.getEdgeManagerUrl(), BASE_URI_BOMS_V1, bomJsonFile, token);
    }

    // POST /emapi/v1/package-management/boms/deploy Deploy a BOM to a filtered set of devices
    public static Response deployBOMV1(String payload)
    {
        return RestClient.post(cfg.getEdgeManagerUrl(), BASE_URI_BOMS_V1 + "/deploy", payload, token);
    }

    // GET /emapi/v1/package-management/boms/grouped Retrieve a list of BOM grouped by name
    public static Response getBomGroupedByNameV1(Map<String, Object> params)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_BOMS_V1 + "/grouped", params, token);
    }

    // DELETE /emapi/v1/package-management/boms/{name}/{version} Delete BOM for a specified bom name and version
    public static Response deleteBomV1(String name, String version)
    {
        return RestClient.delete(cfg.getEdgeManagerUrl(), BASE_URI_BOMS_V1 + "/" + name + "/" + version, token);
    }

    // GET /emapi/v1/package-management/boms/{name}/{version} Get BOM for a specified name and version
    public static Response getBomV1(String name, String version)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_BOMS_V1 + "/" + name + "/" + version, null, token);
    }

    // DELETE /emapi/v1/package-management/devices/{deviceId}/bom-installations Delete a BOM installation for a specified device
    public static Response deleteBomOnDeviceV1(String deviceId)
    {
        return RestClient.delete(cfg.getEdgeManagerUrl(),
                BASE_URI_BOMS_DEVICES_V1 + "/" + deviceId + "/bom-installations", token);
    }

    // GET /emapi/v1/package-management/devices/{deviceId}/bom-installations Get running BOM and desired BOM for a specified device
    public static Response getDesiredAndRunningBomOfDeviceV1(String deviceId)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_BOMS_DEVICES_V1 + "/" + deviceId + "/bom-installations",
                null, token);
    }

    // GET /emapi/v1/package-management/devices/{deviceId}/bom-installations/details Get BOM installation details for a specified deviceId with individual
    // package status
    public static Response getBomInstallationDetailFromDeviceV1(String deviceId)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(),
                BASE_URI_BOMS_DEVICES_V1 + "/" + deviceId + "/bom-installations/details", null, token);
    }

    // GET /emapi/v1/bom-management/operations/{operationId} Retrieve the details for a package operation.
    public static Response getBomPackageOperationDetailsV1(String operationId, String deviceFilter)
    {
        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("limit", 50);
        queryParams.put("offset", 0);
        queryParams.put("deviceFilter", deviceFilter);
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI_V1 + "/operations/" + operationId, queryParams, token);
    }

    public void setToken(Token token)
    {
        BomControllerUtils.token = token;
    }

    public Token getToken()
    {
        return BomControllerUtils.token;
    }
}
