/*
 * Copyright (c) 2019 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.emapi.test;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.assertj.core.api.Assertions;
import org.assertj.core.api.SoftAssertions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ge.dspmicro.qe.emapi.pojo.PackagePojo;
import com.ge.dspmicro.qe.emapi.utils.EmapiConstants;
import com.ge.dspmicro.qe.emapi.utils.PackageDeploymentControllerUtils;
import com.ge.dspmicro.qe.emapi.utils.PackageManagementControllerUtils;
import com.ge.dspmicro.qe.emapi.utils.TestUtils;
import com.ge.dspmicro.qe.tools.BaseTest;
import com.ge.dspmicro.qe.tools.testng.TestListener;
import com.ge.dspmicro.qe.tools.utils.CommonUtils;
import com.ge.predix.edgemanager.qe.annotations.JiraTestCaseInfo;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;

/**
 * @author 212756555
 */

@SuppressWarnings(value =
{
        "javadoc", "nls"
})
@Listeners(TestListener.class)
public class
PackageDeploymentControllerV1Test extends BaseTest
{
    private static final Logger _logger               = LoggerFactory
            .getLogger(PackageDeploymentControllerV1Test.class);
    private String              deviceId              = "";
    private String              deploymentOperationId = "";

    @BeforeClass
    public void setup()
    {
        this.deviceId = cfg.getQePMDeviceName();
    }

    @Test(priority = 1)
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get Device Package Installation History,Package Operation Details and download deployment task output", description = "Get Device Package Installation History,Package Operation Details and download deployment task output and validate the status code as 200(OK)", preCondition = "Software Packages should be installed on the device")
    public void test_getDevicePackageInstallationHistory_getPackageOperationDetails_downloadDeploymentTaskOutput()
            throws IOException
    {

        _logger.info("\tTestGetSoftwarePackages installed on the device");

        // get device package installation history for software from the device
        Response response = PackageDeploymentControllerUtils
                .getDevicePackageInstallationHistoryV1(this.deviceId, "software");
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK,
                "getDevicePackageInstallationHistory status code do not match expected code of 200");
        JsonPath jsonPath = response.jsonPath();
        String taskId = "";
        List<Map<String, Object>> packages = jsonPath.getList("$");
        for (Map<String, Object> pkg : packages)
        {
            softAssert.assertNotNull(pkg.get("operationId"), "operationId not found for previously installed package");
            String operationId = (String) pkg.get("operationId");
            @SuppressWarnings("unchecked") List<Map<String, Object>> details = (List<Map<String, Object>>) pkg
                    .get("details");
            for (Map<String, Object> detail : details)
            {
                if ( detail.get("type") != null )
                {
                    softAssert.assertNotNull(detail.get("scheduled"),
                            "scheduled not found for previously installed package");
                    softAssert.assertNotNull(detail.get("status"), "status not found for previously installed package");
                    softAssert.assertTrue(CommonUtils.isLowerCase((String) detail.get("status")),
                            "status is not lower case");
                    // latest deployment will have installedBy
                    // every time a bom is deployed to the same device, the operationId of previous bom deployment gets erased
                    // so the history record for this entry will return a null installedBy value!
                    if ( PackageDeploymentControllerUtils.getPackageOperationDetailsV1(operationId, "").getStatusCode()
                            != HttpStatus.SC_NOT_FOUND )
                    {
                        softAssert.assertNotNull(detail.get("installedBy"), "installedBy is null");
                        if ( (boolean) detail.get("logAvailable") )
                        {
                            taskId = (String) detail.get("taskId");
                        }
                    }
                }
                softAssert.assertNotNull(detail.get("created"), "created not found for previously installed package");
                softAssert.assertNotNull(detail.get("taskId"), "taskId not found for previously installed package");
                softAssert.assertNotNull(detail.get("name"), "name not found for previously installed package");
                softAssert.assertNotNull(detail.get("version"), "version not found for previously installed package");
                softAssert.assertNotNull(detail.get("type"), "type not found for previously installed package");
                softAssert.assertTrue(!detail.get("type").equals("bom") && !detail.get("type").equals("configuration"),
                        "type should not be bom or configuration");
                softAssert.assertNotNull(detail.get("description"),
                        "description not found for previously installed package");
                softAssert.assertNotNull(detail.get("vendor"), "vendor not found for previously installed package");

                if ( StringUtils.isNotEmpty((String) detail.get("status")) )
                {
                    if ( detail.get("status").equals("success") )
                    {
                        softAssert.assertNotNull(detail.get("started"),
                                "started not found for previously installed package");
                        softAssert
                                .assertNotNull(detail.get("ended"), "ended not found for previously installed package");
                        softAssert.assertNotNull(detail.get("statusMessage"),
                                "statusMessage not found for previously installed package");
                        softAssert.assertNotNull(detail.get("detailedStatus"),
                                "detailedStatus not found for previously installed package");
                    }
                }
                softAssert.assertNotNull(detail.get("logAvailable"),
                        "logAvailable not found for previously installed package");
                softAssert.assertNotNull(detail.get("currentRetryAttempt"),
                        "currentRetryAttempt not found for previously installed package");
                softAssert.assertNotNull(detail.get("retryLimit"),
                        "retryLimit not found for previously installed package");
            }

        }
        _logger.info("\tTest getDeploymentTaskOutput installed on the device");

        if ( !taskId.isEmpty() )
        {
            response = PackageDeploymentControllerUtils.downloadDeploymentTaskOutputV1(taskId);
            softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK,
                    "getDeploymentTaskOutput status code do not match expected code of 200");
            String taskOutputFile = System.currentTimeMillis() + "log.gz";
            CommonUtils.writeResponseToFile(response, taskOutputFile);
            softAssert.assertTrue(new File(taskOutputFile).length() > 0, "Size of downloaded file is 0");
            FileUtils.forceDelete(new File(taskOutputFile));
        }

        _logger.info("\tTestGetConfigurationPackages installed on the device");
        response = PackageDeploymentControllerUtils
                .getDevicePackageInstallationHistoryV1(this.deviceId, "configuration");
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK,
                "getListofPackagesInstalledOnDevicePreviously status code do not match expected code of 200");
        jsonPath = response.jsonPath();

        packages = jsonPath.getList("$");
        for (Map<String, Object> pkg : packages)
        {
            softAssert.assertNotNull(pkg.get("operationId"), "operationId not found for previously installed config");
            String operationId = (String) pkg.get("operationId");
            List<Map<String, Object>> details = (List<Map<String, Object>>) pkg.get("details");
            for (Map<String, Object> detail : details)
            {
                if ( detail.get("type") != null )
                {
                    softAssert.assertTrue((detail.get("type").equals("configuration")), "type should be configuration");
                    softAssert.assertNotNull(detail.get("scheduled"),
                            "scheduled not found for previously installed package");
                    softAssert.assertNotNull(detail.get("status"), "status not found for previously installed package");
                    softAssert.assertTrue(CommonUtils.isLowerCase((String) detail.get("status")),
                            "status is not lower case");

                    if ( PackageDeploymentControllerUtils.getPackageOperationDetailsV1(operationId, "").getStatusCode()
                            != HttpStatus.SC_NOT_FOUND )
                    {
                        softAssert.assertNotNull(detail.get("installedBy"), "installedBy is null");
                    }
                }

                softAssert.assertNotNull(detail.get("created"), "created not found for previously installed config");
                softAssert.assertNotNull(detail.get("taskId"), "taskId not found for previously installed config");
                softAssert.assertNotNull(detail.get("name"), "name not found for previously installed config");
                softAssert.assertNotNull(detail.get("version"), "version not found for previously installed config");
                softAssert.assertNotNull(detail.get("description"),
                        "description not found for previously installed config");
                softAssert.assertNotNull(detail.get("vendor"), "vendor not found for previously installed config");

                if ( StringUtils.isNotEmpty((String) detail.get("status")) )
                {
                    if ( detail.get("status").equals("success") )
                    {
                        softAssert.assertNotNull(detail.get("started"),
                                "started not found for previously installed config");
                        softAssert
                                .assertNotNull(detail.get("ended"), "ended not found for previously installed config");
                        softAssert.assertNotNull(detail.get("statusMessage"),
                                "statusMessage not found for previously installed config");
                        softAssert.assertNotNull(detail.get("detailedStatus"),
                                "detailedStatus not found for previously installed config");
                    }
                }
                softAssert.assertNotNull(detail.get("logAvailable"),
                        "logAvailable not found for previously installed config");
                softAssert.assertNotNull(detail.get("currentRetryAttempt"),
                        "currentRetryAttempt not found for previously installed config");
                softAssert.assertNotNull(detail.get("retryLimit"),
                        "retryLimit not found for previously installed config");
            }
        }
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get Currently installed Packages for a Device", description = "Get Currently installed Packages for a Device and validate the status code as 200(OK)", preCondition = "Software Packages should be installed on the device")
    public void testGetCurrentlyInstalledPackages()
    {
        Response response = PackageDeploymentControllerUtils.getCurrentlyInstalledPackagesV1(this.deviceId);
        SoftAssertions softly = new SoftAssertions();
        softly.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_OK);
        if ( response.getStatusCode() == HttpStatus.SC_OK )
        {
            List<Map<String, Object>> packages = response.jsonPath().getList("$");
            softly.assertThat(packages.size()).isGreaterThanOrEqualTo(0);
            if (packages.size() > 0)
            {
                softly.assertThat(packages.get(0).get("name")).isNotNull();
                softly.assertThat(packages.get(0).get("version")).isNotNull();
            }
        }
        softly.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Deploy Package for a Device", description = "Deploy  Package for a Device and validate the status code as 200(OK)", preCondition = "Software Packages should be present in the system to be deployed")
    public void testDeployPackage()
            throws InterruptedException
    {
        PackagePojo pkg = new PackagePojo("machine", "configuration", "configuration.zip");
        String uploadIdForPackage = getUploadIdForPackage(pkg);
        uploadPackage(pkg, uploadIdForPackage);
        Response response = deployPackage(pkg, this.deviceId);

        this.deploymentOperationId = getOperationId(response);

        // get operation details
        response = PackageDeploymentControllerUtils.getPackageOperationDetailsV1(this.deploymentOperationId, "");
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK,
                "getPackageOperationDetails response status code is not as expected.");

        JsonPath jsonPath = response.jsonPath();
        long currentTimeStamp = System.currentTimeMillis();
        softAssert.assertTrue(jsonPath.getLong("scheduled") <= currentTimeStamp,
                "scheduled not found for operation detail");
        softAssert.assertTrue(jsonPath.getLong("created") <= currentTimeStamp,
                "created not found for operation detail");
        softAssert.assertEquals(jsonPath.getString("name"), pkg.getName() + "." + pkg.getVersion(),
                "Package name format do not match in operation details");
        softAssert.assertEquals(jsonPath.getString("type"), pkg.getType(),
                "type name do not match in operation details");
        softAssert.assertEquals(jsonPath.getString("operationId"), this.deploymentOperationId,
                "operationId name do not match in operation details");
        softAssert.assertEquals(jsonPath.getString("scheduledBy"), cfg.getApiClientId(),
                "scheduledBy do not match clientId");
        softAssert.assertNotNull(jsonPath.getString("status"), "status  not found for operation detail");

        List<Map<String, Object>> details = jsonPath.getList("details");
        for (Map<String, Object> detail : details)
        {
            softAssert.assertNotNull(detail, "Detail is null");
            softAssert.assertNotNull(detail.get("deviceId"), "Task deviceId is null");
            softAssert.assertTrue(!detail.get("deviceId").equals(""),
                    "Task Operation deviceId is empty for " + this.deploymentOperationId);
            softAssert.assertTrue(!detail.get("deviceName").equals(""),
                    "Task Operation deviceNn=ame is empty for " + this.deploymentOperationId);
            softAssert.assertNotNull(detail.get("packageId"), "packageId is null");

            List<Map<String, Object>> tasks = (List<Map<String, Object>>) detail.get("tasks");
            for (Map<String, Object> task : tasks)
            {
                softAssert.assertNotNull(task.get("scheduled"), "scheduled not found for task detail");
                softAssert.assertTrue(task.get("scheduled") != null && (long) task.get("scheduled") <= currentTimeStamp,
                        "scheduled null or earlier than expected");
                softAssert.assertNotNull(task.get("created"), "created not found for task detail");
                softAssert.assertTrue(task.get("created") != null && (long) task.get("created") <= currentTimeStamp,
                        "created null or earlier than expected");
                softAssert.assertEquals(task.get("name"), pkg.getName(), "name  do not match for task detail");
                softAssert.assertEquals(task.get("type"), pkg.getType(), "type do not match for task detail");
                softAssert.assertNotNull(task.get("status"), "status  not found for task detail");
                softAssert.assertTrue(CommonUtils.isLowerCase((String) task.get("status")));
                softAssert.assertNotNull(task.get("taskId"), "taskId  not found for task detail");
                softAssert.assertFalse((boolean) task.get("logAvailable"), "logAvailable not found for task detail");
                softAssert.assertEquals((String) task.get("scheduledBy"), cfg.getApiClientId(),
                        "scheduledBy do not match clientId");
            }

            softAssert.assertTrue(((String) detail.get("payload")).contains(pkg.getName()),
                    "payload doesn't has package name for task detail");
            softAssert.assertEquals((int) detail.get("priority"), 2, "priority not found for task detail");
            softAssert.assertNotNull(detail.get("retryLimit"), "retryLimit not found");
            softAssert.assertNull(detail.get("updated"), "updated should no longer be set for task detail");
            softAssert.assertTrue(detail.get("updated") == null || (long) detail.get("updated") <= currentTimeStamp,
                    "updated earlier than expected");

        }

        // get operation history and assert that operation created by deployment is returned
        response = PackageDeploymentControllerUtils.getPackageOperationHistoryV1("deviceId eq \"" + this.deviceId + "\"",
                10);
        List<Map<String, Object>> operations = response.jsonPath().getList("$");
        int count = 0;
        for (Map<String, Object> op : operations)
        {
            if ( op.get("operationId").equals(this.deploymentOperationId) )
            {
                count++;

            }
        }
        softAssert.assertEquals(count, 1, "Deployment operation not found in operation history");
        softAssert.assertAll();
    }

    @AfterClass(alwaysRun = true)
    public void cleanup()
    {
        String cancelPayload = "{\"deploymentActions\":[{\"action\":\"CANCEL\",\"params\":{}}]}";
        _logger.info("Cancelling Package Deployment Operation: " + this.deploymentOperationId);

        Response response = PackageDeploymentControllerUtils.cancelDeploymentV1(this.deploymentOperationId, cancelPayload);
        Assertions.assertThat(response.statusCode())
                .as("Operation Cancellation of " + this.deploymentOperationId + " failed to cancel.")
                .isIn(HttpStatus.SC_ACCEPTED, HttpStatus.SC_NO_CONTENT);
    }

    private String getOperationId(Response response)
    {
        String locationHeader = response.getHeader("Location");
        String operationId = locationHeader.split("/")[response.getHeader("Location").split("/").length - 1];
        softAssert.assertEquals(locationHeader,
                EmapiConstants.EM_API_V1_VERSION + EmapiConstants.PACKAGE_MANAGEMENT + "/operations/" + operationId);
        return operationId;
    }

    private Response deployPackage(PackagePojo pkg, String deviceId)
            throws InterruptedException
    {
        String payload = CommonUtils.getResourceAsString("/package/deployPackageMinPayload.json")
                .replaceAll("PACKAGE-NAME", pkg.getName()).replaceAll("TYPE", pkg.getType())
                .replaceAll("VERSION", pkg.getVersion())
                .replaceAll("FILTER", "deviceId eq \\\\\"" + deviceId + "\\\\\"");

        Response response = PackageDeploymentControllerUtils.deployPackagesToDevicesV1(payload);
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_ACCEPTED,
                "deployPackagesToDevices response status code is not as expected.");
        Thread.sleep(3000);
        return response;
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get the list of instance ids for a Device", description = "Get the list of instance ids for a Device and validate the status code as 200(OK)", preCondition = "Device should have instances")
    private void getAppInstallations()
    {
        Response response = PackageDeploymentControllerUtils.getAppInstallationsV1();
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK, "Response code do not match");
        softAssert.assertAll();
    }

    private void uploadPackage(PackagePojo pkg, String uploadId)
            throws InterruptedException
    {
        pkg.setUploadId(uploadId);
        TestUtils.uploadPackage(pkg);
    }

    private String getUploadIdForPackage(PackagePojo pkg)
    {
        String payload = CommonUtils.getResourceAsString("/package/uploadRequest.json")
                .replaceAll("\\$NAME", pkg.getName()).replaceAll("\\$VERSION", pkg.getVersion())
                .replaceAll("\\$VENDOR", pkg.getVendor()).replaceAll("\\$DESCRIPTION", pkg.getDesc())
                .replaceAll("\\$TYPE", pkg.getType()).replaceAll("\\$NOTES", pkg.getNotes())
                .replaceAll("\\$HANDLER", pkg.getHandler()).replaceAll("\\$SIZE", pkg.getTotalBytes() + "")
                .replaceAll("\\$ATTRIBUTES", pkg.getAttributes());

        Response response = PackageManagementControllerUtils.createUploadIdV1(payload);

        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_CREATED,
                "createUploadId status code do not match expected code of 201");

        return response.jsonPath().getString("uploadId");
    }
}
