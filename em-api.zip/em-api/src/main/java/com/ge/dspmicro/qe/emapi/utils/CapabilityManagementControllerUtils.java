/*
 * Copyright (c) 2019 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.emapi.utils;

import java.util.Map;

import com.ge.dspmicro.qe.tools.environment.Configuration;
import com.ge.dspmicro.qe.tools.utils.RestClient;
import com.ge.dspmicro.qe.tools.utils.Token;
import com.jayway.restassured.response.Response;

/**
 *
 * @author 212758475
 */
@SuppressWarnings(
{
        "javadoc", "nls"
})
public class CapabilityManagementControllerUtils
{
    static         Configuration cfg   = Configuration.getConfig();
    private static Token         token = cfg.getAdminUAAToken();

    private static final String BASE_URI = EmapiConstants.EM_API_BASE + "/capability-management/capabilities";
    private static final String DELETE_URI = "/svc/capability/v1/capabilities";

    //GET /emapi/v1/capability-management/capabilities
    //Get a list of all capabilities
    public static Response getCapabilities(Map<String, ?> queryParams)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI, queryParams, token);
    }

    //POST /emapi/v1/capability-management/capabilities
    //Create a capability
    public static Response createCapability(String payload)
    {
        return RestClient.post(cfg.getEdgeManagerUrl(), BASE_URI, payload, token);
    }

    //GET /emapi/v1/capability-management/capabilities/{name}/{version}
    //Get a capability
    public static Response getCapability(String name, String version, Map<String, ?> queryParams)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), BASE_URI + "/" + name + "/" + version,
                queryParams, token);
    }

    //Calling EM capability manager api to delete created test data as delete endpoint is not available in em-api yet.
    //DELETE /svc/capability/v1/capabilities/{name}/{version}
    //Delete capability
    public static Response deleteCapability(String name, String version)
    {
        return RestClient.delete(cfg.getEdgeManagerUrl(), DELETE_URI + "/" + name + "/" + version, token);
    }

    public Token getToken()
    {
        return CapabilityManagementControllerUtils.token;
    }

    public void setToken(Token token)
    {
        CapabilityManagementControllerUtils.token = token;
    }
}
