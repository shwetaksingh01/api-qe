/*
 * Copyright (c) 2019 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.emapi.test;

import static com.ge.dspmicro.qe.emapi.utils.CommandManagementControllerUtils.addCommandV1;
import static com.ge.dspmicro.qe.emapi.utils.CommandManagementControllerUtils.deleteCommandV1;
import static com.google.common.net.HttpHeaders.LOCATION;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ge.dspmicro.qe.emapi.utils.CommandManagementControllerUtils;
import com.ge.dspmicro.qe.emapi.utils.EmapiConstants;
import com.ge.dspmicro.qe.tools.BaseTest;
import com.ge.dspmicro.qe.tools.CommandConstants;
import com.ge.dspmicro.qe.tools.QEConstants;
import com.ge.dspmicro.qe.tools.environment.Configuration;
import com.ge.dspmicro.qe.tools.testng.TestListener;
import com.ge.dspmicro.qe.tools.utils.CommonUtils;
import com.ge.predix.edgemanager.qe.annotations.JiraTestCaseInfo;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;

/**
 *
 * @author 212547153
 */

@SuppressWarnings({"javadoc", "nls"
}) @Listeners(TestListener.class) public class CommandControllerV1Test
        extends BaseTest
{
    private static final Logger         _logger               = LoggerFactory.getLogger(CommandControllerV1Test.class);
    private static String               deviceId;
    private static Map<String, Integer> commandIdMap          = new HashMap<>();
    private static String               addCommandPayload;
    private static String               sendCommandPayload;
    private static String               operationId;
    private List<String>                addCommandList        = new ArrayList<>();
    private List<String>                sentCommandTaskIdList = new ArrayList<>();

    @DataProvider(name = "dataProvider1")
    public static Object[][] dataProvider1()
    {
        Object[][] params =
        {
                {
                        "device_id eq \\\"" + deviceId + "\\\"", "getlogs", "\"name\":\"machine:/machine/machine.log\"",
                        HttpStatus.SC_ACCEPTED
                },
                {
                        "device_id eq \\\"" + deviceId + "\\\"", "ipaddress", "", HttpStatus.SC_ACCEPTED
                },
                {
                        "device_id eq \\\"" + deviceId + "\\\"", "setpolling", "\"PollingTime\":\"30\"",
                        HttpStatus.SC_ACCEPTED
                },
        };
        return params;
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get Command operation history", description = "User can get the command opeartion history", preCondition = "System should have some pre-existing Commands")
    public static void testGetCommandOperationHistory()
    {
        Response response = CommandManagementControllerUtils.getCommandOperationHistoryV1("5", "0");
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK);
        JsonPath jsonPath = response.jsonPath();
        List<Map<String, Object>> operations = jsonPath.getList("$");
        softAssert.assertEquals(operations.size(), 5,
                "Command Operation history does not have 5 operations as requested");
        operations.forEach(op -> {
            softAssert.assertNotNull(op.get("scheduled"), "scheduled is null.");
            softAssert.assertNotNull(op.get("created"), "created is null.");
            softAssert.assertNotNull(op.get("started"), "started is null.");
            softAssert.assertNotNull(op.get("ended"), "ended is null.");
            softAssert.assertNotNull(op.get("name"), "name is null.");
            softAssert.assertNotNull(op.get("status"), "status is null.");
            softAssert.assertNotNull(op.get("operationId"), "operationId is null.");
            softAssert.assertNotNull(op.get("successfulTasks"), "successfullTasks is null.");
            softAssert.assertNotNull(op.get("failedTasks"), "failedTasks is null.");
            softAssert.assertNotNull(op.get("inProgressTasks"), "inProgressTasks is null.");
            softAssert.assertNotNull(op.get("pendingTasks"), "pendingTasks is null.");
            softAssert.assertNotNull(op.get("cancelledTasks"), "cancelledTasks is null.");
            softAssert.assertNotNull(op.get("timeoutTasks"), "timeoutTasks is null.");
            softAssert.assertNotNull(op.get("scheduledBy"), "scheduledBy is null.");
        });
        softAssert.assertAll();
    }

    @Override
    @BeforeClass
    public void init()
    {
        commandIdMap = CommandManagementControllerUtils.getCommandIdMapV1();
        addCommandPayload = CommonUtils.getResourceAsString("/command/addCommandPayload.json");
        sendCommandPayload = CommonUtils.getResourceAsString("/command/sendCommandPayload.json");
        cfg = Configuration.getConfig();
        deviceId = cfg.getQePMDeviceName();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get system commands which includes Predix Machine and Edge Agent System Commands", description = "User can get system commands which includes Predix Machine and Edge Agent System Commands", preCondition = "System should have some pre-existing Commands")
    public void testGetCommands()
    {
        // Verify GET response matches number of SYSTEM commands
        Response response = CommandManagementControllerUtils.getCommandsV1();
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_OK, "Response codes do not match.");
        softAssert.assertNotNull(response.asString(), "Response should not be null.");

        JsonPath jsonPath = response.jsonPath();
        List<Map<String, String>> commandsList = jsonPath.getList("$");
        int getSystemCommandCount = 0;
        int getPmSystemCommandCount = 0;
        int getEaSystemCommandCount = 0;
        for (Map<String, String> command : commandsList)
        {
            if ( command.get("type").equals("system") )
            {
                getSystemCommandCount++;

                if ( command.get(CommandConstants.AGENT_TYPE).equals(QEConstants.PREDIX_MACHINE) )
                {
                    getPmSystemCommandCount++;
                }
                else if ( command.get(CommandConstants.AGENT_TYPE).equals(QEConstants.EDGE_AGENT) )
                {
                    getEaSystemCommandCount++;
                }
            }
        }
        _logger.info("\tAssert on count of system commands");
        _logger.info("\tTotal number of SYSTEM commands: " + getSystemCommandCount + " (PM: " + getPmSystemCommandCount
                + ", EA: " + getEaSystemCommandCount + ")");
        softAssert.assertEquals(getSystemCommandCount, CommandConstants.TOTAL_SYSTEM_COMMAND_COUNT,
                "Expected SYSTEM command counts do not match.");
        softAssert.assertEquals(getPmSystemCommandCount, CommandConstants.PM_SYSTEM_COMMAND_COUNT,
                "Expected PredixMachine SYSTEM command counts do not match.");
        softAssert.assertEquals(getEaSystemCommandCount, CommandConstants.EA_SYSTEM_COMMAND_COUNT,
                "Expected EdgeAgent SYSTEM command counts do not match.");
        softAssert.assertAll();
    }

    @DataProvider
    public Object[][] getCommandQuery()
    {
        return new Object[][]
        // "scenario", "sortBy" -- same keys as filter, "sortOrder", "contains" -- text in commandDisplayName only,
        // "filter" -- valid keys in commandId, agentType, commandDisplayName only, "responseCode"
        {
                {
                        "PredixMachine Query", CommandConstants.COMMAND_ID, QEConstants.ORDER_DESC, "Container",
                        "agentType eq \"PredixMachine\" and commandDisplayName co \"Application\"", "200",
                        QEConstants.PREDIX_MACHINE
                },
                {
                        "EdgeAgent Query", CommandConstants.COMMAND_ID, QEConstants.ORDER_DESC, "Application",
                        "agentType eq \"EdgeAgent\"", "200", QEConstants.EDGE_AGENT
                }
        };
    }

    @Test(dataProvider = "getCommandQuery")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get system commands which query parameters", description = "User can get system commands by passing query parameters", preCondition = "System should have some pre-existing Commands")
    public void testGetCommandsWithQueryParams(String scenario, String sortBy, String sortOrder, String containsStr,
            String filter, String responseCode, String agentType)
    {
        _logger.info("\tRunning scenario: " + scenario);

        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("limit", HttpStatus.SC_OK);
        queryParams.put("sort", sortBy);
        queryParams.put("order", sortOrder);
        queryParams.put("contains", containsStr);
        queryParams.put("filter", filter);

        _logger.info("\tgetCommand query: " + queryParams.toString());
        Response response = CommandManagementControllerUtils.getCommandsV1(queryParams);

        JsonPath jsonPath = response.jsonPath();
        List<Map<String, Object>> commandsList = jsonPath.getList("$");

        softAssert.assertEquals(response.statusCode() + "", responseCode, "Response codes do not match.");
        softAssert.assertNotNull(response.asString(), "Response should not be null.");

        int firstCommandId = Integer.parseInt((String) commandsList.get(0).get(sortBy));
        int lastCommandId = Integer.parseInt((String) commandsList.get(commandsList.size() - 1).get(sortBy));
        if ( sortOrder.equals(QEConstants.ORDER_ASC) )
        {
            softAssert.assertTrue(firstCommandId < lastCommandId,
                    "lastCommandId should be GT firstCommandId for ASC sort.");
        }
        else
        {
            softAssert.assertTrue(firstCommandId > lastCommandId,
                    "lastCommandId should be LT firstCommandId for DESC sort.");
        }

        for (Map<String, Object> command : commandsList)
        {
            softAssert.assertTrue(command.get(CommandConstants.AGENT_TYPE).equals(agentType),
                    "agentType do not match.");
            String commandDisplayName = (String) command.get("displayName");
            softAssert.assertTrue(commandDisplayName.toLowerCase().contains(containsStr.toLowerCase()),
                    "displayName does not include search string.");
        }

        softAssert.assertAll();
    }

    @DataProvider
    public Object[][] addCommandDP()
    {
        return new Object[][]
        {
                // {
                // "scenario","commandName", "commandType", "associateWithApp",
                // "agentType", "description", "statusCode",
                // "responseMessage"
                // },
                {
                        "Add custom command", "qe-command-", CommandConstants.CUSTOM_COMMAND, null, null,
                        "this is a test description", "201", ""
                },
                {
                        "Add system command", "qe-command-", CommandConstants.SYSTEM_COMMAND, null, null, null, "403",
                        "Cannot add a system command"
                },
                {
                        "Add custom command with agentType: EA", "qe-command-", CommandConstants.CUSTOM_COMMAND,
                        Boolean.TRUE, QEConstants.EDGE_AGENT, null, "201", ""
                },
                {
                        "Add custom command with agentType: PM and description", "qe-command-",
                        CommandConstants.CUSTOM_COMMAND, null, QEConstants.PREDIX_MACHINE, "this is a description",
                        "201", ""
                },
                {
                        "Add custom command with exceed char limit description", "qe-command-",
                        CommandConstants.CUSTOM_COMMAND, null, null,
                        "This is a test description of 200 char. This is a test description of 200 char. This is a test description of 200 char. This is a test description of 200 char. This is a test description of 200 char. ",
                        "400", "cannot be longer than 125 characters"
                },
        };
    }

    @Test(dataProvider = "addCommandDP")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Add custom command with agent type as EA and PM", description = "User can add custom commands with agent type as EA and PM and cannot add system commands", preCondition = "System should be stable so that POST requests are successful")
    public void testAddCommand(String scenario, String commandName, String commandType, Boolean associateWithApp,
            String agentType, String description, String statusCode, String responseMessage)
    {

        _logger.info("\tRunning scenario: " + scenario);
        String payload = "{\"displayName\":\"command_name\",\"command\":\"listfiles1\",\"hasOutput\":true,\"parameters\":[{\"displayName\":\"ParameterName\",\"key\":\"key\",\"value\":\"value\",\"editable\":false}],\"type\":\"command_type\",\"handler\":\"myType\",\"agentType\":\"$PredixMachine\",\"associateWithApp\":true,\"description\":\"validDescriptionInput\"}";

        String testCommandName = commandName + UUID.randomUUID().toString();

        payload = payload.replace("command_name", testCommandName);
        payload = payload.replace("command_type", commandType);

        if ( agentType != null )
        {
            payload = payload.replace("$PredixMachine", agentType);
        }
        else
        {
            payload = payload.replace(",\"agentType\":\"$PredixMachine\"", "");
        }
        if ( associateWithApp != null )
        {
            payload = payload.replace(",\"associateWithApp\":true",
                    ",\"associateWithApp\":" + Boolean.toString(associateWithApp));
        }
        else
        {
            payload = payload.replace(",\"associateWithApp\":true", "");
        }
        if ( description != null )
        {
            payload = payload.replace("validDescriptionInput", description);
        }
        else
        {
            payload = payload.replace(",\"description\":\"validDescriptionInput\"", "");
        }
        _logger.info("\tAddCommand payload: " + payload);

        Response response = addCommandV1(payload);

        if ( !statusCode.equals("201") )
        {
            Assert.assertTrue((response.statusCode() + "").equals(statusCode), "Response code do not match.");
            Assert.assertTrue(response.asString().contains(responseMessage),
                    "Response does not contain expected message.");
            _logger.info(response.getHeader(LOCATION));
        }
        else
        {
            response.then().statusCode(Integer.parseInt(statusCode));
            // get commandId from the response header
            String location = response.getHeader(LOCATION);
            softAssert
                    .assertTrue(location.contains(EmapiConstants.EM_API_V1_VERSION + "/command-management/commands/"));

            String commandId = location.substring(location.lastIndexOf("/") + 1);
            softAssert.assertTrue(!commandId.isEmpty());
            this.addCommandList.add(commandId);

            // verify added commands contains optional fields
            Response commandResponse = CommandManagementControllerUtils.getCommandDetailByIdV1(commandId);
            softAssert.assertEquals(commandResponse.statusCode(), HttpStatus.SC_OK, "Response codes do not match.");
            JsonPath jsonPath = commandResponse.jsonPath();
            Map<String, String> commandModel = jsonPath.getMap("$");
            if ( agentType != null )
            {
                softAssert.assertEquals(commandModel.get(CommandConstants.AGENT_TYPE), agentType,
                        "agentType does not match");
            }
            if ( associateWithApp != null )
            {
                softAssert.assertEquals(commandModel.get(CommandConstants.ASSOCIATE_WITH_APP), associateWithApp,
                        "associateWithApp does not match");
            }
            if ( description != null )
            {
                softAssert.assertTrue(commandModel.get(CommandConstants.DESCRIPTION).contains(description),
                        "Description does not contain expected description.");
            }
        }
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Add custom command with Existing name of command", description = "User gets conflict error code as 409 when tries to create command with existing name", preCondition = "System should already have a command with the name that the Post request is using")
    public void testAddCommandWithExistingName()
    {

        String payload = "{\"displayName\":\"command_name\",\"command\":\"listfiles1\",\"hasOutput\":true,\"parameters\":[{ \"displayName\":\"ParameterName\",\"key\":\"key\",\"value\":\"value\",\"editable\":false}],\"type\":\"CUSTOM\",\"handler\":\"myType\"}";

        String newCommandName = CommonUtils.getTimeStamp_HH_mm_ss_yyyy_MM_dd() + "-command";
        payload = payload.replace("command_name", newCommandName);
        Response response = addCommandV1(payload);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.SC_CREATED);
        this.addCommandList
                .add(response.getHeader(LOCATION).substring(response.getHeader(LOCATION).lastIndexOf("/") + 1));
        response = addCommandV1(payload);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.SC_CONFLICT);
        Assert.assertTrue(response.asString().contains(newCommandName + " command already exists"));

    }

    @DataProvider
    public Object[][] deleteCommandDP()
    {
        return new Object[][]
        {
                // {
                // "scenario","commandId", "statusCode", "responseMessage"
                // },
                {
                        "Add and delete a command", "add", "204", ""
                },
                {
                        "Delete System Command", "400", "404", ""
                },
                {
                        "Delete command id which doesn't exist", "1111", "404", ""
                },
        };
    }

    @Test(dataProvider = "deleteCommandDP")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Delete a command under few scenarios", description = "User tries to delete the command which does not exist and also tries to delete system command", preCondition = "System should have commands on which delete operation can be performed")
    public void testDeleteCommand(String scenario, String commandId, String expectedStatusCode, String responseMessage)
    {

        _logger.info("\t Running Scenario: " + scenario);
        if ( commandId.equals("add") )
        {
            String payload = "{\"displayName\":\"deleteCommandTest1\",\"command\":\"listfiles1\",\"hasOutput\":true,\"parameters\":[{ \"displayName\":\"ParameterName\",\"key\":\"key\",\"value\":\"value\",\"isEditable\":false}],\"type\":\"CUSTOM\",\"handler\":\"myType\"}";

            Response response = addCommandV1(payload);
            response.then().statusCode(HttpStatus.SC_CREATED);

            // get commandId of added command
            String location = response.getHeader(LOCATION);

            String createdCommandId = location.substring(location.lastIndexOf("/") + 1);
            softAssert.assertTrue(!createdCommandId.isEmpty());

            response = deleteCommandV1(createdCommandId);

            softAssert.assertEquals(response.statusCode(), Integer.parseInt(expectedStatusCode));
            if ( !responseMessage.equals("") )
            {
                softAssert.assertEquals(response.statusLine(), "Command Does not exist for commandId: " + commandId);
            }
            softAssert.assertAll();

        }
        else
        {

            Response response = deleteCommandV1(commandId);
            Assert.assertEquals(response.statusCode() + "", expectedStatusCode);

        }
    }

    @Test(dependsOnMethods = "testGetCommands")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Delete a system command", description = "User tries to delete system command which returns status code as 403 and user is forbidden from deleting a command", preCondition = "System should have system command on which delete operation can be performed")
    public void testDeleteSystemCommand()
    {
        Response response = deleteCommandV1("1");

        response.then().statusCode(HttpStatus.SC_FORBIDDEN);

        Assert.assertTrue(response.asString().toLowerCase().contains("system command cannot be deleted"));

    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get command history for a device", description = "User should get the status code as 200 when get command history request is made", preCondition = "System should have some pre-existing command history for a device")
    public void testGetCommandHistory()
    {

        Response response = CommandManagementControllerUtils.getDeviceCommandHistoryV1(deviceId);

        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get command history for an invalid device", description = "User should get the status code as 404 when get command history request is made for an invalid device", preCondition = "System should have some pre-existing command history for a device")
    public void given_invalid_device_when_getCommandHistory_then_fail_404()
    {

        Response response = CommandManagementControllerUtils.getDeviceCommandHistoryV1("device_donot_exist");
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_NOT_FOUND);
        softAssert.assertTrue(response.asString().contains("Device not found"));
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Add and delete a command", description = "User tries to add a command and then delete command", preCondition = "System should be stable to create and delete command for a device")
    public void AddAndDeleteCommand()
    {
        // cleanup if the command exist with name QE-Command
        Response response = CommandManagementControllerUtils.getCommandWithDisplayNameV1("QE-Command");

        if ( response != null && StringUtils.isNotEmpty(response.asString()) )
        {
            Map<String, Integer> commandDisplayNameMap = CommandManagementControllerUtils
                    .getCommandIdMap(response.asString());

            if ( commandDisplayNameMap.containsKey("QE-Command") )
            {
                CommandManagementControllerUtils.deleteCommandV1(commandDisplayNameMap.get("QE-Command").toString());
            }

        }

        // add command
        String commandName = CommonUtils.getTimeStamp_HH_mm_ss_yyyy_MM_dd() + "_command";

        String payload = addCommandPayload;

        payload = payload.replaceAll("command_name", commandName);
        payload = payload.replaceAll("command_type", "CUSTOM");
        payload = payload.replaceAll("display_name", "QE-Command");

        response = CommandManagementControllerUtils.addCommandV1(payload);

        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_CREATED);
        response = CommandManagementControllerUtils.getCommandWithDisplayNameV1("QE-Command");
        softAssert.assertTrue(response.asString().contains(commandName));
        Map<String, Integer> qeCommandId = CommandManagementControllerUtils.getCommandIdMap(response.asString());
        int newCommandId = qeCommandId.get("QE-Command");
        // delete command
        response = CommandManagementControllerUtils.deleteCommandV1(newCommandId + "");
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_NO_CONTENT);
        softAssert.assertAll();

    }

    @DataProvider
    public Object[][] modifyCommandDP()
    {
        return new Object[][]
        {
                // {"scenario","commandName", "commandType", "agentType", "description", "statusCode", "responseMessage"},
                {
                        "modify custom command description", QEConstants.PREDIX_MACHINE, "description_one",
                        "egg_bacon_sausage", "204", ""
                },
                {
                        "modify custom command description with empty string", QEConstants.EDGE_AGENT,
                        "description_two", "", "204", ""
                },
                {
                        "modify max limit description", QEConstants.PREDIX_MACHINE, "this is a description",
                        "This is a test description of 200 char. This is a test description of 200 char. This is a test description of 200 char. This is a test description of 200 char. This is a test description of 200 char. ",
                        "400", "longer than 125 characters"
                }
        };
    }

    @Test(dataProvider = "modifyCommandDP")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Update command for a device using different options", description = "Update command for various scenarios like-modify custom command description,modify custom command description with empty string,modify max limit description", preCondition = "System should have command to be modified")
    public void testModifyCommand(String scenario, String agentType, String oldDescription, String newDescription,
            String modifyStatusCode, String responseBodyMessage)
    {
        _logger.info("\tRunning scenario: " + scenario);

        // add custom command
        String payload = "{\"displayName\":\"command_name\",\"command\":\"listfiles1\",\"hasOutput\":true,\"parameters\":[{ \"displayName\":\"ParameterName\",\"key\":\"key\",\"value\":\"value\",\"editable\":false}],\"type\":\"CUSTOM\",\"handler\":\"myType\",\"agentType\":\"$PredixMachine\",\"description\":\"validDescriptionInput\"}";
        String prefix = CommonUtils.getTimeStamp_HH_mm_ss_yyyy_MM_dd();
        String testCommandName = prefix + "_" + "command";
        payload = payload.replace("command_name", testCommandName);
        payload = payload.replace("$PredixMachine", agentType);
        payload = payload.replace("validDescriptionInput", oldDescription);
        _logger.info("\tAddCommand payload: " + payload);

        Response addResponse = CommandManagementControllerUtils.addCommandV1(payload);

        if ( addResponse.statusCode() == HttpStatus.SC_CREATED )
        {
            // get commandId from the response header
            String location = addResponse.getHeader(LOCATION);
            String commandId = location.substring(location.lastIndexOf("/") + 1);
            softAssert.assertTrue(!commandId.isEmpty(), "commandId is missing");
            this.addCommandList.add(commandId);

            // modify description fields
            String modPayload = "[{\"action\":\"edit\",\"field\":\"description\",\"value\":\"" + newDescription
                    + "\"}]";

            Response modifyResponse = CommandManagementControllerUtils.modifyCommandByIdV1(commandId, modPayload);
            softAssert.assertEquals(modifyResponse.statusCode(), Integer.parseInt(modifyStatusCode),
                    "Response codes do not match");
            if ( modifyResponse.statusCode() != HttpStatus.SC_NO_CONTENT
                    && scenario.equals("modify max limit description") )
            {
                _logger.info("\tModification rejected: " + modifyResponse.body().asString());
                softAssert.assertEquals(modifyResponse.statusCode() + "", modifyStatusCode,
                        "Response codes do not match ");
                softAssert.assertNotNull(modifyResponse.body(), "Response should not be null");
                softAssert.assertTrue(modifyResponse.body().asString().contains(responseBodyMessage));
            }
            else
            {
                // verify description modification occured
                Response commandResponse = CommandManagementControllerUtils.getCommandDetailByIdV1(commandId);
                softAssert.assertEquals(commandResponse.statusCode(), HttpStatus.SC_OK, "Response codes do not match");
                JsonPath jsonPath = commandResponse.jsonPath();
                Map<String, String> commandModel = jsonPath.getMap("$");
                softAssert.assertTrue(commandModel.get(CommandConstants.DESCRIPTION).contains(newDescription),
                        "Modified description do not match");
            }
        }
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Update system command for a device and get status code as 400(Bad Request)", description = "Update system command for a device and get status code as 400(Bad Request) since system command cannot be modified", preCondition = "There should be system command to be modified")
    public void modifySystemCommand()
    {
        String modPayload = "[{\"action\":\"edit\",\"field\":\"description\",\"value\":\"stringstring\"}]";
        Response response = CommandManagementControllerUtils.modifyCommandByIdV1("1", modPayload);
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_BAD_REQUEST, "Response codes do not match");
        softAssert.assertTrue(response.asString().contains("System command cannot be updated"),
                "Response does not contain expected message");
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Update non existing command for a device and get status code as 404(Not Found)", description = "Update a non-existing command for a device and get status code as 404(Not Found) since command to be modified does not exist", preCondition = "System should be stable to handle the update request")
    public void modifyNonExistantCommand()
    {
        String modPayload = "[{\"action\":\"edit\",\"field\":\"description\",\"value\":\"stringstring\"}]";
        Response response = CommandManagementControllerUtils.modifyCommandByIdV1("99999999999", modPayload);
        softAssert.assertEquals(response.statusCode(), HttpStatus.SC_NOT_FOUND, "Response codes do not match");
        softAssert.assertTrue(response.asString().contains("Command does not exist"),
                "Response does not contain expected message");
        softAssert.assertAll();
    }

    @Test(dataProvider = "dataProvider1")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Send command for device and then exeute the command", description = "Send command for device and then execute the command", preCondition = "System should be stable to handle the Send request")
    public void given_device_when_send_command_then_return_execute(String deviceFilter, String commandName,
            String params, int responseCode)
            throws InterruptedException
    {

        String final_payload = sendCommandPayload.replace("DEVICE_FILTER", "\"" + deviceFilter + "\"").replace("PARAMS",
                params);
        _logger.info("\tSendCommand payload: " + final_payload);
        Response response = CommandManagementControllerUtils.sendCommandV1(commandIdMap.get(commandName) + "",
                final_payload);
        softAssert.assertEquals(response.statusCode(), responseCode, "SendCommand response code do not match.");
        String locationHeader = response.getHeader(LOCATION);
        _logger.info("\tLocation header from Response: " + locationHeader);
        softAssert.assertTrue(CommonUtils.isLocationHeaderValid(
                EmapiConstants.EM_API_V1_VERSION + "/command-management/operations/", locationHeader));
        String[] tokens = locationHeader.split("/");
        String opId = tokens[tokens.length - 1];
        response = CommandManagementControllerUtils.getCommandOperationDetailV1(opId);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
        String taskId = null;
        //Null pointer exception check.
        if(!"[]".equals(response.jsonPath().getString("tasks")))
        {
            taskId = response.jsonPath().getString("tasks[0].taskId");
            sentCommandTaskIdList.add(taskId);
        }
        softAssert.assertNotNull(taskId, "TaskId is expected to be not null");
        softAssert.assertAll();
    }

    @SuppressWarnings("unchecked")
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Send command for device", description = "Send command for device and then validate get command operation details and command task details", preCondition = "System should be stable to handle the Send request")
    public void testSendCommand()
            throws InterruptedException
    {
        String deviceFilter = "device_id eq \\\\\"" + deviceId + "\\\\\"";

        String final_payload = sendCommandPayload.replaceAll("DEVICE_FILTER", "\"" + deviceFilter + "\"")
                .replace("PARAMS", "");
        _logger.info("\tSendCommand payload: " + final_payload);
        Response response = CommandManagementControllerUtils.sendCommandV1(commandIdMap.get("ipaddress") + "",
                final_payload);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_ACCEPTED);

        String locationHeader = response.getHeader(LOCATION);
        _logger.info("\tLocation header from Response: " + locationHeader);

        String[] tokens = locationHeader.split("/");
        operationId = tokens[tokens.length - 1];
        softAssert.assertTrue(CommonUtils.isLocationHeaderValid(
                EmapiConstants.EM_API_V1_VERSION + "/command-management/operations/", locationHeader));
        _logger.info("\tOperation Id for ipaddress: " + operationId);

        response = CommandManagementControllerUtils.getCommandOperationDetailV1(operationId);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
        JsonPath jsonPath = response.jsonPath();
        softAssert.assertNotNull(jsonPath.getLong("created"), "created is null");
        softAssert.assertNotNull(jsonPath.getString("name"), "Name is null.");
        softAssert.assertEquals(jsonPath.getString("operationId"), operationId, "operationId do not match");
        softAssert.assertNotNull(jsonPath.getLong("scheduled"), "scheduled is null");
        softAssert.assertEquals(jsonPath.getString("scheduledBy"), cfg.getApiClientId(),
                "scheduledBy do not match the clientId");
        softAssert.assertNotNull(jsonPath.getString("status"), "status is null");
        String taskId = jsonPath.getString("tasks[0].taskId");
        _logger.info("\tTask Id for ipaddress: " + taskId);
        softAssert.assertNotEquals(taskId, "");
        softAssert.assertEquals(jsonPath.getString("tasks[0].deviceId"), deviceId,
                "Device id in response doesn't match");

        response = CommandManagementControllerUtils.getCommandTaskV1(taskId);
        jsonPath = response.jsonPath();
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
        softAssert.assertEquals(jsonPath.getString("taskId"), taskId, "TaskId do not match");
        softAssert.assertEquals(jsonPath.getString("operationId"), operationId, "OperationId do not match");
        softAssert.assertEquals(jsonPath.getString("deviceId"), deviceId, "Device Id do not match");
        softAssert.assertTrue(jsonPath.getString("name").contains("IP Address"),
                "command name does not contain IP Address");
        softAssert.assertEquals(jsonPath.getString("type"), "Machine", "command type is not Machine");
        softAssert.assertNotNull(jsonPath.getString("status"), "command status is null");
        softAssert.assertNotNull(jsonPath.getString("payload"), "command payload is null");
        softAssert.assertNotNull(jsonPath.getString("deviceName"), "deviceName is null");
        softAssert.assertTrue(jsonPath.getBoolean("hasOutput"), "hasOutput is false for getIpAddress");
        softAssert.assertTrue(jsonPath.getLong("scheduled") <= System.currentTimeMillis(), "scheduled time is null");
        softAssert.assertTrue(jsonPath.getLong("created") <= System.currentTimeMillis(), "created time is null");
        softAssert.assertEquals(jsonPath.getInt("priority"), 0, "priority is not equal to 0");
        softAssert.assertEquals(jsonPath.getString("scheduledBy"), cfg.getApiClientId(),
                "scheduledBy do not match the clientId");

        // cancel task
        response = CommandManagementControllerUtils.cancelTasksV1("[\"" + taskId + "\"]");
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_ACCEPTED,
                "Command Cancel Task response code do not match");
        Map<String, Object> cancelTask = (Map<String, Object>) response.jsonPath().getList("$").get(0);
        String taskStatus = (String) cancelTask.get("result");
        Thread.sleep(30000);
        List<String> expectedResultList = Arrays.asList("cancel-pending", "cancelled", "command-already-started");

        softAssert.assertTrue(expectedResultList.contains(taskStatus));
        // cancel command if it is pending
        if ( taskStatus.equals("pending") )
        {
            response = CommandManagementControllerUtils.getCommandTaskV1(taskId);
            softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
            softAssert.assertTrue(expectedResultList.contains(response.jsonPath().getMap("$").get("status")));
        }

        softAssert.assertAll();
    }

    @SuppressWarnings("unchecked")
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Delete a command by task id", description = "Delete a command using commands task id", preCondition = "System should have commands in the system")
    public void testDeleteCommandByTaskId()
            throws InterruptedException
    {
        String deviceFilter = "device_id eq \\\\\"" + deviceId + "\\\\\"";

        String final_payload = sendCommandPayload.replaceAll("DEVICE_FILTER", "\"" + deviceFilter + "\"")
                .replace("PARAMS", "");
        _logger.info("\tSendCommand payload: " + final_payload);
        Response response = CommandManagementControllerUtils.sendCommandV1(commandIdMap.get("ipaddress") + "",
                final_payload);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_ACCEPTED);

        String locationHeader = response.getHeader(LOCATION);
        _logger.info("\tLocation header from Response: " + locationHeader);

        String[] tokens = locationHeader.split("/");
        operationId = tokens[tokens.length - 1];
        softAssert.assertTrue(CommonUtils.isLocationHeaderValid(
                EmapiConstants.EM_API_V1_VERSION + "/command-management/operations/", locationHeader));
        _logger.info("\tOperation Id for ipaddress: " + operationId);

        response = CommandManagementControllerUtils.getCommandOperationDetailV1(operationId);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
        JsonPath jsonPath = response.jsonPath();
        String taskId = jsonPath.getString("tasks[0].taskId");
        _logger.info("\tTask Id for ipaddress: " + taskId);
        softAssert.assertNotEquals(taskId, "");
        softAssert.assertEquals(jsonPath.getString("tasks[0].deviceId"), deviceId,
                "Device id in response doesn't match");

        response = CommandManagementControllerUtils.getCommandTaskV1(taskId);
        jsonPath = response.jsonPath();
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
        softAssert.assertEquals(jsonPath.getString("taskId"), taskId, "TaskId do not match");
        softAssert.assertEquals(jsonPath.getString("operationId"), operationId, "OperationId do not match");
        softAssert.assertEquals(jsonPath.getString("deviceId"), deviceId, "Device Id do not match");
        softAssert.assertTrue(jsonPath.getString("name").contains("IP Address"),
                "command name does not contain IP Address");

        // Delete an Existing and Valid Taskid
        response = CommandManagementControllerUtils.deleteCommandTaskV1(taskId);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK);

        // Delete an non existing Task Id
        response = CommandManagementControllerUtils.deleteCommandTaskV1("nonExistingTaskId");
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_NOT_FOUND);

        softAssert.assertAll();
    }

    @SuppressWarnings("unchecked")
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Upload output files produced from the command", description = "Upload output files produced from the command", preCondition = "System should have sommands in the system")
    public void testUploadTaskOutput()
            throws InterruptedException
    {
        String deviceFilter = "device_id eq \\\\\"" + deviceId + "\\\\\"";

        String final_payload = sendCommandPayload.replaceAll("DEVICE_FILTER", "\"" + deviceFilter + "\"")
                .replace("PARAMS", "");
        _logger.info("\tSendCommand payload: " + final_payload);
        Response response = CommandManagementControllerUtils.sendCommandV1(commandIdMap.get("ipaddress") + "",
                final_payload);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_ACCEPTED);

        String locationHeader = response.getHeader(LOCATION);
        _logger.info("\tLocation header from Response: " + locationHeader);

        String[] tokens = locationHeader.split("/");
        String uploadOperationId = tokens[tokens.length - 1];
        softAssert.assertTrue(CommonUtils.isLocationHeaderValid(
                EmapiConstants.EM_API_V1_VERSION + "/command-management/operations/", locationHeader));
        _logger.info("\tOperation Id for ipaddress: " + uploadOperationId);

        response = CommandManagementControllerUtils.getCommandOperationDetailV1(uploadOperationId);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
        JsonPath jsonPath = response.jsonPath();
        String taskId = jsonPath.getString("tasks[0].taskId");
        _logger.info("\tTask Id for ipaddress: " + taskId);
        softAssert.assertNotEquals(taskId, "");
        softAssert.assertEquals(jsonPath.getString("tasks[0].deviceId"), deviceId,
                "Device id in response doesn't match");

        response = CommandManagementControllerUtils.getCommandTaskV1(taskId);
        jsonPath = response.jsonPath();
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
        softAssert.assertEquals(jsonPath.getString("taskId"), taskId, "TaskId do not match");
        softAssert.assertEquals(jsonPath.getString("operationId"), uploadOperationId, "OperationId do not match");
        softAssert.assertEquals(jsonPath.getString("deviceId"), deviceId, "Device Id do not match");
        softAssert.assertTrue(jsonPath.getString("name").contains("IP Address"),
                "command name does not contain IP Address");

        response = CommandManagementControllerUtils.uploadCommandOutputV1(taskId,
                "src/main/resources/command/commandOutput.txt", "commandOutput.txt");
        // Successfully Uploaded the Output content
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_CREATED, "Upload output should return 201");

        response = CommandManagementControllerUtils.getCommandTaskOutputV1(taskId);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK,
                "GET Command Task output should return 200");
        softAssert.assertTrue(response.getBody().asString().contains("Command Ran Successfully"),
                "The downloaded Command output should have Command Ran Successfully message");

        softAssert.assertAll();
    }

    @AfterClass(alwaysRun = true)
    public void cleanup()
    {
        _logger.info("CLEANUP:  Command Test....");
        for (String commandId : this.addCommandList)
        {
            _logger.info(String.format("\tDeleting command id: %s", commandId));
            Response response = deleteCommandV1(commandId);
            Assert.assertEquals(response.statusCode(), HttpStatus.SC_NO_CONTENT, "Response codes do not match.");
            _logger.info(String.format("\tDelete Command response status code: %d", response.statusCode()));
        }

        sentCommandTaskIdList.forEach(taskId -> {
            _logger.info("Cancelling sent command task: " + taskId);
            Response response = CommandManagementControllerUtils.cancelTasksV1("[\"" + taskId + "\"]");
            softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_ACCEPTED,
                    "Command Cancel Task response code do not match");
        });
    }
}
