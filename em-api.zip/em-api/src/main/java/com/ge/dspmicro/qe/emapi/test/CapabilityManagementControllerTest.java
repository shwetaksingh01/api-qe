/*
 * Copyright (c) 2019 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.emapi.test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpHeaders;
import org.apache.http.HttpStatus;
import org.assertj.core.api.SoftAssertions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ge.dspmicro.qe.emapi.utils.CapabilityManagementControllerUtils;
import com.ge.dspmicro.qe.tools.BaseTest;
import com.ge.dspmicro.qe.tools.testng.TestListener;
import com.ge.dspmicro.qe.tools.utils.CommonUtils;
import com.ge.predix.edgemanager.qe.annotations.JiraTestCaseInfo;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;

/**
 *
 * @author 212758475
 */
@SuppressWarnings(
{
        "javadoc", "nls"
})
@Listeners(TestListener.class)
public class CapabilityManagementControllerTest extends BaseTest
{
    private static final Logger _logger                = LoggerFactory
            .getLogger(CapabilityManagementControllerTest.class);
    private static final String CAPABILITY_NAME_KEY    = "name";
    private static final String CAPABILITY_VERSION_KEY = "version";
    private static final String CAPABILITY_TYPE_KEY    = "type";
    private static final String CAPABILITY_NAME        = "qe." + System.currentTimeMillis() + "-capability";
    private static final String CAPABILITY_VERSION     = "1.0.0";
    private static final String CAPABILITY_UPDATED_VERSION = "1.0.1";
    private static final String CAPABILITY_DESCRIPTION = "This is a cloud-qe Test";
    private static final String CAPABILITY_PAYLOAD_PATH = "/capability/addCapabilityPayload.json";

    private Map<String, Object> queryParams;
    private SoftAssertions softAssertions;

    @Override @BeforeClass
    public void init()
    {
        this.softAssertions = new SoftAssertions();
        this.queryParams = new HashMap<>();
    }

    //GET emapi/v1/capability-management/capabilities
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get all Capabilities from the System", description = "Get request made to get all the capabilities from the System", preCondition = "System should have some capabilities added")
    public void testGetCapabilities()
    {
        Response response = CapabilityManagementControllerUtils.getCapabilities(this.queryParams);
        softAssert.assertNotNull(response);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
        JsonPath jsonPath = response.getBody().jsonPath();
        List<Map<String, String>> capabilities = jsonPath.getList("$");
        if ( !capabilities.isEmpty() )
        {
            assertCapabilityStaticFields(capabilities.get(0));
        }
        softAssert.assertAll();
    }

    //POST /emapi/v1/capability-management/capabilities
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Create Capability with Valid Name and Valid Version", description = "Post a request to create Capability with Valid Name and Valid Version", preCondition = "System should be stable to post a request")
    public void testCreateCapabilityWithValidNameAndValidVersion()
    {
        String payload = createPayload(CAPABILITY_NAME, CAPABILITY_VERSION, CAPABILITY_DESCRIPTION);
        Response response = CapabilityManagementControllerUtils.createCapability(payload);
        softAssert.assertNotNull(response);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_CREATED);
        softAssert.assertNotNull(response.getHeader(HttpHeaders.LOCATION));
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Create Capability with Valid Name and Valid Version", description = "Post a request to create Capability with Valid Name and Valid Version", preCondition = "System should be stable to post a request")
    public void testCreateCapabilityWithExistingCapabilityNameAndValidNewVersion()
    {
        String payload = createPayload(CAPABILITY_NAME, CAPABILITY_UPDATED_VERSION, CAPABILITY_DESCRIPTION);
        Response response = CapabilityManagementControllerUtils.createCapability(payload);
        softAssert.assertNotNull(response);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_CREATED);
        softAssert.assertNotNull(response.getHeader(HttpHeaders.LOCATION));
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Create Capability with ReservedNamespace as Prefix", description = "Post a request to create Capability with ReservedNamespace as Prefix and get the status code as 400", preCondition = "System should be stable to post a request")
    public void testCreateCapabilityWithReservedNamespaceAsPrefix()
    {
        String reservedNamespace = "predix.edge";
        String payload = createPayload(reservedNamespace + CAPABILITY_NAME, CAPABILITY_VERSION,
                CAPABILITY_DESCRIPTION);
        Response response = CapabilityManagementControllerUtils.createCapability(payload);
        softAssert.assertNotNull(response);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_BAD_REQUEST);
        softAssert.assertAll();
    }

    @Test(dependsOnMethods = "testCreateCapabilityWithValidNameAndValidVersion")
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Create Capability with duplicate capability", description = "Post a request to create Capability with duplicate capability and get the status code as 409", preCondition = "System should be stable to post a request")
    public void testCreateCapabilityWithDuplicateCapability()
    {
        String payload = createPayload(CAPABILITY_NAME, CAPABILITY_VERSION, CAPABILITY_DESCRIPTION);
        Response response = CapabilityManagementControllerUtils.createCapability(payload);
        softAssert.assertNotNull(response);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_CONFLICT);
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Create Capability with invalid character at start in name", description = "Post a request to create Capability with invalid character at start in name and get the status code as 400", preCondition = "System should be stable to post a request")
    public void testCreateCapabilityWithInvalidCharacterAtStartInName()
    {
        String invalidCapabilityName = "&" + CAPABILITY_NAME;
        String payload = createPayload(invalidCapabilityName, CAPABILITY_VERSION, CAPABILITY_DESCRIPTION);
        Response response = CapabilityManagementControllerUtils.createCapability(payload);
        softAssert.assertNotNull(response);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_BAD_REQUEST);
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Create Capability with invalid character at End in name", description = "Post a request to create Capability with invalid character at end in name and get the status code as 400", preCondition = "System should be stable to post a request")
    public void testCreateCapabilityWithInvalidCharacterAtEndInName()
    {
        String invalidCapabilityName = CAPABILITY_NAME + "&";
        String payload = createPayload(invalidCapabilityName, CAPABILITY_VERSION, CAPABILITY_DESCRIPTION);
        Response response = CapabilityManagementControllerUtils.createCapability(payload);
        softAssert.assertNotNull(response);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_BAD_REQUEST);
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Create Capability with invalid character in name", description = "Post a request to create Capability with invalid character in name and get the status code as 400", preCondition = "System should be stable to post a request")
    public void testCreateCapabilityWithInvalidCharacterInName()
    {
        String invalidCapabilityName = "qe&test-capability";
        String payload = createPayload(invalidCapabilityName, CAPABILITY_VERSION, CAPABILITY_DESCRIPTION);
        Response response = CapabilityManagementControllerUtils.createCapability(payload);
        softAssert.assertNotNull(response);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_BAD_REQUEST);
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Create Capability with invalid version in character", description = "Post a request to create Capability with invalid version in character and get the status code as 400", preCondition = "System should be stable to post a request")
    public void testCreateCapabilityWithInvalidVersionWithCharacter()
    {
        String invalidCapabilityVersion = "1.o.1";
        String payload = createPayload(CAPABILITY_NAME, invalidCapabilityVersion, CAPABILITY_DESCRIPTION);
        Response response = CapabilityManagementControllerUtils.createCapability(payload);
        softAssert.assertNotNull(response);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_BAD_REQUEST);
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Create Capability with invalid version", description = "Post a request to create Capability with invalid version and get the status code as 400", preCondition = "System should be stable to post a request")
    public void testCreateCapabilityWithInvalidVersion()
    {
        String invalidCapabilityVersion = "1.0";
        String payload = createPayload(CAPABILITY_NAME, invalidCapabilityVersion, CAPABILITY_DESCRIPTION);
        Response response = CapabilityManagementControllerUtils.createCapability(payload);
        softAssert.assertNotNull(response);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_BAD_REQUEST);
        softAssert.assertAll();
    }

    //GET /emapi/v1/capability-management/capabilities/{name}/{version}
    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Test get Capability with valid name and valid version", description = "Test get capability with valid name and valid version and get the status code as 200", preCondition = "System should be stable to post a request")
    public void testGetCapabilityWithValidNameAndValidVersion()
    {
        Response response = CapabilityManagementControllerUtils
                .getCapability(CAPABILITY_NAME, CAPABILITY_VERSION, this.queryParams);
        softAssert.assertNotNull(response);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
        JsonPath jsonPath = response.jsonPath();
        Map<String, String> capability = jsonPath.getMap("$");
        assertCapabilityStaticFields(capability);
        assertCapabilityVariableFields(capability);
        softAssert.assertAll();
    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-api", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "18628", testType = "system-tests", testCaseName = "Get  Capability with Invalid Capability name", description = "Get capability with Invalid capability name and get the status code as 404(", preCondition = "System should be stable to post a request")
    public void testGetCapabilityWithInvalidCapability()
    {
        String invalidCapability = CAPABILITY_NAME + "_invalid";
        Response response = CapabilityManagementControllerUtils
                .getCapability(invalidCapability, CAPABILITY_VERSION, this.queryParams);
        softAssert.assertNotNull(response);
        softAssert.assertEquals(response.getStatusCode(), HttpStatus.SC_NOT_FOUND);
        softAssert.assertAll();
    }

    @AfterClass
    public void tearDown()
    {
        Response deleteResponseForOriginal =
                CapabilityManagementControllerUtils.deleteCapability(CAPABILITY_NAME, CAPABILITY_VERSION);
        Response deleteResponseForUpdated =
                CapabilityManagementControllerUtils.deleteCapability(CAPABILITY_NAME, CAPABILITY_UPDATED_VERSION);
        if(deleteResponseForOriginal.getStatusCode() == HttpStatus.SC_NO_CONTENT
                && deleteResponseForUpdated.getStatusCode() == HttpStatus.SC_NO_CONTENT)
        {
            _logger.info("Created test data is deleted");
        }
    }

    private String createPayload(String name, String version, String description)
    {
        String payload = CommonUtils.getResourceAsString(CAPABILITY_PAYLOAD_PATH);
        if(payload != null)
        {
            payload = payload.replaceAll("\\$name", name)
                    .replaceAll("\\$version", version)
                    .replaceAll("\\$description", description);
        } return payload;
    }

    private void assertCapabilityStaticFields(Map<String, String> capability)
    {
        softAssert.assertNotNull(capability);
        softAssert.assertTrue(capability.containsKey(CAPABILITY_NAME_KEY));
        softAssert.assertTrue(capability.containsKey(CAPABILITY_VERSION_KEY));
        softAssert.assertTrue(capability.containsKey(CAPABILITY_TYPE_KEY));
        this.softAssertions.assertThat(capability.size()).isGreaterThanOrEqualTo(3);
        this.softAssertions.assertThat(capability.get(CAPABILITY_TYPE_KEY)).isIn(Arrays.asList("SYSTEM","CUSTOM"));
        softAssert.assertAll();
        this.softAssertions.assertAll();
    }

    private void assertCapabilityVariableFields(Map<String, String> capability)
    {
        softAssert.assertEquals(capability.get(CAPABILITY_NAME_KEY), CAPABILITY_NAME);
        softAssert.assertEquals(capability.get(CAPABILITY_VERSION_KEY), CAPABILITY_VERSION);
        softAssert.assertAll();
    }

}
