package com.ge.dspmicro.qe.alert;
/*
 * Copyright (c) 2018 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

import java.util.Map;

import com.ge.dspmicro.qe.tools.environment.Configuration;
import com.ge.dspmicro.qe.tools.utils.RestClient;
import com.ge.dspmicro.qe.tools.utils.Token;
import com.jayway.restassured.response.Response;

/**
 * 
 * @author 212391321
 */

@SuppressWarnings(value =
{
        "javadoc", "nls"
})
public class AlertMgmtControllerUtils
{
    private static       Configuration cfg        = Configuration.getConfig();
    private static       Token         token      = cfg.getAdminUAAToken();
    private static final String        BASE_URI   = "/svc/alert/v1/alert-mgmt/";
    private static final String        ALERTS_URI = BASE_URI + "alerts";

    // GET /svc/alert/v1/alert-mgmt/alerts
    public static Response getAlerts(Map<String, ?> queryParams)
    {
        return RestClient.get(cfg.getEdgeManagerUrl(), ALERTS_URI, queryParams, token);
    }

    // PATCH /svc/alert/v1/alert-mgmt/alerts
    public static Response updateAlerts(String payload)
    {
        return RestClient.patch(cfg.getEdgeManagerUrl(), ALERTS_URI, payload, token);
    }

    // HEAD /svc/alert/v1/alert-mgmt/alerts
    public static Response getNumberOfAlerts(Map<String, ?> queryParams)
    {
        return RestClient.head(cfg.getEdgeManagerUrl(), ALERTS_URI, queryParams, token);
    }

    public void setToken(Token token) {
        AlertMgmtControllerUtils.token = token;
    }

    public Token getToken() {
        return AlertMgmtControllerUtils.token;
    }
}
