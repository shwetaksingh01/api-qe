/*
 * Copyright (c) 2017 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.qe.alert.test;

import sun.tools.tree.IntegerExpression;

import static com.ge.dspmicro.qe.alert.AlertMgmtControllerUtils.getAlerts;
import static com.ge.dspmicro.qe.alert.AlertMgmtControllerUtils.updateAlerts;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ge.dspmicro.qe.alert.AlertMgmtControllerUtils;
import com.ge.dspmicro.qe.tools.BaseTest;
import com.ge.predix.edgemanager.qe.annotations.JiraTestCaseInfo;
import com.jayway.restassured.response.Response;
import com.ge.dspmicro.qe.tools.testng.TestListener;

/**
 * @author 212391321
 */
@SuppressWarnings(
{
        "javadoc", "nls"
})
@Listeners(TestListener.class)
public class AlertTest extends BaseTest
{
    // enum FilterSourceType
    // {
    // ALERT_SOURCE_DEVICE, ALERT_SOURCE_SIM, ALERT_SOURCE_OPENVPN;
    // }
    // enum FilterServerity
    // {
    // ALERT_SEVERITY_CRITICAL, ALERT_SEVERITY_ERROR, ALERT_SEVERITY_WARNING, ALERT_SEVERITY_INFO
    // }
    // enum FilterStatus
    // {
    // ALERT_STATUS_OPEN, ALERT_STATUS_ACKNOWLEDGED, ALERT_STATUS_CLOSED
    // }
    // enum AlertType
    // {
    // DEVICE_ONLINE_OFFLINE, SIM_USAGE, OPENVPN_STATUS, CELLULAR_STRENGTH
    // }

    private static final Logger _logger = LoggerFactory.getLogger(AlertTest.class);

    @Test
    @JiraTestCaseInfo(moduleName = "em-alert", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "13442", testType = "system-tests", testCaseName = "Get Alerts without applying any Alert Filter", description = "User can view the list of alerts without applying any filter on Alerts page", preCondition = "System should have some pre-existing Alerts")
    public void testGetAlertsWithNoFilter()
    {

        Map<String, Object> qMap = new HashMap<>();
        qMap.put("limit", 1);
        qMap.put("offset", 0);

        Response response = getAlerts(qMap);
        Assert.assertEquals(response.getStatusCode(), 200);

        List<Map<String, Object>> alerts = response.jsonPath().getList("$");
        softAssert.assertTrue(alerts.size() == 1);
//        System.out.println(alerts.get(0).get("id"));
        softAssert.assertNotNull(alerts.get(0).get("id"), "alert should have an id");
        softAssert.assertNotNull(alerts.get(0).get("source"), "alert should have source");
        softAssert.assertNotNull(alerts.get(0).get("severity"), "alert should have severity");
        softAssert.assertNotNull(alerts.get(0).get("status"), "alert should have status");
        if ( alerts.get(0).get("source_type") != null && alerts.get(0).get("source_type")
                .equals("ALERT_SOURCE_OPENVPN") )
        {
            // openvpn alerts do not have a description
        }
        else
        {
            softAssert.assertNotNull(alerts.get(0).get("description"), "alert should have description");
        }
        softAssert.assertNotNull(alerts.get(0).get("device_id"), "alert should have device_id");
        softAssert.assertNotNull(alerts.get(0).get("alert_type"), "alert should have alert_type");
        softAssert.assertNotNull(alerts.get(0).get("source_type"), "alert should have source_type");
        softAssert.assertNotNull(alerts.get(0).get("triggered_timestamp"), "alert should have triggered_timestamp");
        softAssert.assertNotNull(alerts.get(0).get("lastupdated_timestamp"), "alert should have lastupdated_timestamp");
        softAssert.assertNotNull(alerts.get(0).get("lastupdated_by"), "alert should have lastupdated_by");

        softAssert.assertAll();

    }

    @DataProvider public Object[][] alertFilterDataProvider()
    {

        return new Object[][] {
                // scenario, limit, offset, filter, contain, sortBy, sortOrder,deviceFilter, expectedStatusCode, expectedSourceType,
                // expectedServerity,expectedAlertStatus, expectedAlertType

                {"GetAlerts with Filter source_type eq \"ALERT_SOURCE_DEVICE\" and severity eq \"ALERT_SEVERITY_CRITICAL\"",
                        1, 0, "source_type eq \"ALERT_SOURCE_DEVICE\" and severity eq \"ALERT_SEVERITY_CRITICAL\"", "",
                        "", "", "", 200, "ALERT_SOURCE_DEVICE", "ALERT_SEVERITY_CRITICAL", "", ""
                },
                {"GetAlerts with Filter source_type eq \"ALERT_SOURCE_DEVICE\" and severity eq \"ALERT_SEVERITY_WARNING\"",
                        1, 0, "source_type eq \"ALERT_SOURCE_DEVICE\" and severity eq \"ALERT_SEVERITY_WARNING\"", "",
                        "", "", "", 200, "ALERT_SOURCE_DEVICE", "ALERT_SEVERITY_WARNING", "", ""
                },
                {"GetAlerts with Filter source_type eq \"ALERT_SOURCE_DEVICE\" and alert_type eq \"DEVICE_ONLINE_OFFLINE\"",
                        1, 0, "source_type eq \"ALERT_SOURCE_DEVICE\" and alert_type eq \"DEVICE_ONLINE_OFFLINE\"", "",
                        "", "", "", 200, "ALERT_SOURCE_DEVICE", "", "", "DEVICE_ONLINE_OFFLINE"
                },
                {"GetAlerts with Filter status eq \"ALERT_STATUS_OPEN\" and alert_type eq \"DEVICE_ONLINE_OFFLINE\"", 1,
                        0, "status eq \"ALERT_STATUS_OPEN\" and alert_type eq \"DEVICE_ONLINE_OFFLINE\"", "", "", "",
                        "", 200, "", "", "ALERT_STATUS_OPEN", "DEVICE_ONLINE_OFFLINE"
                },
                {"GetAlerts with Filter status eq \"ALERT_STATUS_OPEN\" and alert_type eq \"DEVICE_ONLINE_OFFLINE\"", 1,
                        0, "status eq \"ALERT_STATUS_OPEN\" and alert_type eq \"DEVICE_ONLINE_OFFLINE\"", "", "", "",
                        "", 200, "", "", "ALERT_STATUS_OPEN", "DEVICE_ONLINE_OFFLINE"
                },
                {"GetAlerts with Device Filter status eq \"ALERT_STATUS_OPEN\" and deviceFilter: model_id eq \"FieldAgent\"",
                        5, 0, "status eq \"ALERT_STATUS_OPEN\"", "", "triggered_timestamp", "desc",
                        "model_id eq \"FieldAgent\"", 200, "", "", "ALERT_STATUS_OPEN", ""
                }
        };

    }

    @Test(dataProvider = "alertFilterDataProvider")
    @JiraTestCaseInfo(moduleName = "em-alert", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "13442", testType = "system-tests", testCaseName = "Get Alerts after applying different filter options available", description = "User can view the correct list of alerts after applying respective filter option on Alerts page", preCondition = "System should have some pre-existing Alerts")
    public void testGetAlertsScenarios(String scenario, int limit, int offset, String filter, String contain,
            String sortBy, String sortOrder, String deviceFilter, int expectedStatusCode, String expectedSourceType,
            String expectedServerity, String expectedAlertStatus, String expectedAlertType)
    {
        _logger.info(String.format("\tRunning: %s", scenario));

        Map<String, Object> qMap = new HashMap<>();
        qMap.put("limit", limit);
        qMap.put("offset", offset);
        if ( !filter.equals("") )
        {
            qMap.put("filter", filter);
        }
        if ( !contain.equals("") )
        {
            qMap.put("contain", contain);
        }
        if ( !sortBy.equals("") )
        {
            qMap.put("sortBy", sortBy);
        }
        if ( !sortOrder.equals("") )
        {
            qMap.put("sortOrder", sortOrder);
        }
        if ( !deviceFilter.equals("") )
        {
            qMap.put("deviceFilter", deviceFilter);
        }

        Response response = getAlerts(qMap);
        Assert.assertEquals(response.getStatusCode(), expectedStatusCode);
        List<Map<String, Object>> alerts = response.jsonPath().getList("$");
        softAssert.assertTrue(alerts.size() == limit);
        softAssert.assertNotNull(alerts.get(0).get("id"), "alert should have id");
        softAssert.assertNotNull(alerts.get(0).get("source"), "alert should have source");
        if ( alerts.get(0).get("source_type") != null && alerts.get(0).get("source_type")
                .equals("ALERT_SOURCE_OPENVPN") )
        {
            // openvpn alerts do not have a description
        }
        else
        {
            softAssert.assertNotNull(alerts.get(0).get("description"), "alert should have description");
        }
        softAssert.assertNotNull(alerts.get(0).get("device_id"), "alert should have device_id");
        softAssert.assertNotNull(alerts.get(0).get("triggered_timestamp"), "alert should have triggered_timestamp");
        softAssert.assertNotNull(alerts.get(0).get("lastupdated_timestamp"), "alert should have lastupdated_timestamp");
        softAssert.assertNotNull(alerts.get(0).get("lastupdated_by"), "alert should have lastupdated_by");

        if ( !expectedSourceType.equals("") )
        {
            softAssert.assertEquals(alerts.get(0).get("source_type"), expectedSourceType,
                    String.format("Alert Source do not match. Expected %s | Actual %s", expectedSourceType,
                            alerts.get(0).get("source_type")));
        }
        if ( !expectedServerity.equals("") )
        {
            System.out.println(alerts.get(0).get("severity"));
            System.out.println(expectedServerity);
            softAssert.assertEquals(alerts.get(0).get("severity"), expectedServerity,
                    String.format("Alert Severity do not match. Expected %s | Actual %s", expectedServerity,
                            alerts.get(0).get("severity")));
        }

        if ( !expectedAlertStatus.equals("") )
        {

            System.out.println(alerts.get(0).get("status"));
            System.out.println(expectedAlertStatus);
            softAssert.assertEquals(alerts.get(0).get("status"), expectedAlertStatus,
                    String.format("Alert Status do not match. Expected %s | Actual %s", expectedAlertStatus,
                            alerts.get(0).get("alert_type")));
        }
        if ( !expectedAlertType.equals("") )
        {
            softAssert.assertEquals(alerts.get(0).get("alert_type"), expectedAlertType,
                    String.format("Alert Type do not match. Expected %s | Actual %s", expectedAlertType,
                            alerts.get(0).get("alert_type")));
        }
        softAssert.assertAll();

    }

    @DataProvider
    public Object[][] updateFilterDataProvider()
    {
        // scenario, payload, expectedStatusCode
        return new Object[][]
        {

                {
                        "UpdateAlert test with action=ACKNOWLEDGE and id =413",
                        "[{\"action\": \"ACKNOWLEDGE\",\"id\": 413}]", 200
                },
                {
                        "UpdateAlertswithInvalidStatusCode", "{\"action\": \"ACKNOWLEDGE\",\"id\": 413}", 400
                },
                {
                        "UpdateAlertswithString", "skldfjlskjdf", 400
                },

        };

    }

    @Test(dataProvider = "updateFilterDataProvider")
    @JiraTestCaseInfo(moduleName = "em-alert", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "13442", testType = "system-tests", testCaseName = "Update the Alert filter", description = "User should be able to update the Alert and get the updated list of Alerts", preCondition = "System should have some pre-existing Alerts")
    public void testUpdateAlertsScenarios(String scenarios, String payload, int expectedStatusCode)
    {

        _logger.info("\tRunning scenario: " + scenarios);

        Response response = updateAlerts(payload);
        Assert.assertEquals(response.getStatusCode(), expectedStatusCode);

    }

    @Test
    @JiraTestCaseInfo(moduleName = "em-alert", epicName = "EdgeManager-mapTestCasesToMethodsInCloud-qe", requirementID = "13442", testType = "system-tests", testCaseName = "Get Alert Count", description = "User should be able to validate the number of Alerts", preCondition = "System should have some pre-existing Alerts")
    public void testGetNumberOfAlerts()
    {

        Map<String, Object> qMap = new HashMap<>();
        qMap.put("limit", 1000);
        qMap.put("offset", 0);

        qMap.put("filter", "source_type eq \"ALERT_SOURCE_DEVICE\" and severity eq \"ALERT_SEVERITY_CRITICAL\"");

        Response response = AlertMgmtControllerUtils.getNumberOfAlerts(qMap);
        Assert.assertEquals(response.getStatusCode(), 204,
                String.format("Expected status code is 204. Found %d", response.statusCode()));
        Assert.assertTrue(Integer.parseInt(response.getHeaders().getValue("Total-Count")) > 0,
                "Total-Count header returned " + response.getHeaders().getValue("Total-Count")
                        + ". Expected value should be greater than 0");

    }

}
